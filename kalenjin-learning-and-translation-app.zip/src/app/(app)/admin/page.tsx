import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getAdminSnapshot } from "@/lib/data";
import { AdminClient } from "@/components/admin-client";
import { InfoNote, ScreenHeader } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata = { title: "Language admin" };

export default async function AdminPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "admin") {
    return (
      <div className="screen">
        <ScreenHeader title="Language admin" backHref="/profile" />
        <InfoNote tone="warn">
          Administrator access is required. Sign in with the admin demo account to review contributions and manage the
          corpus.
        </InfoNote>
      </div>
    );
  }
  const snapshot = await getAdminSnapshot();

  return (
    <div className="screen">
      <ScreenHeader
        title="Language admin"
        subtitle="Approve contributions, publish reviewed content and keep verification honest."
        backHref="/profile"
      />
      <AdminClient
        pending={snapshot.pending.map((item) => ({
          id: item.id,
          type: item.type,
          status: item.status,
          consent: item.consent,
          createdAt: item.createdAt.toISOString(),
          dialectId: item.dialectId,
          payload: item.payload,
        }))}
        vocabulary={snapshot.vocabulary.map((row) => ({
          id: row.id,
          word: row.word,
          definition: row.definition,
          verificationStatus: row.verificationStatus,
          dialectId: row.dialectId,
        }))}
        dialects={snapshot.dialects.map((dialect) => ({ id: dialect.id, code: dialect.code, name: dialect.name }))}
        recordings={snapshot.recordings.map((recording) => ({
          id: recording.id,
          speakerName: recording.speakerName,
          consentStatus: recording.consentStatus,
          reviewStatus: recording.reviewStatus,
          audioUrl: recording.audioUrl,
        }))}
        stats={{
          phraseCount: snapshot.phraseCount,
          verifiedPhrases: snapshot.verifiedPhrases,
          userCount: snapshot.userCount,
        }}
      />
    </div>
  );
}
