import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getMyContributions, loadDialects } from "@/lib/data";
import { ContributeClient } from "@/components/contribute-client";
import { InfoNote, ScreenHeader } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata = { title: "Contribute" };

export default async function ContributePage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const [dialects, contributions] = await Promise.all([loadDialects(), getMyContributions(user.id)]);

  return (
    <div className="screen">
      <ScreenHeader
        title="Add to the corpus"
        subtitle="Native speakers are the authority. Submit words, corrections, examples and consented recordings."
        backHref="/culture"
      />
      <div className="mb-3">
        <InfoNote tone="warn">
          Nothing you submit is shown to learners until a reviewer approves it. Do not submit borrowed audio without the
          speaker&apos;s consent, and never upload a guess as if it were verified. Every submission is attributed and
          auditable.
        </InfoNote>
      </div>
      <ContributeClient
        dialects={dialects.map((dialect) => ({ id: dialect.id, code: dialect.code, name: dialect.name }))}
        defaultDialectCode={user.dialectCode ?? dialects[0]?.code ?? "kipsigis"}
        contributions={contributions.map((contribution) => ({
          id: contribution.id,
          type: contribution.type,
          status: contribution.status,
          reviewNote: contribution.reviewNote,
          createdAt: contribution.createdAt.toISOString(),
          payload: contribution.payload,
        }))}
      />
    </div>
  );
}
