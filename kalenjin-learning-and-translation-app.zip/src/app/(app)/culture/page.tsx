import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getCultureNotes, getDefaultDialectId } from "@/lib/data";
import { Icon } from "@/components/icons";
import { Card, InfoNote, ScreenHeader, StatusBadge } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata = { title: "Culture" };

export default async function CulturePage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const dialectId = user.dialectId ?? (await getDefaultDialectId());
  const notes = await getCultureNotes(dialectId);
  const categories = Array.from(new Set(notes.map((note) => note.category)));

  return (
    <div className="screen">
      <ScreenHeader
        title="Culture & context"
        subtitle="How greetings, food, cattle and storytelling live inside the language."
        backHref="/learn"
      />

      <InfoNote tone="warn">
        Cultural explanations are seeds for conversation, not a complete account. Customs vary by family, region and
        generation. Every item shows its verification status, and native speakers can submit corrections and recorded
        explanations.
      </InfoNote>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {categories.map((category) => (
          <span key={category} className="chip capitalize">
            {category}
          </span>
        ))}
      </div>

      <div className="mt-3 flex flex-col gap-3">
        {notes.map((note) => (
          <Card key={note.id} className="p-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wide text-[var(--gold)]">{note.category}</p>
                <h2 className="display text-base font-semibold leading-tight text-ink">{note.title}</h2>
              </div>
              <StatusBadge status={note.verificationStatus} />
            </div>
            <p className="mt-1.5 text-xs font-medium text-ink">{note.summary}</p>
            <p className="mt-1.5 text-xs leading-relaxed text-muted">{note.body}</p>
            <p className="mt-2 flex items-center gap-1 text-[10px] text-muted">
              <Icon name="user" size={11} /> {note.contributor ?? "Community contribution"}
            </p>
          </Card>
        ))}
      </div>

      <Card className="mt-4 p-4">
        <h2 className="display text-sm font-semibold text-ink">Add knowledge only you have</h2>
        <p className="mt-1 text-xs leading-relaxed text-muted">
          Record a greeting, a proverb or the cattle terminology your family uses. State your variety, location and
          whether you are the speaker. A reviewer checks it before learners see it as confirmed.
        </p>
        <Link href="/contribute" className="btn btn-primary mt-3 w-full">
          <Icon name="mic" size={15} /> Contribute culture & recordings
        </Link>
      </Card>
    </div>
  );
}
