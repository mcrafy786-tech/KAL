import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getDefaultDialectId, getDictionary, getDictionaryStats } from "@/lib/data";
import { DictionaryClient } from "@/components/dictionary-client";
import { ScreenHeader } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata = { title: "Dictionary" };

export default async function DictionaryPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const dialectId = user.dialectId ?? (await getDefaultDialectId());
  if (!dialectId) redirect("/onboarding");
  const [entries, stats] = await Promise.all([getDictionary(dialectId, user.id), getDictionaryStats(dialectId)]);

  return (
    <div className="screen">
      <ScreenHeader
        title="Dictionary"
        subtitle={`${stats.total} entries in ${user.dialectName ?? "your variety"} · ${stats.reviewed} reviewed`}
      />
      <DictionaryClient
        entries={entries}
        dialectName={user.dialectName ?? "Kalenjin"}
        coverage={{ total: stats.total, reviewed: stats.reviewed, pending: stats.pending }}
      />
    </div>
  );
}
