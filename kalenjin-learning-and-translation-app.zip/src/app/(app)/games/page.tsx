import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getDefaultDialectId, getGameVocabulary, getPhraseRows } from "@/lib/data";
import { Games } from "@/components/games";
import { ScreenHeader } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata = { title: "Games" };

export default async function GamesPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const dialectId = user.dialectId ?? (await getDefaultDialectId());
  if (!dialectId) redirect("/onboarding");
  const [words, phrases] = await Promise.all([getGameVocabulary(dialectId, 30), getPhraseRows(dialectId)]);

  return (
    <div className="screen">
      <ScreenHeader
        title="Play & practise"
        subtitle={`Games use only ${user.dialectName ?? "your variety"} entries. Scores save to your progress.`}
      />
      <Games
        words={words}
        phrases={phrases.map((phrase) => ({
          english: phrase.english,
          kalenjin: phrase.kalenjin,
          status: phrase.verificationStatus,
        }))}
        dialectName={user.dialectName ?? "Kalenjin"}
      />
    </div>
  );
}
