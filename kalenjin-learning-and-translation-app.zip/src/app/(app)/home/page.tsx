import Link from "next/link";
import Image from "next/image";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getDashboard } from "@/lib/data";
import { AudioButton } from "@/components/audio";
import { Icon } from "@/components/icons";
import { Card, InfoNote, ProgressBar, ProgressRing, SectionHeading, Stat, StatusBadge } from "@/components/ui";
import { levelMeta } from "@/content/lessons";

export const dynamic = "force-dynamic";

const QUICK_LINKS = [
  { href: "/translate", label: "Live Translator", icon: "translate" as const, tone: "brand" },
  { href: "/tutor", label: "AI Tutor", icon: "sparkles" as const, tone: "gold" },
  { href: "/dictionary", label: "Dictionary", icon: "search" as const, tone: "neutral" },
  { href: "/games", label: "Games", icon: "game" as const, tone: "neutral" },
  { href: "/culture", label: "Culture", icon: "globe" as const, tone: "neutral" },
  { href: "/practice/pronunciation", label: "Pronunciation", icon: "headphones" as const, tone: "neutral" },
];

export default async function HomePage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (!user.onboarded) redirect("/onboarding");
  const data = await getDashboard(user);
  const goal = user.dailyGoalMinutes;
  const minutesToday = data.today?.minutes ?? 0;
  const goalPercent = Math.min(100, Math.round((minutesToday / goal) * 100));
  const lesson = data.nextLesson;
  const reviewLabel = levelMeta.find((meta) => meta.level === lesson?.level)?.title ?? "Keep going";

  return (
    <div className="screen flex flex-col gap-5">
      <section className="fade-up">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted">
          {new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}
        </p>
        <h1 className="display mt-1 text-[26px] font-bold leading-tight text-ink">
          {user.dialectCode === "kipsigis" || user.dialectCode === "nandi" ? "Chamgei" : "Welcome back"},{" "}
          {user.username.split("_")[0]} <span aria-hidden="true">👋</span>
        </h1>
        <p className="mt-1 text-sm text-muted">
          Learning <strong className="font-semibold text-ink">{user.dialectName ?? "Kalenjin"}</strong> · {reviewLabel}
        </p>
      </section>

      <Card className="overflow-hidden fade-up">
        <div className="relative">
          <Image
            src="/images/hero.png"
            alt="Kalenjin highlands illustration"
            width={1080}
            height={620}
            priority
            className="h-36 w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[color:var(--surface)] via-[color:var(--surface)]/10 to-transparent" />
          <div className="absolute right-3 top-3">
            <span className="chip border-transparent bg-[color:var(--surface)]/90 backdrop-blur">
              <Icon name="flame" size={12} className="text-[color:var(--clay)]" /> {user.streak}-day streak
            </span>
          </div>
        </div>
        <div className="-mt-6 px-4 pb-4">
          <div className="flex items-center gap-4">
            <ProgressRing value={goalPercent} size={82}>
              <span className="display text-lg font-bold text-ink">{minutesToday}</span>
              <span className="text-[9px] font-semibold uppercase text-muted">of {goal} min</span>
            </ProgressRing>
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold uppercase tracking-wide text-[var(--gold)]">Daily goal</p>
              <h2 className="display truncate text-base font-semibold text-ink">
                {goalPercent >= 100 ? "Goal complete — da kogoi!" : `${goal - minutesToday} minutes to your goal`}
              </h2>
              <p className="mt-0.5 text-xs text-muted">
                {data.completedLessons} of {data.totals.lessons} lessons complete · {data.learnedWords} words learned
              </p>
              <Link href={lesson ? `/learn/${lesson.slug}` : "/learn"} className="btn btn-primary mt-2 w-full">
                <Icon name="play" size={14} filled />
                {lesson ? `Continue: ${lesson.title}` : "Review a lesson"}
              </Link>
            </div>
          </div>
        </div>
      </Card>

      <section>
        <div className="grid grid-cols-3 gap-2">
          <Stat label="Total XP" value={user.xp} icon="star" hint={data.level.title} />
          <Stat label="Streak" value={`${user.streak}d`} icon="flame" hint="Keep it alive" />
          <Stat label="Lessons" value={`${data.completedLessons}/${data.totals.lessons}`} icon="book" />
        </div>
        <div className="mt-2 flex items-center gap-2 rounded-2xl border border-line bg-surface px-3 py-2">
          <span className="text-[10px] font-bold uppercase tracking-wide text-muted">Next rank</span>
          <ProgressBar value={data.level.progress} className="flex-1" />
          <span className="text-[10px] font-semibold text-muted">
            {data.level.nextAt ? `${data.level.nextTitle} · ${data.level.nextAt} XP` : "Top rank"}
          </span>
        </div>
      </section>

      <section>
        <SectionHeading title="Jump back in" subtitle="Everything works with your selected variety" />
        <div className="grid grid-cols-3 gap-2">
          {QUICK_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="card-flat pressable flex flex-col items-center gap-1.5 px-2 py-3 text-center"
            >
              <span
                className={`grid h-9 w-9 place-items-center rounded-full ${
                  link.tone === "brand"
                    ? "bg-[var(--brand)] text-[var(--brand-ink)]"
                    : link.tone === "gold"
                      ? "bg-[var(--gold)] text-[#241703]"
                      : "bg-[var(--surface-muted)] text-[var(--brand)]"
                }`}
              >
                <Icon name={link.icon} size={17} />
              </span>
              <span className="text-[11px] font-semibold leading-tight text-ink">{link.label}</span>
            </Link>
          ))}
        </div>
      </section>

      {data.wordOfDay ? (
        <section>
          <SectionHeading title="Word of the day" href="/dictionary" hrefLabel="Dictionary" />
          <Card className="p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="display text-2xl font-bold text-ink">{data.wordOfDay.word}</p>
                <p className="text-sm text-muted">{data.wordOfDay.definition}</p>
                {data.wordOfDay.pronunciationGuide ? (
                  <p className="mt-1 text-xs text-muted">Say it: {data.wordOfDay.pronunciationGuide}</p>
                ) : null}
              </div>
              <StatusBadge status={data.wordOfDay.verificationStatus} />
            </div>
            <div className="mt-3 flex items-center gap-2">
              <AudioButton text={data.wordOfDay.word} label="Listen" lang="kal" variant="solid" />
              <span className="chip">{data.wordOfDay.category}</span>
              <span className="chip">{user.dialectName}</span>
            </div>
            {data.wordOfDay.verificationNote ? (
              <p className="mt-2 text-[10px] leading-relaxed text-muted">{data.wordOfDay.verificationNote}</p>
            ) : null}
          </Card>
        </section>
      ) : null}

      <section>
        <SectionHeading title="Linguistic integrity" subtitle="What is actually verified for your variety" />
        <Card className="p-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted">Dictionary</p>
              <p className="display text-lg font-semibold text-ink">
                {data.coverage.reviewedWords} reviewed
                <span className="text-xs font-normal text-muted"> / {data.coverage.words}</span>
              </p>
              <ProgressBar
                value={data.coverage.words ? (data.coverage.reviewedWords / data.coverage.words) * 100 : 0}
                className="mt-1"
              />
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted">Phrasebook</p>
              <p className="display text-lg font-semibold text-ink">
                {data.coverage.verifiedPhrases} reviewed
                <span className="text-xs font-normal text-muted"> / {data.coverage.phrases}</span>
              </p>
              <ProgressBar
                value={data.coverage.phrases ? (data.coverage.verifiedPhrases / data.coverage.phrases) * 100 : 0}
                className="mt-1"
              />
            </div>
          </div>
          <InfoNote>
            Entries marked <strong>Needs review</strong> are recognisable study material, not confirmed production
            Kalenjin. The translator flags them and routes uncertain sentences to a native-speaker review queue.
          </InfoNote>
          <Link href="/contribute" className="btn btn-secondary mt-3 w-full">
            <Icon name="plus" size={15} /> Add your voice to the corpus
          </Link>
        </Card>
      </section>

      <section>
        <SectionHeading title="This week" subtitle="Minutes that actually moved your progress" />
        <Card className="p-4">
          <div className="flex items-end justify-between gap-1.5" aria-hidden="true">
            {Array.from({ length: 7 }).map((_, index) => {
              const day = new Date();
              day.setDate(day.getDate() - (6 - index));
              const iso = day.toISOString().slice(0, 10);
              const record = data.weekly.find((row) => row.day === iso);
              const value = record?.minutes ?? 0;
              const height = Math.max(6, Math.min(64, value * 5));
              return (
                <div key={iso} className="flex flex-1 flex-col items-center gap-1">
                  <div className="flex h-16 w-full items-end">
                    <div
                      className="w-full rounded-t-md bg-[var(--brand)]/80"
                      style={{ height: `${height}px` }}
                      title={`${value} minutes`}
                    />
                  </div>
                  <span className="text-[9px] font-semibold text-muted">
                    {day.toLocaleDateString(undefined, { weekday: "narrow" })}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="mt-3 flex items-center justify-between text-xs">
            <span className="text-muted">{data.today?.xpEarned ?? 0} XP earned today</span>
            <Link href="/profile" className="font-semibold text-[var(--brand)]">
              Full progress →
            </Link>
          </div>
        </Card>
      </section>

      {data.translations.length > 0 ? (
        <section>
          <SectionHeading title="Recent translations" href="/translate" hrefLabel="Open translator" />
          <div className="flex flex-col gap-2">
            {data.translations.slice(0, 3).map((item) => (
              <div key={item.id} className="card-flat p-3">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-xs text-muted">{item.sourceText}</p>
                  <StatusBadge status={item.confidenceStatus} />
                </div>
                <p className="mt-0.5 truncate text-sm font-medium text-ink">
                  {item.translatedText ?? "No verified translation"}
                </p>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      <InfoNote tone="warn">
        Live AI translation and the tutor need an internet connection. Downloaded lessons, the phrasebook and saved
        vocabulary work offline — see{" "}
        <Link href="/offline" className="font-semibold underline">
          Offline learning
        </Link>
        .
      </InfoNote>
    </div>
  );
}
