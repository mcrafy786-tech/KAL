import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { getSessionUser } from "@/lib/auth";
import { AppShell } from "@/components/app-shell";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  return (
    <AppShell
      user={{
        username: user.username,
        dialectName: user.dialectName,
        streak: user.streak,
        xp: user.xp,
        role: user.role,
      }}
    >
      {children}
    </AppShell>
  );
}
