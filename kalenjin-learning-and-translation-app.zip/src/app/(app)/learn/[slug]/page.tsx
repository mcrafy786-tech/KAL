import { notFound, redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getDefaultDialectId, getLessonDetail } from "@/lib/data";
import { LessonPlayer } from "@/components/lesson-player";
import { OfflineSave } from "@/components/offline-save";
import { ScreenHeader, StatusBadge } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function LessonPage({ params }: { params: Promise<{ slug: string }> }) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const { slug } = await params;
  const dialectId = user.dialectId ?? (await getDefaultDialectId());
  if (!dialectId) redirect("/onboarding");
  const detail = await getLessonDetail(slug, dialectId, user.id);
  if (!detail) notFound();

  const concepts = detail.concepts.map((concept) => ({
    conceptKey: concept.conceptKey,
    word: concept.word,
    definition: concept.definition,
    status: concept.status,
    pronunciationGuide: concept.pronunciationGuide ?? null,
    note: concept.note ?? null,
  }));

  return (
    <div className="screen">
      <ScreenHeader title={detail.lesson.title} subtitle={detail.lesson.description} backHref="/learn" />
      <div className="mb-3 flex flex-wrap items-center gap-1.5">
        <span className="chip">Level {detail.lesson.level}</span>
        <span className="chip">{user.dialectName}</span>
        <span className="chip">
          {detail.lesson.estimatedMinutes} min · {detail.exercises.length} exercises
        </span>
        <StatusBadge status={detail.lesson.verificationStatus} />
      </div>
      <OfflineSave
        pack={{
          slug: detail.lesson.slug,
          title: detail.lesson.title,
          concepts: detail.concepts.map((concept) => ({
            word: concept.word,
            definition: concept.definition,
            pronunciationGuide: concept.pronunciationGuide ?? null,
            status: concept.status,
          })),
          phrases: detail.phraseRows.map((phrase) => ({ english: phrase.english, kalenjin: phrase.kalenjin })),
          exercises: detail.exercises.length,
        }}
      />
      <LessonPlayer
        slug={detail.lesson.slug}
        title={detail.lesson.title}
        description={detail.lesson.description}
        objectives={detail.lesson.objectives}
        grammarNotes={detail.lesson.grammarNotes}
        concepts={concepts}
        exercises={detail.exercises}
        nextSlug={detail.nextSlug ?? null}
        completedScore={detail.progress?.status === "completed" ? detail.progress.score : null}
      />
    </div>
  );
}
