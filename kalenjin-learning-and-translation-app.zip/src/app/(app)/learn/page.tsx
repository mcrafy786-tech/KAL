import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getDefaultDialectId, getLessonCatalog } from "@/lib/data";
import { levelMeta } from "@/content/lessons";
import { Icon } from "@/components/icons";
import { Card, InfoNote, ProgressBar, ScreenHeader } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata = { title: "Learn" };

export default async function LearnPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const dialectId = user.dialectId ?? (await getDefaultDialectId());
  if (!dialectId) redirect("/onboarding");
  const catalog = await getLessonCatalog(user.id, dialectId);
  const completed = catalog.filter((lesson) => lesson.status === "completed").length;
  const percent = catalog.length ? Math.round((completed / catalog.length) * 100) : 0;

  return (
    <div className="screen">
      <ScreenHeader
        title="Learn Kalenjin"
        subtitle={`Six progressive levels in ${user.dialectName ?? "your variety"}. Lessons unlock in order and stay open for review.`}
      />

      <Card className="mb-4 p-4">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-ink">
            {completed} of {catalog.length} lessons complete
          </span>
          <span className="text-muted">{percent}%</span>
        </div>
        <ProgressBar value={percent} className="mt-2" />
        <div className="mt-3 grid grid-cols-3 gap-2">
          <Link href="/games" className="card-flat pressable flex flex-col items-center gap-1 px-2 py-2.5 text-center">
            <Icon name="game" size={16} className="text-[var(--brand)]" />
            <span className="text-[10px] font-semibold text-ink">Games</span>
          </Link>
          <Link
            href="/practice/pronunciation"
            className="card-flat pressable flex flex-col items-center gap-1 px-2 py-2.5 text-center"
          >
            <Icon name="mic" size={16} className="text-[var(--brand)]" />
            <span className="text-[10px] font-semibold text-ink">Pronunciation</span>
          </Link>
          <Link href="/culture" className="card-flat pressable flex flex-col items-center gap-1 px-2 py-2.5 text-center">
            <Icon name="globe" size={16} className="text-[var(--brand)]" />
            <span className="text-[10px] font-semibold text-ink">Culture</span>
          </Link>
        </div>
      </Card>

      {catalog.length === 0 ? (
        <InfoNote tone="warn">No lessons are available yet. Ask an administrator to seed the curriculum.</InfoNote>
      ) : null}

      <div className="flex flex-col gap-5">
        {levelMeta.map((level) => {
          const lessons = catalog.filter((lesson) => lesson.level === level.level);
          if (lessons.length === 0) return null;
          return (
            <section key={level.level}>
              <div className="mb-2 flex items-end justify-between">
                <div>
                  <h2 className="display text-base font-semibold text-ink">{level.title}</h2>
                  <p className="text-[11px] text-muted">{level.subtitle}</p>
                </div>
                <span className="chip">
                  {lessons.filter((lesson) => lesson.status === "completed").length}/{lessons.length}
                </span>
              </div>
              <div className="flex flex-col gap-2">
                {lessons.map((lesson) => {
                  const locked = lesson.status === "locked";
                  return (
                    <Link
                      key={lesson.slug}
                      href={locked ? "/learn" : `/learn/${lesson.slug}`}
                      aria-disabled={locked}
                      className={`card pressable flex items-start gap-3 p-3.5 ${
                        locked ? "opacity-60" : ""
                      }`}
                    >
                      <span
                        className={`mt-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-full ${
                          lesson.status === "completed"
                            ? "bg-[var(--brand)] text-[var(--brand-ink)]"
                            : locked
                              ? "bg-[var(--surface-muted)] text-muted"
                              : "bg-[var(--gold-soft)] text-[color:var(--clay)]"
                        }`}
                      >
                        <Icon
                          name={
                            lesson.status === "completed" ? "check" : locked ? "lock" : lesson.status === "in_progress" ? "play" : "book"
                          }
                          size={17}
                        />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="display text-sm font-semibold leading-tight text-ink">{lesson.title}</h3>
                          <span className="chip shrink-0">
                            <Icon name="clock" size={10} /> {lesson.estimatedMinutes}m
                          </span>
                        </div>
                        <p className="mt-0.5 line-clamp-2 text-[11px] leading-relaxed text-muted">{lesson.description}</p>
                        <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                          <span className="chip">
                            {lesson.coverage}/{lesson.totalConcepts} concepts available
                          </span>
                          {lesson.status === "completed" ? (
                            <span className="chip border-transparent bg-[var(--brand-soft)] text-[var(--brand)]">
                              Score {lesson.score}%
                            </span>
                          ) : locked ? (
                            <span className="chip">Complete the previous lesson to unlock</span>
                          ) : (
                            <span className="chip border-[var(--brand)] text-[var(--brand)]">
                              <Icon name="arrowRight" size={10} /> Start
                            </span>
                          )}
                        </div>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>

      <div className="mt-5">
        <InfoNote>
          Exercises are generated from your selected variety&apos;s entries. If a concept is missing for your variety the
          exercise is skipped rather than borrowed from another dialect — coverage numbers show exactly what is
          available.
        </InfoNote>
      </div>
    </div>
  );
}
