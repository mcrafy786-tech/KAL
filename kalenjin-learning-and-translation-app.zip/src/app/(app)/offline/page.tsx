import Link from "next/link";
import { OfflineManager } from "@/components/offline-manager";
import { ScreenHeader } from "@/components/ui";
import { Icon } from "@/components/icons";

export const metadata = { title: "Offline learning" };

export default function OfflinePage() {
  return (
    <div className="screen">
      <ScreenHeader
        title="Offline learning"
        subtitle="What still works without a connection — and what honestly does not."
        backHref="/profile"
      />
      <OfflineManager />
      <div className="card mt-4 p-4">
        <p className="flex items-center gap-1.5 text-xs font-bold text-ink">
          <Icon name="info" size={14} className="text-[var(--brand)]" /> Needs a connection
        </p>
        <ul className="mt-1.5 space-y-1 text-[11px] text-muted">
          <li>• Live Translator (server corpus matching + optional AI proposal)</li>
          <li>• AI tutor replies</li>
          <li>• Saving lesson progress, game scores and favourites to your account</li>
          <li>• Recording submissions and the admin review queue</li>
        </ul>
        <p className="mt-2 text-[11px] text-muted">
          Full offline voice translation is not claimed. It would require an on-device Kalenjin acoustic and translation
          model that is not integrated. When that changes, this page will say so explicitly.
        </p>
        <Link href="/learn" className="btn btn-secondary mt-3 w-full">
          <Icon name="download" size={15} /> Download a lesson pack
        </Link>
      </div>
    </div>
  );
}
