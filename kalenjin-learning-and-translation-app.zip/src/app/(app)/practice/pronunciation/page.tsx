import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getDefaultDialectId, getVocabularyRows } from "@/lib/data";
import { PronunciationTrainer } from "@/components/pronunciation-trainer";
import { ScreenHeader } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata = { title: "Pronunciation" };

export default async function PronunciationPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const dialectId = user.dialectId ?? (await getDefaultDialectId());
  if (!dialectId) redirect("/onboarding");
  const rows = await getVocabularyRows(dialectId);

  return (
    <div className="screen">
      <ScreenHeader
        title="Pronunciation trainer"
        subtitle={`Listen, record and compare in ${user.dialectName ?? "your variety"}. No misleading scores.`}
        backHref="/learn"
      />
      <PronunciationTrainer
        dialectName={user.dialectName ?? "Kalenjin"}
        words={rows.map((row) => ({
          word: row.word,
          definition: row.definition,
          pronunciationGuide: row.pronunciationGuide,
          verificationStatus: row.verificationStatus,
          verificationNote: row.verificationNote,
        }))}
      />
    </div>
  );
}
