import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getDefaultDialectId, getProgressOverview, loadDialects } from "@/lib/data";
import { ProfileClient } from "@/components/profile-client";
import { Icon } from "@/components/icons";
import { Card, InfoNote, ProgressBar, ProgressRing, ScreenHeader, Stat } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata = { title: "Profile & progress" };

export default async function ProfilePage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const [dialects, overview] = await Promise.all([loadDialects(), getProgressOverview(user)]);
  await getDefaultDialectId();
  const weekTotal = overview.activity.slice(0, 7).reduce((sum, row) => sum + row.minutes, 0);

  return (
    <div className="screen">
      <ScreenHeader title="Your progress" subtitle={`${user.dialectName ?? "Kalenjin"} · goal ${user.dailyGoalMinutes} min/day`} />

      <Card className="mb-3 p-4">
        <div className="flex items-center gap-4">
          <ProgressRing value={overview.level.progress} size={96} stroke={9}>
            <span className="display text-lg font-bold text-ink">{user.xp}</span>
            <span className="text-[9px] font-semibold uppercase text-muted">XP</span>
          </ProgressRing>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] font-bold uppercase tracking-wide text-[var(--gold)]">{overview.level.title}</p>
            <h2 className="display text-base font-semibold text-ink">
              {overview.level.nextAt ? `Next: ${overview.level.nextTitle}` : "Highest rank reached"}
            </h2>
            <ProgressBar value={overview.level.progress} className="mt-1" />
            <p className="mt-1 text-[11px] text-muted">
              {user.streak}-day streak · {weekTotal} minutes this week · {overview.totalXp} XP logged recently
            </p>
          </div>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2">
          <Stat label="Lessons" value={overview.completedLessons.length} icon="book" />
          <Stat label="Words" value={overview.vocab.length} icon="search" />
          <Stat label="Translations" value={overview.translations} icon="translate" />
        </div>
      </Card>

      <Card className="mb-3 p-4">
        <h2 className="display text-sm font-semibold text-ink">Last two weeks</h2>
        <div className="mt-2 flex items-end justify-between gap-1" aria-hidden="true">
          {overview.activity
            .slice()
            .reverse()
            .slice(-14)
            .map((row) => {
              const height = Math.max(5, Math.min(56, row.minutes * 5));
              return (
                <div key={row.day} className="flex flex-1 flex-col items-center gap-1">
                  <div className="flex h-14 w-full items-end">
                    <div className="w-full rounded-t bg-[var(--brand)]/80" style={{ height: `${height}px` }} />
                  </div>
                  <span className="text-[8px] text-muted">{row.day.slice(8)}</span>
                </div>
              );
            })}
        </div>
        {overview.activity.length === 0 ? (
          <p className="mt-2 text-xs text-muted">No practice logged yet. Finish a lesson to start your chart.</p>
        ) : null}
      </Card>

      <Card className="mb-3 p-4">
        <h2 className="display text-sm font-semibold text-ink">Achievements</h2>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {overview.achievements.map((achievement) => (
            <div
              key={achievement.type}
              className={`rounded-xl border p-2.5 ${
                achievement.earned ? "border-[var(--brand)] bg-[var(--brand-soft)]/40" : "border-line bg-surface opacity-60"
              }`}
            >
              <p className="text-lg leading-none" aria-hidden="true">
                {achievement.emoji}
              </p>
              <p className="mt-1 text-[11px] font-semibold text-ink">{achievement.title}</p>
              <p className="text-[10px] leading-snug text-muted">{achievement.description}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mb-3 p-4">
        <div className="flex items-center justify-between">
          <h2 className="display text-sm font-semibold text-ink">Completed lessons</h2>
          <Link href="/learn" className="chip pressable">
            Curriculum <Icon name="arrowRight" size={11} />
          </Link>
        </div>
        {overview.completedLessons.length === 0 ? (
          <p className="mt-2 text-xs text-muted">No completed lessons yet — your first one is waiting.</p>
        ) : (
          <ul className="mt-2 divide-y divide-[var(--line)]">
            {overview.completedLessons.slice(0, 6).map((lesson) => (
              <li key={lesson.slug} className="flex items-center justify-between gap-2 py-2">
                <div className="min-w-0">
                  <p className="truncate text-xs font-semibold text-ink">{lesson.title}</p>
                  <p className="text-[10px] text-muted">
                    Level {lesson.level}
                    {lesson.completedAt ? ` · ${new Date(lesson.completedAt).toLocaleDateString()}` : ""}
                  </p>
                </div>
                <span className="chip border-transparent bg-[var(--brand-soft)] text-[var(--brand)]">{lesson.score}%</span>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card className="mb-3 p-4">
        <h2 className="display text-sm font-semibold text-ink">Recently learned words</h2>
        {overview.vocab.length === 0 ? (
          <p className="mt-1 text-xs text-muted">Words are added here as you complete lessons and review entries.</p>
        ) : (
          <div className="mt-1.5 flex flex-wrap gap-1.5">
            {overview.vocab.slice(0, 14).map((entry) => (
              <span key={entry.word} className="chip">
                {entry.word} <span className="text-[9px] text-muted">· {entry.definition.slice(0, 18)}</span>
              </span>
            ))}
          </div>
        )}
      </Card>

      {overview.games.length > 0 ? (
        <Card className="mb-3 p-4">
          <h2 className="display text-sm font-semibold text-ink">Game results</h2>
          <ul className="mt-1.5 divide-y divide-[var(--line)]">
            {overview.games.slice(0, 5).map((game) => (
              <li key={game.id} className="flex items-center justify-between py-1.5 text-xs">
                <span className="capitalize text-ink">{game.gameType}</span>
                <span className="text-muted">
                  {game.score}% · {new Date(game.createdAt).toLocaleDateString()}
                </span>
              </li>
            ))}
          </ul>
        </Card>
      ) : null}

      <div className="mb-3 grid grid-cols-2 gap-2">
        <Link href="/offline" className="card-flat pressable flex items-center gap-2 p-3">
          <Icon name="download" size={16} className="text-[var(--brand)]" />
          <span className="text-xs font-semibold text-ink">Offline packs</span>
        </Link>
        <Link href="/contribute" className="card-flat pressable flex items-center gap-2 p-3">
          <Icon name="users" size={16} className="text-[var(--brand)]" />
          <span className="text-xs font-semibold text-ink">Contribute</span>
        </Link>
      </div>

      {user.role === "admin" ? (
        <Link href="/admin" className="card-flat pressable mb-3 flex items-center gap-2 p-3">
          <Icon name="shield" size={16} className="text-[var(--brand)]" />
          <span className="text-xs font-semibold text-ink">Open language admin</span>
          <Icon name="arrowRight" size={14} className="ml-auto text-muted" />
        </Link>
      ) : null}

      <ProfileClient
        user={{
          username: user.username,
          email: user.email,
          role: user.role,
          dialectCode: user.dialectCode,
          proficiencyLevel: user.proficiencyLevel,
          dailyGoalMinutes: user.dailyGoalMinutes,
          preferredLanguage: user.preferredLanguage,
          theme: user.theme,
        }}
        dialects={dialects.map((dialect) => ({ id: dialect.id, code: dialect.code, name: dialect.name }))}
      />

      <div className="mt-3">
        <InfoNote>
          Progress rewards completed lessons, reviews, games and translations. Streaks break if a day has no activity —
          opening the app alone does not count.
        </InfoNote>
      </div>
    </div>
  );
}
