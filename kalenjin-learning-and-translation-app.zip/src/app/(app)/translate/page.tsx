import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getDefaultDialectId, getDialectById, getHistory, getPhraseRows } from "@/lib/data";
import { Translator } from "@/components/translator";
import { ScreenHeader } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata = { title: "Live Translator" };

export default async function TranslatePage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const dialectId = user.dialectId ?? (await getDefaultDialectId());
  if (!dialectId) redirect("/onboarding");
  const [dialect, history, phraseRows] = await Promise.all([
    getDialectById(dialectId),
    getHistory(user.id, 40),
    getPhraseRows(dialectId),
  ]);

  return (
    <div className="screen">
      <ScreenHeader
        title="Live translator"
        subtitle="English ↔ Kalenjin voice, phrase and text translation with honest confidence labels."
      />
      <Translator
        dialectName={dialect?.name ?? "Kalenjin"}
        dialectCode={dialect?.code ?? "kipsigis"}
        history={history.map((item) => ({
          id: item.id,
          sourceText: item.sourceText,
          translatedText: item.translatedText,
          sourceLanguage: item.sourceLanguage,
          targetLanguage: item.targetLanguage,
          confidenceStatus: item.confidenceStatus,
          confidenceScore: item.confidenceScore,
          mode: item.mode,
          createdAt: item.createdAt.toISOString(),
        }))}
        phrasebook={phraseRows.map((row) => ({
          english: row.english,
          kalenjin: row.kalenjin,
          status: row.verificationStatus,
          category: row.category,
        }))}
      />
    </div>
  );
}
