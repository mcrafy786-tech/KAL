import { redirect } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { tutorMessages } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { TutorChat } from "@/components/tutor-chat";
import { ScreenHeader } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata = { title: "AI Tutor" };

export default async function TutorPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const rows = await db
    .select()
    .from(tutorMessages)
    .where(eq(tutorMessages.userId, user.id))
    .orderBy(asc(tutorMessages.createdAt))
    .limit(40);

  return (
    <div className="screen">
      <ScreenHeader
        title="AI Kalenjin tutor"
        subtitle={`Grounded in the reviewed ${user.dialectName ?? "Kalenjin"} corpus and your proficiency level.`}
      />
      <TutorChat
        dialectName={user.dialectName ?? "Kalenjin"}
        initialMessages={rows.map((row) => ({
          id: String(row.id),
          role: row.role === "user" ? "user" : "assistant",
          content: row.content,
        }))}
      />
    </div>
  );
}
