import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { contributions, dialects, phrases, recordings, vocabulary } from "@/db/schema";
import { getSessionUser, sameOrigin } from "@/lib/auth";
import { normalizeText } from "@/lib/text";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ ok: false, error: "Invalid origin" }, { status: 403 });
  const user = await getSessionUser();
  if (!user || user.role !== "admin") {
    return Response.json({ ok: false, error: "Administrator access required." }, { status: 403 });
  }

  let body: {
    action?: string;
    id?: number;
    reviewNote?: string;
    dialectId?: number;
    word?: string;
    definition?: string;
    category?: string;
    english?: string;
    kalenjin?: string;
    note?: string;
    pronunciationGuide?: string;
    verificationStatus?: string;
    speakerName?: string;
    audioUrl?: string;
    vocabularyId?: number;
    reviewStatus?: string;
    consentStatus?: string;
    code?: string;
    name?: string;
    region?: string;
    description?: string;
    nativeName?: string;
  };
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request body" }, { status: 400 });
  }

  const action = body.action;

  try {
    if (action === "review_contribution" || action === "approve" || action === "reject") {
      if (!body.id) return Response.json({ ok: false, error: "Contribution id required." }, { status: 400 });
      const [contribution] = await db.select().from(contributions).where(eq(contributions.id, body.id)).limit(1);
      if (!contribution) return Response.json({ ok: false, error: "Contribution not found." }, { status: 404 });
      const approve = action !== "reject";

      await db
        .update(contributions)
        .set({
          status: approve ? "approved" : "rejected",
          reviewerId: user.id,
          reviewNote: body.reviewNote?.slice(0, 600) ?? null,
          reviewedAt: new Date(),
        })
        .where(eq(contributions.id, contribution.id));

      let published: string | null = null;
      if (approve && contribution.dialectId) {
        const payload = contribution.payload ?? {};
        if (contribution.type === "vocabulary" && payload.word) {
          await db
            .insert(vocabulary)
            .values({
              dialectId: contribution.dialectId,
              conceptKey: `community.${randomUUID().slice(0, 8)}`,
              word: payload.word,
              normalized: normalizeText(payload.word),
              definition: payload.definition ?? "Community submission",
              category: payload.category ?? "community",
              pronunciationGuide: payload.pronunciation ?? null,
              verificationStatus: "community",
              verificationNote: `Approved community submission${body.reviewNote ? `: ${body.reviewNote}` : ""}`,
            })
            .onConflictDoNothing();
          published = "vocabulary";
        } else if ((contribution.type === "correction" || contribution.type === "example") && payload.kalenjin) {
          await db
            .insert(phrases)
            .values({
              dialectId: contribution.dialectId,
              conceptKey: `community.phrase.${randomUUID().slice(0, 8)}`,
              english: payload.english ?? "Community phrase",
              kalenjin: payload.kalenjin,
              normalizedEnglish: normalizeText(payload.english ?? ""),
              normalizedKalenjin: normalizeText(payload.kalenjin),
              category: "community",
              verificationStatus: "community",
              verificationNote: body.reviewNote ?? "Approved community submission",
            })
            .onConflictDoNothing();
          published = "phrase";
        }
      }
      return Response.json({ ok: true, published });
    }

    if (action === "add_vocabulary") {
      if (!body.dialectId || !body.word || !body.definition) {
        return Response.json({ ok: false, error: "Variety, word and definition are required." }, { status: 400 });
      }
      await db.insert(vocabulary).values({
        dialectId: body.dialectId,
        conceptKey: `admin.${randomUUID().slice(0, 8)}`,
        word: body.word.trim().slice(0, 120),
        normalized: normalizeText(body.word),
        definition: body.definition.trim().slice(0, 240),
        category: body.category?.trim() || "general",
        pronunciationGuide: body.pronunciationGuide?.slice(0, 120) ?? null,
        verificationStatus: body.verificationStatus === "verified" ? "verified" : "needs_review",
        verificationNote: body.note?.slice(0, 400) ?? "Added by an administrator; review log records reviewer.",
      });
      return Response.json({ ok: true });
    }

    if (action === "update_vocabulary") {
      if (!body.id) return Response.json({ ok: false, error: "Vocabulary id required." }, { status: 400 });
      const update: Record<string, unknown> = {};
      if (body.definition) update.definition = body.definition.slice(0, 240);
      if (body.verificationStatus === "verified" || body.verificationStatus === "needs_review") {
        update.verificationStatus = body.verificationStatus;
      }
      if (body.note) update.verificationNote = body.note.slice(0, 400);
      if (Object.keys(update).length === 0) {
        return Response.json({ ok: false, error: "Nothing to update." }, { status: 400 });
      }
      await db.update(vocabulary).set(update).where(eq(vocabulary.id, body.id));
      return Response.json({ ok: true });
    }

    if (action === "add_phrase") {
      if (!body.dialectId || !body.english || !body.kalenjin) {
        return Response.json({ ok: false, error: "Variety, English and Kalenjin are required." }, { status: 400 });
      }
      await db.insert(phrases).values({
        dialectId: body.dialectId,
        conceptKey: `admin.phrase.${randomUUID().slice(0, 8)}`,
        english: body.english.slice(0, 300),
        kalenjin: body.kalenjin.slice(0, 300),
        normalizedEnglish: normalizeText(body.english),
        normalizedKalenjin: normalizeText(body.kalenjin),
        category: body.category?.trim() || "general",
        verificationStatus: body.verificationStatus === "verified" ? "verified" : "needs_review",
        verificationNote: body.note?.slice(0, 400) ?? "Added by an administrator.",
      });
      return Response.json({ ok: true });
    }

    if (action === "add_recording") {
      if (!body.speakerName || !body.audioUrl) {
        return Response.json({ ok: false, error: "Speaker name and audio URL are required." }, { status: 400 });
      }
      await db.insert(recordings).values({
        dialectId: body.dialectId ?? null,
        vocabularyId: body.vocabularyId ?? null,
        contributorId: user.id,
        speakerName: body.speakerName.slice(0, 120),
        consentStatus: body.consentStatus === "granted" ? "granted" : "pending",
        audioUrl: body.audioUrl.slice(0, 600),
        reviewStatus: "pending",
        note: body.note?.slice(0, 400) ?? null,
      });
      return Response.json({ ok: true });
    }

    if (action === "review_recording") {
      if (!body.id) return Response.json({ ok: false, error: "Recording id required." }, { status: 400 });
      await db
        .update(recordings)
        .set({
          reviewStatus: body.reviewStatus === "approved" ? "approved" : "rejected",
          note: body.note?.slice(0, 400) ?? null,
        })
        .where(eq(recordings.id, body.id));
      return Response.json({ ok: true });
    }

    if (action === "add_dialect") {
      if (!body.code || !body.name || !body.region) {
        return Response.json({ ok: false, error: "Code, name and region are required." }, { status: 400 });
      }
      await db
        .insert(dialects)
        .values({
          code: body.code.toLowerCase().replace(/[^a-z0-9_-]/g, ""),
          name: body.name,
          nativeName: body.nativeName ?? body.name,
          description: body.description ?? "Community-added variety. Pending editorial review.",
          region: body.region,
          sortOrder: 99,
        })
        .onConflictDoNothing();
      return Response.json({ ok: true });
    }

    return Response.json({ ok: false, error: "Unknown admin action." }, { status: 400 });
  } catch {
    return Response.json({ ok: false, error: "The admin action could not be completed." }, { status: 500 });
  }
}
