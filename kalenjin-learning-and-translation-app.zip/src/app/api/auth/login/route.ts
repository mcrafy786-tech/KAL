import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, sameOrigin, verifyPassword } from "@/lib/auth";
import { ensureSeeded } from "@/db/seed";

const DEMO_ACCOUNTS = {
  learner: "demo@kalenjin.app",
  admin: "admin@kalenjin.app",
  contributor: "contributor@kalenjin.app",
} as const;

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ ok: false, error: "Invalid origin" }, { status: 403 });
  await ensureSeeded();
  let body: { email?: string; password?: string; demo?: keyof typeof DEMO_ACCOUNTS };
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request body" }, { status: 400 });
  }

  let email = (body.email ?? "").trim().toLowerCase();
  let password = body.password ?? "";

  if (body.demo) {
    email = DEMO_ACCOUNTS[body.demo] ?? DEMO_ACCOUNTS.learner;
    password = body.demo === "learner" ? "demo1234" : body.demo === "admin" ? "Kalenjin2026!" : "contributor1234";
  }

  if (!email || !password) {
    return Response.json({ ok: false, error: "Email and password are required." }, { status: 400 });
  }

  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return Response.json({ ok: false, error: "Email or password is incorrect." }, { status: 401 });
  }

  await createSession(user.id);
  return Response.json({
    ok: true,
    user: { id: user.id, username: user.username, role: user.role, onboarded: user.onboarded },
    next: user.onboarded ? "/home" : "/onboarding",
  });
}
