import { eq, or } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, hashPassword, sameOrigin } from "@/lib/auth";
import { ensureSeeded } from "@/db/seed";
import { getDefaultDialectId } from "@/lib/data";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ ok: false, error: "Invalid origin" }, { status: 403 });
  await ensureSeeded();
  let body: { username?: string; email?: string; password?: string };
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request body" }, { status: 400 });
  }

  const username = (body.username ?? "").trim();
  const email = (body.email ?? "").trim().toLowerCase();
  const password = body.password ?? "";

  if (username.length < 3) return Response.json({ ok: false, error: "Username must be at least 3 characters." }, { status: 400 });
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return Response.json({ ok: false, error: "Enter a valid email address." }, { status: 400 });
  }
  if (password.length < 8) return Response.json({ ok: false, error: "Password must be at least 8 characters." }, { status: 400 });

  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(or(eq(users.email, email), eq(users.username, username)))
    .limit(1);
  if (existing.length > 0) {
    return Response.json({ ok: false, error: "That username or email is already registered." }, { status: 409 });
  }

  const dialectId = await getDefaultDialectId();
  const [created] = await db
    .insert(users)
    .values({
      username,
      email,
      passwordHash: hashPassword(password),
      role: "learner",
      dialectId,
      onboarded: false,
    })
    .returning({ id: users.id, username: users.username, email: users.email, onboarded: users.onboarded });

  await createSession(created.id);
  return Response.json({ ok: true, user: created, next: "/onboarding" });
}
