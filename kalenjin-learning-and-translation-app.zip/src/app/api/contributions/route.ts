import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { contributions, dialects } from "@/db/schema";
import { getSessionUser, sameOrigin } from "@/lib/auth";
import { awardAchievements } from "@/lib/gamification";

const TYPES = ["vocabulary", "correction", "recording", "example", "cultural"];

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false, error: "Sign in required." }, { status: 401 });
  const rows = await db
    .select()
    .from(contributions)
    .where(eq(contributions.userId, user.id))
    .orderBy(desc(contributions.createdAt))
    .limit(30);
  return Response.json({ ok: true, contributions: rows });
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ ok: false, error: "Invalid origin" }, { status: 403 });
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false, error: "Sign in required." }, { status: 401 });

  let body: {
    type?: string;
    dialectCode?: string;
    payload?: Record<string, string>;
    consent?: boolean;
  };
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request body" }, { status: 400 });
  }

  const type = body.type ?? "";
  if (!TYPES.includes(type)) return Response.json({ ok: false, error: "Unknown contribution type." }, { status: 400 });

  const payload: Record<string, string> = {};
  Object.entries(body.payload ?? {}).forEach(([key, value]) => {
    if (typeof value === "string" && value.trim()) payload[key.slice(0, 40)] = value.trim().slice(0, 1200);
  });
  if (Object.keys(payload).length === 0) {
    return Response.json({ ok: false, error: "Add some content to submit." }, { status: 400 });
  }

  let dialectId = user.dialectId;
  if (body.dialectCode) {
    const [dialect] = await db.select().from(dialects).where(eq(dialects.code, body.dialectCode)).limit(1);
    if (!dialect) return Response.json({ ok: false, error: "Unknown Kalenjin variety." }, { status: 400 });
    dialectId = dialect.id;
  }

  const needsConsent = type === "recording";
  const consent = Boolean(body.consent);
  if (needsConsent && !consent) {
    return Response.json(
      { ok: false, error: "Speaker consent is required before a recording can be submitted." },
      { status: 400 },
    );
  }

  const [created] = await db
    .insert(contributions)
    .values({ userId: user.id, type, dialectId, payload, consent, status: "pending" })
    .returning();

  await awardAchievements(user.id, ["contributor"]);
  return Response.json({ ok: true, contribution: created });
}
