import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { favorites } from "@/db/schema";
import { getSessionUser, sameOrigin } from "@/lib/auth";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ ok: false, error: "Invalid origin" }, { status: 403 });
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false, error: "Sign in required." }, { status: 401 });

  let body: { vocabularyId?: number };
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request body" }, { status: 400 });
  }
  const vocabularyId = Number(body.vocabularyId);
  if (!Number.isInteger(vocabularyId)) {
    return Response.json({ ok: false, error: "Invalid vocabulary entry." }, { status: 400 });
  }

  const [existing] = await db
    .select()
    .from(favorites)
    .where(and(eq(favorites.userId, user.id), eq(favorites.vocabularyId, vocabularyId)))
    .limit(1);

  if (existing) {
    await db.delete(favorites).where(eq(favorites.id, existing.id));
    return Response.json({ ok: true, favorite: false });
  }

  await db.insert(favorites).values({ userId: user.id, vocabularyId });
  return Response.json({ ok: true, favorite: true });
}
