import { db } from "@/db";
import { gameScores } from "@/db/schema";
import { getSessionUser, sameOrigin } from "@/lib/auth";
import { awardAchievements, recordActivity } from "@/lib/gamification";

const ALLOWED_GAMES = ["match", "build", "listen", "quiz", "memory", "missing"];

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ ok: false, error: "Invalid origin" }, { status: 403 });
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false, error: "Sign in required." }, { status: 401 });

  let body: { gameType?: string; score?: number; total?: number };
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request body" }, { status: 400 });
  }

  const gameType = body.gameType ?? "";
  const score = Math.max(0, Math.min(100, Math.round(Number(body.score ?? 0))));
  const total = Math.max(1, Math.min(50, Math.round(Number(body.total ?? 1))));

  if (!ALLOWED_GAMES.includes(gameType)) {
    return Response.json({ ok: false, error: "Unknown game." }, { status: 400 });
  }

  await db.insert(gameScores).values({
    userId: user.id,
    gameType,
    dialectId: user.dialectId,
    score,
    total,
  });

  const xpEarned = 5 + Math.round(score / 12);
  await recordActivity(user.id, { xp: xpEarned, minutes: 3, reviews: total });
  const achievements = await awardAchievements(user.id, score === 100 ? ["game_perfect"] : []);

  return Response.json({ ok: true, xpEarned, achievements });
}
