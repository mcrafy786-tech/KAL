import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { lessons, userProgress } from "@/db/schema";
import { getSessionUser, sameOrigin } from "@/lib/auth";
import { getDefaultDialectId, getVocabularyRows, getPhraseRows, contentEntries, phraseEntries } from "@/lib/data";
import { gradeExercises, materializeExercises, type SubmittedAnswer } from "@/lib/exercises";
import type { ExerciseTemplate } from "@/content/lessons";
import { awardAchievements, pairVocabulary, recordActivity } from "@/lib/gamification";

export async function POST(request: Request, { params }: { params: Promise<{ slug: string }> }) {
  if (!sameOrigin(request)) return Response.json({ ok: false, error: "Invalid origin" }, { status: 403 });
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false, error: "Sign in required." }, { status: 401 });

  const { slug } = await params;
  let body: { answers?: Record<string, SubmittedAnswer> };
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request body" }, { status: 400 });
  }

  const [lesson] = await db.select().from(lessons).where(eq(lessons.slug, slug)).limit(1);
  if (!lesson) return Response.json({ ok: false, error: "Lesson not found." }, { status: 404 });

  const dialectId = user.dialectId ?? (await getDefaultDialectId());
  if (!dialectId) return Response.json({ ok: false, error: "Choose a Kalenjin variety first." }, { status: 400 });

  const [vocabRows, phraseRows] = await Promise.all([getVocabularyRows(dialectId), getPhraseRows(dialectId)]);
  const vocabularyMap = contentEntries(vocabRows);
  const phraseMap = phraseEntries(phraseRows);
  const exercises = materializeExercises((lesson.exercises as ExerciseTemplate[]) ?? [], vocabularyMap, phraseMap);

  if (exercises.length === 0) {
    return Response.json(
      {
        ok: false,
        error:
          "This lesson has no exercises available for your selected variety yet. Choose another lesson or contribute the missing vocabulary.",
      },
      { status: 409 },
    );
  }

  const answers = body.answers ?? {};
  const graded = gradeExercises(exercises, answers);

  const [existing] = await db
    .select()
    .from(userProgress)
    .where(and(eq(userProgress.userId, user.id), eq(userProgress.lessonId, lesson.id)))
    .limit(1);
  const alreadyCompleted = existing?.status === "completed";
  const baseXp = 15 + Math.round(graded.score / 10);
  const xpEarned = alreadyCompleted ? Math.max(3, Math.round(baseXp / 3)) : baseXp;

  if (existing) {
    await db
      .update(userProgress)
      .set({
        status: "completed",
        score: Math.max(existing.score, graded.score),
        attempts: existing.attempts + 1,
        completedAt: existing.completedAt ?? new Date(),
        updatedAt: new Date(),
      })
      .where(eq(userProgress.id, existing.id));
  } else {
    await db.insert(userProgress).values({
      userId: user.id,
      lessonId: lesson.id,
      status: "completed",
      score: graded.score,
      attempts: 1,
      completedAt: new Date(),
    });
  }

  const vocabularyIds = lesson.conceptKeys
    .map((key) => vocabRows.find((row) => row.conceptKey === key)?.id)
    .filter((id): id is number => typeof id === "number");
  await pairVocabulary(user.id, vocabularyIds);
  await recordActivity(user.id, {
    xp: xpEarned,
    minutes: lesson.estimatedMinutes,
    lessonsCompleted: alreadyCompleted ? 0 : 1,
    reviews: exercises.length,
  });
  const earned = await awardAchievements(user.id, graded.score === 100 ? ["perfect_lesson"] : []);

  return Response.json({
    ok: true,
    score: graded.score,
    results: graded.results,
    xpEarned,
    achievements: earned,
    alreadyCompleted,
  });
}
