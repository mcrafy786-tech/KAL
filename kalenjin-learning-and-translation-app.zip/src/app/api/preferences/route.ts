import { eq } from "drizzle-orm";
import { db } from "@/db";
import { dialects, users } from "@/db/schema";
import { getSessionUser, sameOrigin } from "@/lib/auth";

const PROFICIENCY = ["beginner", "elementary", "intermediate", "upper_intermediate", "advanced"];
const LANGUAGES = ["en", "sw"];

export async function PATCH(request: Request) {
  if (!sameOrigin(request)) return Response.json({ ok: false, error: "Invalid origin" }, { status: 403 });
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false, error: "Sign in required." }, { status: 401 });

  let body: {
    dialectCode?: string;
    proficiencyLevel?: string;
    dailyGoalMinutes?: number;
    preferredLanguage?: string;
    theme?: string;
    onboarded?: boolean;
    username?: string;
  };
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request body" }, { status: 400 });
  }

  const update: Record<string, unknown> = {};

  if (body.dialectCode) {
    const [dialect] = await db.select().from(dialects).where(eq(dialects.code, body.dialectCode)).limit(1);
    if (!dialect) return Response.json({ ok: false, error: "Unknown Kalenjin variety." }, { status: 400 });
    update.dialectId = dialect.id;
  }
  if (body.proficiencyLevel) {
    if (!PROFICIENCY.includes(body.proficiencyLevel)) {
      return Response.json({ ok: false, error: "Unknown proficiency level." }, { status: 400 });
    }
    update.proficiencyLevel = body.proficiencyLevel;
  }
  if (typeof body.dailyGoalMinutes === "number") {
    const minutes = Math.max(5, Math.min(60, Math.round(body.dailyGoalMinutes)));
    update.dailyGoalMinutes = minutes;
  }
  if (body.preferredLanguage) {
    if (!LANGUAGES.includes(body.preferredLanguage)) {
      return Response.json({ ok: false, error: "Unsupported interface language." }, { status: 400 });
    }
    update.preferredLanguage = body.preferredLanguage;
  }
  if (body.theme === "light" || body.theme === "dark" || body.theme === "system") {
    update.theme = body.theme;
  }
  if (typeof body.onboarded === "boolean") {
    update.onboarded = body.onboarded;
  }
  if (typeof body.username === "string" && body.username.trim().length >= 3) {
    update.username = body.username.trim();
  }

  if (Object.keys(update).length === 0) {
    return Response.json({ ok: false, error: "Nothing to update." }, { status: 400 });
  }

  await db.update(users).set(update).where(eq(users.id, user.id));
  return Response.json({ ok: true });
}
