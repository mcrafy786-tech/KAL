import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { translations } from "@/db/schema";
import { getSessionUser, sameOrigin } from "@/lib/auth";
import { getDefaultDialectId } from "@/lib/data";
import { translateSentence, type Direction } from "@/lib/translate";
import { awardAchievements, recordActivity } from "@/lib/gamification";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false, error: "Sign in required." }, { status: 401 });
  const rows = await db
    .select()
    .from(translations)
    .where(eq(translations.userId, user.id))
    .orderBy(desc(translations.createdAt))
    .limit(60);
  return Response.json({ ok: true, translations: rows });
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ ok: false, error: "Invalid origin" }, { status: 403 });
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false, error: "Sign in required." }, { status: 401 });

  let body: { text?: string; direction?: Direction; mode?: string };
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request body" }, { status: 400 });
  }

  const text = (body.text ?? "").trim();
  const direction: Direction = body.direction === "kal-en" ? "kal-en" : "en-kal";
  const mode = body.mode === "conversation" ? "conversation" : "text";

  if (!text) return Response.json({ ok: false, error: "Enter or record something to translate." }, { status: 400 });
  if (text.length > 600) return Response.json({ ok: false, error: "Please keep sentences under 600 characters." }, { status: 400 });

  const dialectId = user.dialectId ?? (await getDefaultDialectId());
  if (!dialectId) {
    return Response.json(
      { ok: false, error: "Select your Kalenjin variety in Profile before translating." },
      { status: 400 },
    );
  }

  try {
    const outcome = await translateSentence({ text, direction, dialectId, allowProposal: true });
    const [saved] = await db
      .insert(translations)
      .values({
        userId: user.id,
        sourceText: text,
        translatedText: outcome.translatedText,
        sourceLanguage: direction === "en-kal" ? "en" : outcome.dialectCode,
        targetLanguage: direction === "en-kal" ? outcome.dialectCode : "en",
        dialectId,
        confidenceStatus: outcome.confidence,
        confidenceScore: outcome.score,
        provider: outcome.provider,
        matchedPhraseId: outcome.matchedPhraseId,
        notes: outcome.notes.join(" • "),
        mode,
      })
      .returning();

    await recordActivity(user.id, { reviews: 1 });
    const achievements = await awardAchievements(user.id, []);

    return Response.json({ ok: true, result: outcome, saved, achievements });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : "Translation failed. Try again." },
      { status: 500 },
    );
  }
}

export async function DELETE(request: Request) {
  if (!sameOrigin(request)) return Response.json({ ok: false, error: "Invalid origin" }, { status: 403 });
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false, error: "Sign in required." }, { status: 401 });
  const url = new URL(request.url);
  const mode = url.searchParams.get("mode");
  const id = url.searchParams.get("id");

  if (id) {
    await db
      .delete(translations)
      .where(and(eq(translations.userId, user.id), eq(translations.id, Number(id))));
    return Response.json({ ok: true });
  }

  if (mode === "conversation") {
    await db
      .delete(translations)
      .where(and(eq(translations.userId, user.id), eq(translations.mode, "conversation")));
    return Response.json({ ok: true });
  }

  await db.delete(translations).where(eq(translations.userId, user.id));
  return Response.json({ ok: true });
}
