import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { tutorMessages } from "@/db/schema";
import { getSessionUser, sameOrigin } from "@/lib/auth";
import { getDefaultDialectId } from "@/lib/data";
import { tutorReply } from "@/lib/tutor";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false, error: "Sign in required." }, { status: 401 });
  const rows = await db
    .select()
    .from(tutorMessages)
    .where(eq(tutorMessages.userId, user.id))
    .orderBy(asc(tutorMessages.createdAt))
    .limit(60);
  return Response.json({ ok: true, messages: rows });
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ ok: false, error: "Invalid origin" }, { status: 403 });
  const user = await getSessionUser();
  if (!user) return Response.json({ ok: false, error: "Sign in required." }, { status: 401 });

  let body: { message?: string };
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request body" }, { status: 400 });
  }
  const message = (body.message ?? "").trim().slice(0, 500);
  if (!message) return Response.json({ ok: false, error: "Type a question for your tutor." }, { status: 400 });

  const dialectId = user.dialectId ?? (await getDefaultDialectId());
  if (!dialectId) return Response.json({ ok: false, error: "Choose a Kalenjin variety first." }, { status: 400 });

  try {
    const reply = await tutorReply({
      message,
      dialectId,
      dialectName: user.dialectName ?? "Kalenjin",
      proficiencyLevel: user.proficiencyLevel,
    });

    await db.insert(tutorMessages).values({
      userId: user.id,
      role: "user",
      content: message,
    });
    await db.insert(tutorMessages).values({
      userId: user.id,
      role: "assistant",
      content: reply.content,
      grounding: reply.grounding,
    });

    return Response.json({ ok: true, reply });
  } catch {
    return Response.json({ ok: false, error: "The tutor could not respond. Try again." }, { status: 500 });
  }
}
