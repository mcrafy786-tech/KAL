"use client";

import Link from "next/link";
import { Icon } from "@/components/icons";
import { Logo } from "@/components/ui";

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="screen flex min-h-dvh flex-col items-center justify-center text-center">
      <Logo size={48} />
      <h1 className="display mt-4 text-xl font-bold text-ink">Something interrupted this screen</h1>
      <p className="mt-1 max-w-xs text-sm text-muted">
        Your saved progress is safe. Try again — if the database is briefly unavailable, the app will reconnect.
      </p>
      <div className="mt-4 flex gap-2">
        <button type="button" onClick={reset} className="btn btn-primary">
          <Icon name="refresh" size={15} /> Try again
        </button>
        <Link href="/home" className="btn btn-outline">
          Home
        </Link>
      </div>
    </div>
  );
}
