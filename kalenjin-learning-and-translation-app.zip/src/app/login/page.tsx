import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { AuthForm } from "@/components/auth-form";
import { Logo } from "@/components/ui";
import { Icon } from "@/components/icons";

export const dynamic = "force-dynamic";
export const metadata = { title: "Sign in" };

export default async function LoginPage() {
  const user = await getSessionUser();
  if (user) redirect(user.onboarded ? "/home" : "/onboarding");
  return (
    <div className="screen !pb-10">
      <div className="mb-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Logo size={32} />
          <span className="display text-base font-bold text-ink">Kalenjin</span>
        </Link>
        <Link href="/" className="chip pressable">
          <Icon name="chevronLeft" size={12} /> Home
        </Link>
      </div>
      <AuthForm mode="login" />
    </div>
  );
}
