import Link from "next/link";
import { Icon } from "@/components/icons";
import { Logo } from "@/components/ui";

export default function NotFound() {
  return (
    <div className="screen flex min-h-dvh flex-col items-center justify-center text-center">
      <Logo size={48} />
      <h1 className="display mt-4 text-2xl font-bold text-ink">This page is not in the corpus</h1>
      <p className="mt-1 max-w-xs text-sm text-muted">
        The screen you followed does not exist. Head back to your dashboard to keep learning.
      </p>
      <Link href="/home" className="btn btn-primary mt-4">
        <Icon name="home" size={15} /> Back to home
      </Link>
    </div>
  );
}
