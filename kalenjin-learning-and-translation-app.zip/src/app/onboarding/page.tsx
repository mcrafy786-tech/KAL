import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { loadDialects } from "@/lib/data";
import { OnboardingForm } from "@/components/onboarding-form";
import { Logo } from "@/components/ui";
import { Icon } from "@/components/icons";

export const dynamic = "force-dynamic";
export const metadata = { title: "Set up your learning" };

export default async function OnboardingPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const dialects = await loadDialects();

  return (
    <div className="screen !pb-10">
      <div className="mb-4 flex items-center gap-2">
        <Logo size={32} />
        <div>
          <p className="display text-base font-bold leading-none text-ink">Kalenjin</p>
          <p className="text-[10px] text-muted">Set up in under a minute</p>
        </div>
      </div>

      <div className="mb-3 flex items-start gap-2 rounded-2xl border border-line bg-surface px-3 py-2">
        <Icon name="info" size={14} className="mt-0.5 shrink-0 text-[var(--brand)]" />
        <p className="text-[10px] leading-relaxed text-muted">
          Hi {user.username}. We ask for your variety up front because Kalenjin is a family of distinct varieties — the
          lessons you see will be built only from your choice.
        </p>
      </div>

      <OnboardingForm
        dialects={dialects.map((dialect) => ({
          id: dialect.id,
          code: dialect.code,
          name: dialect.name,
          region: dialect.region,
          description: dialect.description,
        }))}
        defaultDialectCode={dialects.find((dialect) => dialect.id === user.dialectId)?.code ?? dialects[0]?.code ?? "kipsigis"}
        defaultLevel={user.proficiencyLevel}
      />
    </div>
  );
}
