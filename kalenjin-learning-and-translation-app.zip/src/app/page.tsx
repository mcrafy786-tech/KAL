import Image from "next/image";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { loadDialects } from "@/lib/data";
import { Icon, type IconName } from "@/components/icons";
import { Logo } from "@/components/ui";

export const dynamic = "force-dynamic";

const FEATURES: { icon: IconName; title: string; body: string }[] = [
  {
    icon: "book",
    title: "Six structured levels",
    body: "Greetings to storytelling, with objectives, vocabulary, grammar notes and a graded assessment in every lesson.",
  },
  {
    icon: "translate",
    title: "Two-way voice translator",
    body: "Speak English or Kalenjin, see both sentences, hear the result and keep a searchable conversation history.",
  },
  {
    icon: "sparkles",
    title: "Grounded AI tutor",
    body: "A patient tutor that explains in simple English and refuses to invent Kalenjin when the corpus lacks an answer.",
  },
  {
    icon: "mic",
    title: "Pronunciation studio",
    body: "Listen, slow it down, record yourself and compare — with no fake accuracy scores.",
  },
  {
    icon: "globe",
    title: "Seven varieties",
    body: "Kipsigis, Nandi, Tugen, Keiyo, Marakwet, Pokot and Sabaot stay distinct in every screen.",
  },
  {
    icon: "shield",
    title: "Review, not guesswork",
    body: "Native-speaker contributions, consent-tracked recordings and a review queue before anything is called verified.",
  },
];

export default async function WelcomePage() {
  const user = await getSessionUser();
  if (user) redirect(user.onboarded ? "/home" : "/onboarding");
  const dialects = await loadDialects().catch(() => []);

  return (
    <div className="pb-10">
      <header className="flex items-center justify-between px-5 pt-6">
        <div className="flex items-center gap-2.5">
          <Logo size={38} />
          <span>
            <span className="display block text-lg font-bold leading-none text-ink">Kalenjin</span>
            <span className="block text-[10px] font-medium text-muted">Learn · Speak · Translate</span>
          </span>
        </div>
        <Link href="/login" className="chip pressable">
          Sign in
        </Link>
      </header>

      <section className="px-5 pt-6">
        <div className="relative overflow-hidden rounded-[1.75rem] border border-line">
          <Image
            src="/images/hero.png"
            alt="Illustration of the Kalenjin highlands at golden hour"
            width={1080}
            height={900}
            priority
            className="h-64 w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#08231a]/90 via-[#08231a]/35 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 p-4 text-white">
            <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#f0d59a]">Kalenjin language keeper</p>
            <h1 className="display mt-1 text-[28px] font-bold leading-[1.08]">
              Speak Kalenjin.
              <br />
              Keep it alive.
            </h1>
            <p className="mt-1.5 max-w-xs text-xs leading-relaxed text-white/80">
              Structured lessons, a searchable dictionary, real games and a voice translator built on a
              native-speaker-reviewed corpus — by variety.
            </p>
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          <Link href="/register" className="btn btn-primary flex-1">
            Start learning <Icon name="arrowRight" size={16} />
          </Link>
          <Link href="/login" className="btn btn-outline">
            <Icon name="user" size={16} /> Sign in
          </Link>
        </div>
        <p className="mt-2 text-center text-[10px] text-muted">
          Demo accounts are available on the sign-in screen. No card, no trial timer.
        </p>
      </section>

      <section className="mt-6 px-5">
        <div className="flex flex-wrap gap-1.5">
          {dialects.map((dialect) => (
            <span key={dialect.id} className="chip">
              <Icon name="globe" size={11} /> {dialect.name}
            </span>
          ))}
        </div>
      </section>

      <section className="mt-6 px-5">
        <h2 className="display text-base font-semibold text-ink">Built for how the language is actually used</h2>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {FEATURES.map((feature) => (
            <div key={feature.title} className="card-flat p-3">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-[var(--brand-soft)] text-[var(--brand)]">
                <Icon name={feature.icon} size={16} />
              </span>
              <p className="display mt-1.5 text-[13px] font-semibold leading-tight text-ink">{feature.title}</p>
              <p className="mt-0.5 text-[10px] leading-relaxed text-muted">{feature.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-5 px-5">
        <div className="rounded-2xl border border-[color:var(--gold)]/50 bg-[var(--gold-soft)] p-4 text-[color:var(--clay)]">
          <p className="flex items-center gap-1.5 text-xs font-bold">
            <Icon name="shield" size={14} /> Our language-accuracy promise
          </p>
          <p className="mt-1 text-[11px] leading-relaxed">
            The translator will not invent Kalenjin. Every entry carries a verification status, uncertain results are
            labelled, and any sentence outside the reviewed corpus can be sent to a native-speaker review queue.
            Kalenjin speech recognition and native voices are not available from mainstream engines, so the app always
            offers manual input, phrase lookup and recorded audio instead.
          </p>
        </div>
      </section>

      <section className="mt-5 px-5">
        <div className="card p-4">
          <h2 className="display text-sm font-semibold text-ink">Runs on Android, iOS and the web</h2>
          <p className="mt-1 text-[11px] leading-relaxed text-muted">
            This build is an installable progressive web app: open the browser menu and choose “Add to Home screen” to
            install it like a native app, with offline lesson packs. The data layer, API contracts and offline
            behaviour are documented for a React Native / Expo client that reuses the same backend.
          </p>
        </div>
      </section>

      <footer className="mt-6 px-5 text-center">
        <p className="text-[10px] text-muted">
          Kalenjin varieties: Kipsigis · Nandi · Tugen · Keiyo · Marakwet · Pokot · Sabaot
        </p>
        <p className="mt-1 text-[10px] text-muted">Built with respect for native-speaker authority.</p>
      </footer>
    </div>
  );
}
