"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Icon } from "@/components/icons";
import { Card, StatusBadge } from "@/components/ui";

type Pending = {
  id: number;
  type: string;
  status: string;
  consent: boolean;
  createdAt: string;
  dialectId: number | null;
  payload: Record<string, string>;
};

type Vocab = {
  id: number;
  word: string;
  definition: string;
  verificationStatus: string;
  dialectId: number;
};

type Dialect = { id: number; code: string; name: string };

export function AdminClient({
  pending,
  vocabulary,
  dialects,
  recordings,
  stats,
}: {
  pending: Pending[];
  vocabulary: Vocab[];
  dialects: Dialect[];
  recordings: { id: number; speakerName: string; consentStatus: string; reviewStatus: string; audioUrl: string | null }[];
  stats: { phraseCount: number; verifiedPhrases: number; userCount: number };
}) {
  const router = useRouter();
  const [tab, setTab] = useState<"queue" | "add" | "corpus">("queue");
  const [notes, setNotes] = useState<Record<number, string>>({});
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [dialectId, setDialectId] = useState(dialects[0]?.id ?? 0);
  const [wordForm, setWordForm] = useState({ word: "", definition: "", category: "", pronunciationGuide: "", note: "" });
  const [phraseForm, setPhraseForm] = useState({ english: "", kalenjin: "", note: "" });
  const [recordForm, setRecordForm] = useState({ speakerName: "", audioUrl: "", note: "" });
  const [dialectForm, setDialectForm] = useState({ code: "", name: "", region: "", description: "" });

  async function call(body: Record<string, unknown>, successMessage: string) {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const response = await fetch("/api/admin", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = (await response.json()) as { ok: boolean; error?: string; published?: string | null };
      if (!response.ok || !data.ok) {
        setError(data.error ?? "Action failed.");
        return;
      }
      setMessage(data.published ? `${successMessage} Published as ${data.published}.` : successMessage);
      router.refresh();
    } catch {
      setError("Network error while saving.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-3 gap-2">
        <div className="card-flat p-2.5 text-center">
          <p className="text-[9px] font-bold uppercase text-muted">Queue</p>
          <p className="display text-lg font-bold text-ink">{pending.length}</p>
        </div>
        <div className="card-flat p-2.5 text-center">
          <p className="text-[9px] font-bold uppercase text-muted">Phrases</p>
          <p className="display text-lg font-bold text-ink">
            {stats.verifiedPhrases}/{stats.phraseCount}
          </p>
        </div>
        <div className="card-flat p-2.5 text-center">
          <p className="text-[9px] font-bold uppercase text-muted">Accounts</p>
          <p className="display text-lg font-bold text-ink">{stats.userCount}</p>
        </div>
      </div>

      <div className="flex rounded-full border border-line bg-surface p-1 text-xs font-semibold">
        {[
          { id: "queue" as const, label: `Review (${pending.length})` },
          { id: "add" as const, label: "Add content" },
          { id: "corpus" as const, label: "Corpus" },
        ].map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => setTab(option.id)}
            className={`flex-1 rounded-full py-1.5 transition ${
              tab === option.id ? "bg-[var(--brand)] text-[var(--brand-ink)]" : "text-muted"
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>

      {message ? <p className="text-xs text-[var(--brand)]">{message}</p> : null}
      {error ? <p className="text-xs text-[color:var(--danger)]">{error}</p> : null}

      {tab === "queue" ? (
        pending.length === 0 ? (
          <Card className="p-4 text-center text-xs text-muted">No submissions waiting for review.</Card>
        ) : (
          <div className="flex flex-col gap-2">
            {pending.map((item) => (
              <Card key={item.id} className="p-3.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wide text-[var(--brand)]">{item.type}</span>
                  <span className="text-[10px] text-muted">{new Date(item.createdAt).toLocaleDateString()}</span>
                </div>
                <div className="mt-1.5 space-y-0.5">
                  {Object.entries(item.payload).map(([key, value]) => (
                    <p key={key} className="text-[11px] text-muted">
                      <span className="font-semibold capitalize text-ink">{key}:</span> {value}
                    </p>
                  ))}
                </div>
                {item.type === "recording" ? (
                  <p className="mt-1 text-[10px] text-muted">Consent recorded: {item.consent ? "yes" : "no"}</p>
                ) : null}
                <input
                  value={notes[item.id] ?? ""}
                  onChange={(event) => setNotes((previous) => ({ ...previous, [item.id]: event.target.value }))}
                  placeholder="Reviewer note (recorded with the decision)"
                  className="input mt-2 !py-1.5 text-xs"
                />
                <div className="mt-2 flex gap-2">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() =>
                      void call(
                        { action: "approve", id: item.id, reviewNote: notes[item.id] ?? "" },
                        "Contribution approved.",
                      )
                    }
                    className="btn btn-primary flex-1 !py-1.5 !text-xs"
                  >
                    <Icon name="check" size={13} /> Approve & publish
                  </button>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() =>
                      void call({ action: "reject", id: item.id, reviewNote: notes[item.id] ?? "" }, "Contribution rejected.")
                    }
                    className="btn btn-outline flex-1 !py-1.5 !text-xs"
                  >
                    <Icon name="close" size={13} /> Reject
                  </button>
                </div>
              </Card>
            ))}
          </div>
        )
      ) : null}

      {tab === "add" ? (
        <div className="flex flex-col gap-3">
          <Card className="p-4">
            <h3 className="display text-sm font-semibold text-ink">Variety</h3>
            <select
              value={dialectId}
              onChange={(event) => setDialectId(Number(event.target.value))}
              className="select mt-1"
            >
              {dialects.map((dialect) => (
                <option key={dialect.id} value={dialect.id}>
                  {dialect.name}
                </option>
              ))}
            </select>
          </Card>

          <Card className="p-4">
            <h3 className="display text-sm font-semibold text-ink">Add vocabulary</h3>
            <div className="mt-2 flex flex-col gap-2">
              {[
                { key: "word" as const, placeholder: "Kalenjin word" },
                { key: "definition" as const, placeholder: "English definition" },
                { key: "category" as const, placeholder: "Category" },
                { key: "pronunciationGuide" as const, placeholder: "Pronunciation guide" },
                { key: "note" as const, placeholder: "Verification note" },
              ].map((field) => (
                <input
                  key={field.key}
                  value={wordForm[field.key]}
                  onChange={(event) => setWordForm((previous) => ({ ...previous, [field.key]: event.target.value }))}
                  placeholder={field.placeholder}
                  className="input !py-2 text-xs"
                />
              ))}
              <button
                type="button"
                disabled={busy || !wordForm.word || !wordForm.definition}
                onClick={() =>
                  void call(
                    {
                      action: "add_vocabulary",
                      dialectId,
                      ...wordForm,
                      category: wordForm.category || "general",
                      verificationStatus: "needs_review",
                    },
                    "Vocabulary entry added (needs review).",
                  )
                }
                className="btn btn-primary w-full !py-2 !text-xs"
              >
                <Icon name="plus" size={13} /> Add vocabulary
              </button>
            </div>
          </Card>

          <Card className="p-4">
            <h3 className="display text-sm font-semibold text-ink">Add verified phrase</h3>
            <div className="mt-2 flex flex-col gap-2">
              <input
                value={phraseForm.english}
                onChange={(event) => setPhraseForm((previous) => ({ ...previous, english: event.target.value }))}
                placeholder="English"
                className="input !py-2 text-xs"
              />
              <input
                value={phraseForm.kalenjin}
                onChange={(event) => setPhraseForm((previous) => ({ ...previous, kalenjin: event.target.value }))}
                placeholder="Kalenjin"
                className="input !py-2 text-xs"
              />
              <input
                value={phraseForm.note}
                onChange={(event) => setPhraseForm((previous) => ({ ...previous, note: event.target.value }))}
                placeholder="Reviewer / source note"
                className="input !py-2 text-xs"
              />
              <button
                type="button"
                disabled={busy || !phraseForm.english || !phraseForm.kalenjin}
                onClick={() =>
                  void call(
                    {
                      action: "add_phrase",
                      dialectId,
                      ...phraseForm,
                      verificationStatus: "verified",
                    },
                    "Reviewed phrase added to the translator corpus.",
                  )
                }
                className="btn btn-primary w-full !py-2 !text-xs"
              >
                <Icon name="plus" size={13} /> Add reviewed phrase
              </button>
            </div>
          </Card>

          <Card className="p-4">
            <h3 className="display text-sm font-semibold text-ink">Register a native recording</h3>
            <div className="mt-2 flex flex-col gap-2">
              <input
                value={recordForm.speakerName}
                onChange={(event) => setRecordForm((previous) => ({ ...previous, speakerName: event.target.value }))}
                placeholder="Speaker name"
                className="input !py-2 text-xs"
              />
              <input
                value={recordForm.audioUrl}
                onChange={(event) => setRecordForm((previous) => ({ ...previous, audioUrl: event.target.value }))}
                placeholder="Audio URL"
                className="input !py-2 text-xs"
              />
              <input
                value={recordForm.note}
                onChange={(event) => setRecordForm((previous) => ({ ...previous, note: event.target.value }))}
                placeholder="Consent / usage note"
                className="input !py-2 text-xs"
              />
              <button
                type="button"
                disabled={busy || !recordForm.speakerName || !recordForm.audioUrl}
                onClick={() =>
                  void call(
                    { action: "add_recording", dialectId, ...recordForm, consentStatus: "granted" },
                    "Recording metadata saved (review pending).",
                  )
                }
                className="btn btn-secondary w-full !py-2 !text-xs"
              >
                <Icon name="mic" size={13} /> Save recording metadata
              </button>
            </div>
            {recordings.length > 0 ? (
              <ul className="mt-2 divide-y divide-[var(--line)]">
                {recordings.slice(0, 5).map((recording) => (
                  <li key={recording.id} className="flex items-center justify-between gap-2 py-1.5 text-[11px]">
                    <span className="truncate text-ink">{recording.speakerName}</span>
                    <span className="flex items-center gap-1">
                      <StatusBadge status={recording.reviewStatus === "approved" ? "approved" : "pending"} />
                      {recording.reviewStatus !== "approved" ? (
                        <button
                          type="button"
                          onClick={() => void call({ action: "review_recording", id: recording.id, reviewStatus: "approved" }, "Recording approved.")}
                          className="chip pressable"
                        >
                          Approve
                        </button>
                      ) : null}
                    </span>
                  </li>
                ))}
              </ul>
            ) : null}
          </Card>

          <Card className="p-4">
            <h3 className="display text-sm font-semibold text-ink">Add a Kalenjin variety</h3>
            <div className="mt-2 flex flex-col gap-2">
              {[
                { key: "code" as const, placeholder: "code (e.g. terik)" },
                { key: "name" as const, placeholder: "Display name" },
                { key: "region" as const, placeholder: "Region" },
                { key: "description" as const, placeholder: "Description" },
              ].map((field) => (
                <input
                  key={field.key}
                  value={dialectForm[field.key]}
                  onChange={(event) => setDialectForm((previous) => ({ ...previous, [field.key]: event.target.value }))}
                  placeholder={field.placeholder}
                  className="input !py-2 text-xs"
                />
              ))}
              <button
                type="button"
                disabled={busy || !dialectForm.code || !dialectForm.name || !dialectForm.region}
                onClick={() => void call({ action: "add_dialect", ...dialectForm }, "Variety added.")}
                className="btn btn-outline w-full !py-2 !text-xs"
              >
                <Icon name="globe" size={13} /> Add variety
              </button>
            </div>
          </Card>
        </div>
      ) : null}

      {tab === "corpus" ? (
        <Card className="p-4">
          <h3 className="display text-sm font-semibold text-ink">Recent vocabulary</h3>
          <ul className="mt-2 divide-y divide-[var(--line)]">
            {vocabulary.map((entry) => (
              <li key={entry.id} className="flex items-start justify-between gap-2 py-2">
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-ink">{entry.word}</p>
                  <p className="truncate text-[10px] text-muted">{entry.definition}</p>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <StatusBadge status={entry.verificationStatus} />
                  {entry.verificationStatus !== "verified" ? (
                    <button
                      type="button"
                      onClick={() =>
                        void call(
                          { action: "update_vocabulary", id: entry.id, verificationStatus: "verified", note: "Verified by admin review." },
                          "Entry marked reviewed.",
                        )
                      }
                      className="chip pressable"
                    >
                      <Icon name="check" size={11} /> Verify
                    </button>
                  ) : null}
                </div>
              </li>
            ))}
          </ul>
        </Card>
      ) : null}
    </div>
  );
}
