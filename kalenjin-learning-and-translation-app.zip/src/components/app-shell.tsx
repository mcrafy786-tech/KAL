"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { Icon } from "@/components/icons";
import { Logo } from "@/components/ui";

export type ShellUser = {
  username: string;
  dialectName: string | null;
  streak: number;
  xp: number;
  role: string;
};

const NAV = [
  { href: "/home", label: "Home", icon: "home" as const },
  { href: "/learn", label: "Learn", icon: "book" as const },
  { href: "/translate", label: "Translate", icon: "translate" as const, primary: true },
  { href: "/tutor", label: "Tutor", icon: "sparkles" as const },
  { href: "/profile", label: "Profile", icon: "user" as const },
];

function ThemeToggle() {
  const [theme, setTheme] = useState<"light" | "dark">("light");

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      setTheme(document.documentElement.dataset.theme === "dark" ? "dark" : "light");
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  function toggle() {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    document.documentElement.dataset.theme = next;
    try {
      localStorage.setItem("kal-theme", next);
    } catch {
      /* storage might be unavailable */
    }
    void fetch("/api/preferences", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ theme: next }),
    }).catch(() => undefined);
  }

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}
      className="pressable grid h-9 w-9 place-items-center rounded-full border border-line bg-surface text-ink"
    >
      <Icon name={theme === "dark" ? "sun" : "moon"} size={16} />
    </button>
  );
}

export function AppShell({ user, children }: { user: ShellUser; children: ReactNode }) {
  const pathname = usePathname();
  const [offline, setOffline] = useState(false);
  const [installable, setInstallable] = useState<{ prompt: () => Promise<void> } | null>(null);

  useEffect(() => {
    const update = () => setOffline(!navigator.onLine);
    update();
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => {
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
    };
  }, []);

  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
    const handler = (event: Event) => {
      const promptEvent = event as Event & { prompt?: () => Promise<void> };
      if (promptEvent.prompt) {
        setInstallable({ prompt: () => promptEvent.prompt!() });
      }
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="sticky top-0 z-30 border-b border-line bg-[color:var(--canvas)]/85 backdrop-blur-xl">
        <div className="flex items-center justify-between px-4 pb-2 pt-3">
          <Link href="/home" className="flex items-center gap-2.5">
            <Logo size={34} />
            <span className="leading-none">
              <span className="display block text-[17px] font-bold tracking-tight text-ink">Kalenjin</span>
              <span className="block text-[10px] font-medium text-muted">Learn · Speak · Translate</span>
            </span>
          </Link>
          <div className="flex items-center gap-1.5">
            <span className="chip" title="Daily practice streak">
              <Icon name="flame" size={12} className="text-[color:var(--clay)]" />
              {user.streak}
            </span>
            <span className="chip hidden sm:inline-flex" title="Experience points">
              <Icon name="star" size={12} className="text-[color:var(--gold)]" />
              {user.xp} XP
            </span>
            <ThemeToggle />
            <Link
              href="/profile"
              aria-label="Open profile"
              className="grid h-9 w-9 place-items-center rounded-full bg-[var(--brand-soft)] text-xs font-bold text-[var(--brand)]"
            >
              {user.username.slice(0, 2).toUpperCase()}
            </Link>
          </div>
        </div>
        <div className="hide-scrollbar flex items-center gap-2 overflow-x-auto px-4 pb-2">
          <Link href="/profile#variety" className="chip pressable">
            <Icon name="globe" size={12} className="text-[var(--brand)]" />
            {user.dialectName ?? "Choose variety"}
          </Link>
          {offline ? (
            <span className="chip border-[color:var(--gold)] bg-[var(--gold-soft)] text-[color:var(--clay)]">
              <Icon name="info" size={12} /> Offline — downloads only
            </span>
          ) : (
            <span className="chip">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--brand)]" /> Online
            </span>
          )}
          {installable ? (
            <button
              type="button"
              onClick={() => void installable.prompt()}
              className="chip border-[var(--brand)] text-[var(--brand)]"
            >
              <Icon name="download" size={12} /> Install app
            </button>
          ) : null}
          {user.role === "admin" ? (
            <Link href="/admin" className="chip border-[var(--brand)] text-[var(--brand)]">
              <Icon name="shield" size={12} /> Admin
            </Link>
          ) : null}
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <nav className="bottom-nav" aria-label="Main navigation">
        <div className="flex items-end justify-between gap-1">
          {NAV.map((item) => {
            const active =
              pathname === item.href || (item.href !== "/home" && pathname.startsWith(item.href));
            if (item.primary) {
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  aria-current={active ? "page" : undefined}
                  className="flex flex-1 flex-col items-center gap-1 text-[0.66rem] font-semibold"
                >
                  <span
                    className={`grid h-12 w-12 place-items-center rounded-full text-[var(--brand-ink)] shadow-lg transition ${
                      active ? "scale-105 bg-[var(--clay)]" : "bg-[var(--brand)]"
                    }`}
                    style={{ marginTop: "-1.4rem" }}
                  >
                    <Icon name="translate" size={22} />
                  </span>
                  <span className={active ? "text-[var(--brand)]" : "text-muted"}>{item.label}</span>
                </Link>
              );
            }
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                className="nav-item"
                data-active={active}
              >
                <Icon name={item.icon} size={20} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
