"use client";

import { useState } from "react";
import { Icon } from "@/components/icons";
import { useSpeechSynthesis } from "@/lib/use-speech";

export function AudioButton({
  text,
  lang = "kal",
  label,
  size = "md",
  variant = "soft",
  disabled = false,
}: {
  text: string;
  lang?: "en" | "kal";
  label?: string;
  size?: "sm" | "md";
  variant?: "soft" | "solid" | "plain";
  disabled?: boolean;
}) {
  const { speak, stop, speaking, supported } = useSpeechSynthesis();
  const [active, setActive] = useState(false);

  const styles =
    variant === "solid"
      ? "bg-[var(--brand)] text-[var(--brand-ink)]"
      : variant === "plain"
        ? "bg-transparent text-muted"
        : "bg-[var(--surface-muted)] text-[var(--brand)]";

  function handleClick() {
    if (!text.trim()) return;
    if (speaking && active) {
      stop();
      setActive(false);
      return;
    }
    const started = speak(text, { lang, rate: lang === "kal" ? 0.85 : 0.95 });
    setActive(Boolean(started));
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={disabled || !supported}
      title={
        supported
          ? lang === "kal"
            ? "Play with the device voice (not a native recording). Availability depends on your phone's installed voices."
            : "Play audio"
          : "Speech synthesis is not available in this browser"
      }
      aria-label={label ?? `Play audio for ${text}`}
      className={`pressable inline-flex items-center justify-center gap-2 rounded-full ${styles} ${
        size === "sm" ? "h-8 w-8" : "h-10 px-4"
      }`}
    >
      <Icon name={speaking && active ? "pause" : "volume"} size={size === "sm" ? 15 : 17} />
      {size === "md" && label ? <span className="text-xs font-semibold">{label}</span> : null}
    </button>
  );
}

export function SlowAudioButton({ text, lang = "kal" }: { text: string; lang?: "en" | "kal" }) {
  const { speak, supported } = useSpeechSynthesis();
  return (
    <button
      type="button"
      onClick={() => speak(text, { lang, rate: 0.6 })}
      disabled={!supported}
      className="chip pressable disabled:opacity-50"
      title="Slower playback for pronunciation practice"
    >
      <Icon name="headphones" size={13} /> Slow
    </button>
  );
}

export function SpeechNotice({ lang = "kal" }: { lang?: "en" | "kal" }) {
  return (
    <p className="text-[10px] leading-relaxed text-muted">
      {lang === "kal"
        ? "Audio is played by your device's text-to-speech voice, not a native Kalenjin recording. The app uses the closest installed voice and labels it as an approximation. Native recordings appear only after a consented speaker uploads them."
        : "Audio uses your device's built-in English voice."}
    </p>
  );
}
