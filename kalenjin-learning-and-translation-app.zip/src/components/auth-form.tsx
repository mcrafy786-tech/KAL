"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Icon } from "@/components/icons";

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event?: React.FormEvent) {
    event?.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const response = await fetch(`/api/auth/${mode === "login" ? "login" : "register"}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(
          mode === "login" ? { email, password } : { email, password, username },
        ),
      });
      const data = (await response.json()) as { ok: boolean; error?: string; next?: string };
      if (!response.ok || !data.ok) {
        setError(data.error ?? "Something went wrong. Please try again.");
        return;
      }
      router.replace(data.next ?? "/home");
      router.refresh();
    } catch {
      setError("Network error. Check your connection and try again.");
    } finally {
      setBusy(false);
    }
  }

  async function demo(role: "learner" | "admin" | "contributor") {
    setBusy(true);
    setError(null);
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ demo: role }),
      });
      const data = (await response.json()) as { ok: boolean; error?: string; next?: string };
      if (!response.ok || !data.ok) {
        setError(data.error ?? "Demo sign-in failed.");
        return;
      }
      router.replace(data.next ?? "/home");
      router.refresh();
    } catch {
      setError("Network error while starting the demo.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <form onSubmit={submit} className="card flex flex-col gap-3 p-5">
        <div>
          <h1 className="display text-xl font-bold text-ink">
            {mode === "login" ? "Welcome back" : "Create your account"}
          </h1>
          <p className="mt-0.5 text-xs text-muted">
            {mode === "login"
              ? "Sign in to keep your streak, vocabulary and translation history."
              : "Your progress, language variety and saved phrases stay tied to your account."}
          </p>
        </div>

        {mode === "register" ? (
          <label className="flex flex-col gap-1">
            <span className="label">Username</span>
            <input
              className="input"
              value={username}
              onChange={(event) => setUsername(event.target.value)}
              autoComplete="username"
              minLength={3}
              required
              placeholder="e.g. chebet_learns"
            />
          </label>
        ) : null}

        <label className="flex flex-col gap-1">
          <span className="label">Email</span>
          <input
            className="input"
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            autoComplete="email"
            required
            placeholder="you@example.com"
          />
        </label>

        <label className="flex flex-col gap-1">
          <span className="label">Password</span>
          <input
            className="input"
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            autoComplete={mode === "login" ? "current-password" : "new-password"}
            minLength={8}
            required
            placeholder="At least 8 characters"
          />
        </label>

        {error ? <p className="text-xs text-[color:var(--danger)]">{error}</p> : null}

        <button type="submit" disabled={busy} className="btn btn-primary w-full">
          {busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}
          <Icon name="arrowRight" size={15} />
        </button>

        <p className="text-center text-xs text-muted">
          {mode === "login" ? (
            <>
              New here?{" "}
              <Link href="/register" className="font-semibold text-[var(--brand)] underline">
                Create an account
              </Link>
            </>
          ) : (
            <>
              Already have an account?{" "}
              <Link href="/login" className="font-semibold text-[var(--brand)] underline">
                Sign in
              </Link>
            </>
          )}
        </p>
      </form>

      <div className="card p-4">
        <p className="label">Explore with a demo account</p>
        <p className="mt-1 text-[11px] leading-relaxed text-muted">
          Seeded accounts for reviewing the app. Change these credentials before any real deployment.
        </p>
        <div className="mt-2 flex flex-col gap-2">
          <button type="button" disabled={busy} onClick={() => void demo("learner")} className="btn btn-secondary w-full">
            <Icon name="user" size={15} /> Learner demo (streak + progress)
          </button>
          <button type="button" disabled={busy} onClick={() => void demo("admin")} className="btn btn-outline w-full">
            <Icon name="shield" size={15} /> Admin demo (review queue)
          </button>
        </div>
        <p className="mt-2 text-[10px] text-muted">
          Credentials: demo@kalenjin.app / demo1234 · admin@kalenjin.app / Kalenjin2026!
        </p>
      </div>
    </div>
  );
}
