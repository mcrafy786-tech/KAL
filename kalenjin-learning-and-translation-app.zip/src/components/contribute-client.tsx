"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Icon } from "@/components/icons";
import { Card, StatusBadge } from "@/components/ui";

type Dialect = { id: number; code: string; name: string };

type Contribution = {
  id: number;
  type: string;
  status: string;
  reviewNote: string | null;
  createdAt: string;
  payload: Record<string, string>;
};

const TYPES = [
  { id: "vocabulary", label: "New word", hint: "A word your variety uses, with an English definition." },
  { id: "correction", label: "Translation correction", hint: "Correct an existing phrase or translation." },
  { id: "recording", label: "Native recording", hint: "Attach consented native-speaker audio." },
  { id: "example", label: "Example sentence", hint: "A reviewed example with its English meaning." },
  { id: "cultural", label: "Cultural knowledge", hint: "A custom, proverb or usage note." },
];

const FIELDS: Record<string, { name: string; label: string; textarea?: boolean }[]> = {
  vocabulary: [
    { name: "word", label: "Kalenjin word" },
    { name: "definition", label: "English definition" },
    { name: "category", label: "Category (e.g. greetings)" },
    { name: "pronunciation", label: "Pronunciation guide (optional)" },
    { name: "note", label: "Where you learned it / usage note", textarea: true },
  ],
  correction: [
    { name: "english", label: "English sentence" },
    { name: "kalenjin", label: "Correct Kalenjin sentence" },
    { name: "note", label: "What was wrong in the current entry?", textarea: true },
  ],
  recording: [
    { name: "speakerName", label: "Speaker's name" },
    { name: "audioUrl", label: "Audio URL (storage bucket or archive link)" },
    { name: "word", label: "Word or phrase recorded" },
    { name: "note", label: "Variety/location and usage context", textarea: true },
  ],
  example: [
    { name: "english", label: "English sentence" },
    { name: "kalenjin", label: "Kalenjin sentence" },
    { name: "note", label: "When is it used?", textarea: true },
  ],
  cultural: [
    { name: "title", label: "Title" },
    { name: "body", label: "Explanation", textarea: true },
    { name: "note", label: "Source / community context", textarea: true },
  ],
};

export function ContributeClient({
  dialects,
  defaultDialectCode,
  contributions,
}: {
  dialects: Dialect[];
  defaultDialectCode: string;
  contributions: Contribution[];
}) {
  const router = useRouter();
  const [type, setType] = useState("vocabulary");
  const [dialectCode, setDialectCode] = useState(defaultDialectCode);
  const [values, setValues] = useState<Record<string, string>>({});
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const response = await fetch("/api/contributions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ type, dialectCode, payload: values, consent }),
      });
      const data = (await response.json()) as { ok: boolean; error?: string };
      if (!response.ok || !data.ok) {
        setError(data.error ?? "Could not submit your contribution.");
        return;
      }
      setValues({});
      setConsent(false);
      setMessage("Submitted for review. A reviewer will check it before learners see it as confirmed.");
      router.refresh();
    } catch {
      setError("Network error while submitting.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <Card className="p-4">
        <p className="label">Contribution type</p>
        <div className="mt-1.5 grid grid-cols-2 gap-1.5">
          {TYPES.map((option) => (
            <button
              key={option.id}
              type="button"
              onClick={() => {
                setType(option.id);
                setValues({});
              }}
              className={`rounded-xl border px-2.5 py-2 text-left transition ${
                type === option.id ? "border-[var(--brand)] bg-[var(--brand-soft)]/50" : "border-line bg-surface"
              }`}
            >
              <span className="block text-[11px] font-semibold text-ink">{option.label}</span>
              <span className="block text-[9px] leading-snug text-muted">{option.hint}</span>
            </button>
          ))}
        </div>
      </Card>

      <form onSubmit={submit} className="card flex flex-col gap-2.5 p-4">
        <label className="flex flex-col gap-1">
          <span className="label">Kalenjin variety</span>
          <select value={dialectCode} onChange={(event) => setDialectCode(event.target.value)} className="select">
            {dialects.map((dialect) => (
              <option key={dialect.code} value={dialect.code}>
                {dialect.name}
              </option>
            ))}
          </select>
        </label>

        {FIELDS[type].map((field) => (
          <label key={field.name} className="flex flex-col gap-1">
            <span className="label">{field.label}</span>
            {field.textarea ? (
              <textarea
                value={values[field.name] ?? ""}
                onChange={(event) => setValues((previous) => ({ ...previous, [field.name]: event.target.value }))}
                rows={2}
                className="textarea resize-none"
              />
            ) : (
              <input
                value={values[field.name] ?? ""}
                onChange={(event) => setValues((previous) => ({ ...previous, [field.name]: event.target.value }))}
                className="input"
              />
            )}
          </label>
        ))}

        {type === "recording" ? (
          <label className="flex items-start gap-2 rounded-xl border border-line p-2.5 text-[11px] leading-relaxed text-muted">
            <input
              type="checkbox"
              checked={consent}
              onChange={(event) => setConsent(event.target.checked)}
              className="mt-0.5 h-4 w-4 accent-[var(--brand)]"
            />
            I confirm I am the speaker, or I have the speaker&apos;s permission, and the recording may be used to teach
            Kalenjin in this app. Consent is stored with the recording and can be withdrawn by contacting the editorial
            team.
          </label>
        ) : null}

        {message ? <p className="text-xs text-[var(--brand)]">{message}</p> : null}
        {error ? <p className="text-xs text-[color:var(--danger)]">{error}</p> : null}

        <button type="submit" disabled={busy} className="btn btn-primary w-full">
          {busy ? "Submitting…" : "Submit for native review"} <Icon name="send" size={15} />
        </button>
        <p className="text-[10px] leading-relaxed text-muted">
          Submissions are never published automatically. Audio binary upload requires object storage to be configured;
          until then, submit a stable link to the recording together with consent.
        </p>
      </form>

      <Card className="p-4">
        <h2 className="display text-sm font-semibold text-ink">Your submissions</h2>
        {contributions.length === 0 ? (
          <p className="mt-1 text-xs text-muted">Nothing submitted yet. Your first correction helps every learner.</p>
        ) : (
          <ul className="mt-2 divide-y divide-[var(--line)]">
            {contributions.map((contribution) => (
              <li key={contribution.id} className="py-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-semibold capitalize text-ink">{contribution.type}</span>
                  <StatusBadge status={contribution.status} />
                </div>
                <p className="mt-0.5 text-[11px] text-muted">
                  {Object.values(contribution.payload).filter(Boolean).slice(0, 3).join(" · ")}
                </p>
                <p className="text-[10px] text-muted">{new Date(contribution.createdAt).toLocaleDateString()}</p>
                {contribution.reviewNote ? (
                  <p className="mt-1 rounded-lg bg-[var(--surface-muted)] px-2 py-1 text-[10px] text-muted">
                    Reviewer: {contribution.reviewNote}
                  </p>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
