"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { AudioButton, SlowAudioButton, SpeechNotice } from "@/components/audio";
import { Icon } from "@/components/icons";
import { Card, EmptyState, InfoNote, StatusBadge } from "@/components/ui";
import type { DictionaryEntry } from "@/lib/data";

type Tab = "all" | "favorites" | "learned";

export function DictionaryClient({
  entries,
  dialectName,
  coverage,
}: {
  entries: DictionaryEntry[];
  dialectName: string;
  coverage: { total: number; reviewed: number; pending: number };
}) {
  const [entriesState, setEntriesState] = useState(entries);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [tab, setTab] = useState<Tab>("all");
  const [message, setMessage] = useState<string | null>(null);

  const categories = useMemo(
    () => ["all", ...Array.from(new Set(entriesState.map((entry) => entry.category))).sort()],
    [entriesState],
  );

  const filtered = useMemo(() => {
    const search = query.trim().toLowerCase();
    return entriesState.filter((entry) => {
      if (category !== "all" && entry.category !== category) return false;
      if (tab === "favorites" && !entry.favorite) return false;
      if (tab === "learned" && !entry.learned) return false;
      if (!search) return true;
      return entry.word.toLowerCase().includes(search) || entry.definition.toLowerCase().includes(search);
    });
  }, [category, entriesState, query, tab]);

  async function toggleFavorite(entry: DictionaryEntry) {
    setEntriesState((previous) =>
      previous.map((item) => (item.id === entry.id ? { ...item, favorite: !item.favorite } : item)),
    );
    try {
      const response = await fetch("/api/favorites", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ vocabularyId: entry.id }),
      });
      if (!response.ok) throw new Error("failed");
    } catch {
      setEntriesState((previous) =>
        previous.map((item) => (item.id === entry.id ? { ...item, favorite: entry.favorite } : item)),
      );
      setMessage("Could not update your favourites. Check your connection.");
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <InfoNote>
        {coverage.reviewed} of {coverage.total} entries for {dialectName} are reviewed; {coverage.pending} are awaiting
        native-speaker review. Favourite words are saved to your account.
      </InfoNote>

      <div className="relative">
        <Icon name="search" size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
        <input
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder={`Search ${dialectName} or English…`}
          className="input pl-9"
          aria-label="Search the dictionary"
        />
      </div>

      <div className="flex rounded-full border border-line bg-surface p-1 text-xs font-semibold">
        {(
          [
            { id: "all" as Tab, label: `All ${entriesState.length}` },
            { id: "favorites" as Tab, label: "Favourites" },
            { id: "learned" as Tab, label: "Learned" },
          ]
        ).map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => setTab(option.id)}
            className={`flex-1 rounded-full py-1.5 transition ${
              tab === option.id ? "bg-[var(--brand)] text-[var(--brand-ink)]" : "text-muted"
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>

      <div className="hide-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
        {categories.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => setCategory(item)}
            className={`chip pressable capitalize ${
              category === item ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]" : ""
            }`}
          >
            {item}
          </button>
        ))}
      </div>

      {message ? <p className="text-xs text-[color:var(--clay)]">{message}</p> : null}

      {filtered.length === 0 ? (
        <EmptyState
          icon="search"
          title="No entries match"
          body={
            entriesState.length === 0
              ? `No dictionary entries exist for ${dialectName} yet. Contribute a word and recording to start this variety's corpus.`
              : "Try a different spelling, category or tab. The dictionary contains only verified-corpus entries — it never invents a word to fill a gap."
          }
          action={
            <Link href="/contribute" className="btn btn-secondary mt-1">
              <Icon name="plus" size={15} /> Contribute a word
            </Link>
          }
        />
      ) : (
        <ul className="flex flex-col gap-2">
          {filtered.map((entry) => (
            <li key={entry.id}>
              <Card className="p-3.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <h3 className="display text-lg font-semibold leading-none text-ink">{entry.word}</h3>
                      <StatusBadge status={entry.verificationStatus} />
                      {entry.learned ? (
                        <span className="chip border-transparent bg-[var(--brand-soft)] text-[var(--brand)]">
                          <Icon name="check" size={10} /> Learned
                        </span>
                      ) : null}
                    </div>
                    <p className="mt-1 text-sm text-muted">{entry.definition}</p>
                    {entry.pronunciationGuide ? (
                      <p className="mt-0.5 text-[11px] text-muted">Say it: {entry.pronunciationGuide}</p>
                    ) : null}
                  </div>
                  <button
                    type="button"
                    onClick={() => void toggleFavorite(entry)}
                    aria-label={entry.favorite ? "Remove from favourites" : "Add to favourites"}
                    aria-pressed={entry.favorite}
                    className={`pressable grid h-8 w-8 shrink-0 place-items-center rounded-full border ${
                      entry.favorite
                        ? "border-transparent bg-[var(--gold-soft)] text-[color:var(--clay)]"
                        : "border-line bg-surface text-muted"
                    }`}
                  >
                    <Icon name="star" size={15} filled={entry.favorite} />
                  </button>
                </div>

                {entry.exampleSentence ? (
                  <p className="mt-2 rounded-xl bg-[var(--surface-muted)] px-2.5 py-1.5 text-[11px] text-ink">
                    {entry.exampleSentence}
                    {entry.exampleTranslation ? <span className="text-muted"> — {entry.exampleTranslation}</span> : null}
                  </p>
                ) : null}

                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <AudioButton text={entry.word} lang="kal" size="sm" />
                  <SlowAudioButton text={entry.word} />
                  <span className="chip capitalize">{entry.category}</span>
                  <span className="chip">{dialectName}</span>
                  {entry.recordCount > 0 ? (
                    <span className="chip">
                      <Icon name="mic" size={10} /> {entry.recordCount} native recording(s)
                    </span>
                  ) : (
                    <Link href="/contribute" className="chip pressable">
                      <Icon name="mic" size={10} /> Add native audio
                    </Link>
                  )}
                </div>
                {entry.verificationNote ? (
                  <p className="mt-1.5 text-[10px] leading-relaxed text-muted">{entry.verificationNote}</p>
                ) : null}
              </Card>
            </li>
          ))}
        </ul>
      )}

      <div className="mt-1">
        <SpeechNotice lang="kal" />
      </div>
    </div>
  );
}
