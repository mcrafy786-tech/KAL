"use client";

import { useCallback, useMemo, useState } from "react";
import { AudioButton } from "@/components/audio";
import { Icon } from "@/components/icons";
import { Card, ProgressBar, StatusBadge } from "@/components/ui";
import { useSpeechSynthesis } from "@/lib/use-speech";

type Word = { id: number; word: string; definition: string; category: string; verificationStatus: string };
type Phrase = { english: string; kalenjin: string; status: string };

type GameId = "match" | "build" | "listen" | "quiz" | "memory" | "missing";

function shuffle<T>(items: T[]): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export function Games({
  words,
  phrases,
  dialectName,
}: {
  words: Word[];
  phrases: Phrase[];
  dialectName: string;
}) {
  const [game, setGame] = useState<GameId | null>(null);
  const [result, setResult] = useState<{ score: number; xp: number; achievements: string[] } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const submitScore = useCallback(async (gameType: GameId, score: number, total: number) => {
    try {
      const response = await fetch("/api/games/score", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ gameType, score, total }),
      });
      const data = (await response.json()) as { ok: boolean; xpEarned?: number; achievements?: string[]; error?: string };
      if (!response.ok || !data.ok) {
        setError(data.error ?? "Could not save your score.");
        setResult({ score, xp: 0, achievements: [] });
        return;
      }
      setResult({ score, xp: data.xpEarned ?? 0, achievements: data.achievements ?? [] });
    } catch {
      setError("Network error — score not saved, but you can keep practising.");
      setResult({ score, xp: 0, achievements: [] });
    }
  }, []);

  const options: { id: GameId; title: string; description: string; icon: "game" | "book" | "headphones" | "target" | "star" }[] = [
    { id: "match", title: "Word match", description: "Pair Kalenjin words with English meanings", icon: "game" },
    { id: "build", title: "Sentence builder", description: "Arrange reviewed phrase tokens", icon: "book" },
    { id: "listen", title: "Listening challenge", description: "Identify a word from its audio", icon: "headphones" },
    { id: "quiz", title: "Daily quiz", description: "Mixed questions from your recent words", icon: "target" },
    { id: "memory", title: "Memory pairs", description: "Flip cards to find a word and meaning", icon: "star" },
    { id: "missing", title: "Missing word", description: "Complete a reviewed phrase with the right word", icon: "target" },
  ];

  if (words.length < 4) {
    return (
      <Card className="p-5 text-center">
        <p className="display text-base font-semibold text-ink">Not enough vocabulary for {dialectName} games yet</p>
        <p className="mt-1 text-xs text-muted">
          Games need at least four reviewed entries for your variety. Contribute vocabulary or switch variety to keep
          playing.
        </p>
      </Card>
    );
  }

  if (result) {
    return (
      <Card className="flex flex-col items-center p-5 text-center fade-up">
        <span className="grid h-14 w-14 place-items-center rounded-full bg-[var(--gold-soft)] text-[color:var(--clay)]">
          <Icon name="trophy" size={26} />
        </span>
        <h2 className="display mt-2 text-xl font-bold text-ink">{result.score}%</h2>
        <p className="text-xs text-muted">
          {result.score >= 80 ? "Strong work — the words are sticking." : "Good practice. Review the dictionary and try again."}
        </p>
        <p className="mt-1 text-xs font-semibold text-[var(--brand)]">+{result.xp} XP</p>
        {result.achievements.length > 0 ? (
          <p className="chip mt-2 border-transparent bg-[var(--gold-soft)] text-[color:var(--clay)]">
            Achievement unlocked: {result.achievements.join(", ")}
          </p>
        ) : null}
        {error ? <p className="mt-2 text-xs text-[color:var(--danger)]">{error}</p> : null}
        <div className="mt-3 flex w-full gap-2">
          <button type="button" onClick={() => setResult(null)} className="btn btn-primary flex-1">
            Play again
          </button>
          <button
            type="button"
            onClick={() => {
              setResult(null);
              setGame(null);
            }}
            className="btn btn-outline flex-1"
          >
            All games
          </button>
        </div>
      </Card>
    );
  }

  function finish(score: number, total: number, id: GameId) {
    void submitScore(id, score, total);
  }

  if (!game) {
    return (
      <div className="flex flex-col gap-2">
        {options.map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => setGame(option.id)}
            className="card pressable flex items-center gap-3 p-3.5 text-left"
          >
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[var(--brand-soft)] text-[var(--brand)]">
              <Icon name={option.icon} size={18} />
            </span>
            <span className="min-w-0 flex-1">
              <span className="display block text-sm font-semibold text-ink">{option.title}</span>
              <span className="block text-[11px] text-muted">{option.description}</span>
            </span>
            <Icon name="arrowRight" size={16} className="text-muted" />
          </button>
        ))}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      <button type="button" onClick={() => setGame(null)} className="chip pressable self-start">
        <Icon name="chevronLeft" size={12} /> All games
      </button>
      {game === "match" ? <MatchGame words={words} onFinish={(score, total) => finish(score, total, "match")} /> : null}
      {game === "build" ? <BuildGame words={words} phrases={phrases} onFinish={(score, total) => finish(score, total, "build")} /> : null}
      {game === "listen" ? <ListenGame words={words} onFinish={(score, total) => finish(score, total, "listen")} /> : null}
      {game === "quiz" ? <QuizGame words={words} onFinish={(score, total) => finish(score, total, "quiz")} /> : null}
      {game === "memory" ? <MemoryGame words={words} onFinish={(score, total) => finish(score, total, "memory")} /> : null}
      {game === "missing" ? <MissingWordGame phrases={phrases} onFinish={(score, total) => finish(score, total, "missing")} /> : null}
    </div>
  );
}

function MatchGame({ words, onFinish }: { words: Word[]; onFinish: (score: number, total: number) => void }) {
  const round = useMemo(() => shuffle(words).slice(0, 4), [words]);
  const meanings = useMemo(() => shuffle(round), [round]);
  const [selectedWord, setSelectedWord] = useState<number | null>(null);
  const [matched, setMatched] = useState<number[]>([]);
  const [wrong, setWrong] = useState(0);
  const [flash, setFlash] = useState<number | null>(null);

  function chooseMeaning(id: number) {
    if (selectedWord === null) return;
    if (selectedWord === id) {
      const next = [...matched, id];
      setMatched(next);
      setSelectedWord(null);
      if (next.length === round.length) {
        const score = Math.max(0, Math.round((round.length / (round.length + wrong)) * 100));
        setTimeout(() => onFinish(score, round.length), 300);
      }
    } else {
      setWrong((value) => value + 1);
      setFlash(id);
      setTimeout(() => setFlash(null), 450);
    }
  }

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <h3 className="display text-sm font-semibold text-ink">Word match</h3>
        <span className="chip">
          {matched.length}/{round.length} pairs
        </span>
      </div>
      <ProgressBar value={(matched.length / round.length) * 100} className="mt-2" />
      <div className="mt-3 grid grid-cols-2 gap-2">
        <div className="flex flex-col gap-1.5">
          {round.map((word) => (
            <button
              key={word.id}
              type="button"
              disabled={matched.includes(word.id)}
              onClick={() => setSelectedWord(word.id)}
              className={`rounded-xl border px-2.5 py-2 text-left text-xs font-semibold transition ${
                matched.includes(word.id)
                  ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)] opacity-60"
                  : selectedWord === word.id
                    ? "border-[var(--brand)] bg-[var(--brand-soft)]/50 text-ink"
                    : "border-line bg-surface text-ink"
              }`}
            >
              {word.word}
            </button>
          ))}
        </div>
        <div className="flex flex-col gap-1.5">
          {meanings.map((word) => (
            <button
              key={`meaning-${word.id}`}
              type="button"
              disabled={matched.includes(word.id)}
              onClick={() => chooseMeaning(word.id)}
              className={`rounded-xl border px-2.5 py-2 text-left text-[11px] transition ${
                matched.includes(word.id)
                  ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)] opacity-60"
                  : flash === word.id
                    ? "border-[color:var(--danger)] bg-[color:var(--danger)]/10 text-[color:var(--danger)]"
                    : "border-line bg-surface text-ink"
              }`}
            >
              {word.definition}
            </button>
          ))}
        </div>
      </div>
      <p className="mt-2 text-[10px] text-muted">Select a Kalenjin word, then its English meaning. Wrong taps cost accuracy.</p>
    </Card>
  );
}

function BuildGame({
  phrases,
  onFinish,
}: {
  words: Word[];
  phrases: Phrase[];
  onFinish: (score: number, total: number) => void;
}) {
  const rounds = useMemo(
    () =>
      shuffle(
        phrases
          .map((phrase) => ({
            ...phrase,
            tokens: phrase.kalenjin.replace(/[,.]/g, "").split(/\s+/).filter(Boolean),
          }))
          .filter((phrase) => phrase.tokens.length >= 2 && phrase.tokens.length <= 6),
      ).slice(0, 4),
    [phrases],
  );
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<string[]>([]);
  const [correctCount, setCorrectCount] = useState(0);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const round = rounds[index];
  const bank = useMemo(() => (round ? shuffle(round.tokens) : []), [round]);

  if (rounds.length === 0 || !round) {
    return (
      <Card className="p-4">
        <p className="text-xs text-muted">No multi-word phrases are verified for your variety yet, so the builder is unavailable.</p>
      </Card>
    );
  }

  function check() {
    const expected = round.tokens.join(" ").toLowerCase().replace(/[^\p{L}\p{N}'\s]/gu, "");
    const given = selected.join(" ").toLowerCase().replace(/[^\p{L}\p{N}'\s]/gu, "");
    const isCorrect = expected === given;
    setFeedback(isCorrect ? "correct" : "wrong");
    if (isCorrect) setCorrectCount((value) => value + 1);
    setTimeout(() => {
      if (index + 1 >= rounds.length) {
        const finalCorrect = correctCount + (isCorrect ? 1 : 0);
        onFinish(Math.round((finalCorrect / rounds.length) * 100), rounds.length);
      } else {
        setIndex(index + 1);
        setSelected([]);
        setFeedback(null);
      }
    }, 900);
  }

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <h3 className="display text-sm font-semibold text-ink">Sentence builder</h3>
        <span className="chip">
          {index + 1}/{rounds.length}
        </span>
      </div>
      <p className="mt-2 text-xs text-muted">Build the Kalenjin phrase for:</p>
      <p className="display text-lg font-semibold text-ink">{round.english}</p>
      <div className="mt-2 flex min-h-11 flex-wrap gap-1.5 rounded-xl border border-dashed border-line p-2">
        {selected.map((token, tokenIndex) => (
          <button
            key={`${token}-${tokenIndex}`}
            type="button"
            disabled={feedback !== null}
            onClick={() => setSelected((previous) => previous.filter((_, i) => i !== tokenIndex))}
            className="chip border-transparent bg-[var(--brand-soft)] text-[var(--brand)]"
          >
            {token}
          </button>
        ))}
      </div>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {bank.map((token, tokenIndex) => (
          <button
            key={`${token}-${tokenIndex}`}
            type="button"
            disabled={feedback !== null}
            onClick={() => setSelected((previous) => [...previous, token])}
            className="chip pressable"
          >
            {token}
          </button>
        ))}
      </div>
      <div className="mt-3 flex items-center gap-2">
        <button type="button" onClick={check} disabled={feedback !== null || selected.length === 0} className="btn btn-primary flex-1">
          Check
        </button>
        <StatusBadge status={round.status} />
      </div>
      {feedback ? (
        <p className={`mt-2 text-xs ${feedback === "correct" ? "text-[var(--brand)]" : "text-[color:var(--clay)]"}`}>
          {feedback === "correct" ? "Correct." : `Reviewed order: ${round.tokens.join(" ")}`}
        </p>
      ) : null}
    </Card>
  );
}

function ListenGame({ words, onFinish }: { words: Word[]; onFinish: (score: number, total: number) => void }) {
  const rounds = useMemo(() => shuffle(words).slice(0, 5), [words]);
  const [index, setIndex] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [chosen, setChosen] = useState<number | null>(null);
  const { speak } = useSpeechSynthesis();
  const round = rounds[index];
  const options = useMemo(() => {
    const distractors = shuffle(words.filter((word) => word.id !== round.id)).slice(0, 3);
    return shuffle([round, ...distractors]);
  }, [round, words]);

  function pick(id: number) {
    setChosen(id);
    const isCorrect = id === round.id;
    if (isCorrect) setCorrectCount((value) => value + 1);
    setTimeout(() => {
      if (index + 1 >= rounds.length) {
        const finalCorrect = correctCount + (isCorrect ? 1 : 0);
        onFinish(Math.round((finalCorrect / rounds.length) * 100), rounds.length);
      } else {
        setIndex(index + 1);
        setChosen(null);
      }
    }, 850);
  }

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <h3 className="display text-sm font-semibold text-ink">Listening challenge</h3>
        <span className="chip">
          {index + 1}/{rounds.length}
        </span>
      </div>
      <div className="mt-3 flex flex-col items-center gap-2 rounded-2xl bg-[var(--surface-muted)] p-4">
        <button
          type="button"
          onClick={() => speak(round.word, { lang: "kal", rate: 0.8 })}
          className="grid h-14 w-14 place-items-center rounded-full bg-[var(--brand)] text-[var(--brand-ink)]"
          aria-label="Play the word"
        >
          <Icon name="volume" size={24} />
        </button>
        <p className="text-[10px] text-muted">Tap to hear it again. Device voice, not a native recording.</p>
      </div>
      <div className="mt-3 flex flex-col gap-1.5">
        {options.map((option) => (
          <button
            key={option.id}
            type="button"
            disabled={chosen !== null}
            onClick={() => pick(option.id)}
            className={`rounded-xl border px-3 py-2 text-left text-xs transition ${
              chosen !== null && option.id === round.id
                ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]"
                : chosen === option.id
                  ? "border-[color:var(--danger)] text-[color:var(--danger)]"
                  : "border-line bg-surface text-ink"
            }`}
          >
            {option.definition}
          </button>
        ))}
      </div>
    </Card>
  );
}

function QuizGame({ words, onFinish }: { words: Word[]; onFinish: (score: number, total: number) => void }) {
  const rounds = useMemo(
    () =>
      shuffle(words)
        .slice(0, 5)
        .map((answer, index) => {
          const distractors = shuffle(words.filter((word) => word.id !== answer.id)).slice(0, 3);
          const askWord = index % 2 === 0;
          return {
            answer,
            askWord,
            options: shuffle([answer, ...distractors]),
          };
        }),
    [words],
  );
  const [index, setIndex] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [chosen, setChosen] = useState<number | null>(null);
  const round = rounds[index];

  function pick(id: number) {
    setChosen(id);
    const isCorrect = id === round.answer.id;
    if (isCorrect) setCorrectCount((value) => value + 1);
    setTimeout(() => {
      if (index + 1 >= rounds.length) {
        const finalCorrect = correctCount + (isCorrect ? 1 : 0);
        onFinish(Math.round((finalCorrect / rounds.length) * 100), rounds.length);
      } else {
        setIndex(index + 1);
        setChosen(null);
      }
    }, 800);
  }

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <h3 className="display text-sm font-semibold text-ink">Daily quiz</h3>
        <span className="chip">
          {index + 1}/{rounds.length}
        </span>
      </div>
      <p className="mt-2 display text-lg font-semibold text-ink">
        {round.askWord ? round.answer.word : round.answer.definition}
      </p>
      <p className="text-[11px] text-muted">{round.askWord ? "What does this mean?" : "Which Kalenjin word matches?"}</p>
      <div className="mt-2 flex flex-col gap-1.5">
        {round.options.map((option) => (
          <button
            key={option.id}
            type="button"
            disabled={chosen !== null}
            onClick={() => pick(option.id)}
            className={`rounded-xl border px-3 py-2 text-left text-xs transition ${
              chosen !== null && option.id === round.answer.id
                ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]"
                : chosen === option.id
                  ? "border-[color:var(--danger)] text-[color:var(--danger)]"
                  : "border-line bg-surface text-ink"
            }`}
          >
            {round.askWord ? option.definition : option.word}
          </button>
        ))}
      </div>
    </Card>
  );
}

function MemoryGame({ words, onFinish }: { words: Word[]; onFinish: (score: number, total: number) => void }) {
  const pairs = useMemo(() => shuffle(words).slice(0, 4), [words]);
  const cards = useMemo(
    () =>
      shuffle(
        pairs.flatMap((word) => [
          { key: `${word.id}-word`, id: word.id, label: word.word, kind: "word" as const },
          { key: `${word.id}-meaning`, id: word.id, label: word.definition, kind: "meaning" as const },
        ]),
      ),
    [pairs],
  );
  const [flipped, setFlipped] = useState<string[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);

  function flip(card: (typeof cards)[number]) {
    if (flipped.length >= 2 || flipped.includes(card.key) || matched.includes(card.id)) return;
    const next = [...flipped, card.key];
    setFlipped(next);
    if (next.length === 2) {
      setMoves((value) => value + 1);
      const [firstKey, secondKey] = next;
      const first = cards.find((item) => item.key === firstKey)!;
      const second = cards.find((item) => item.key === secondKey)!;
      if (first.id === second.id) {
        const nextMatched = [...matched, first.id];
        setMatched(nextMatched);
        setFlipped([]);
        if (nextMatched.length === pairs.length) {
          const score = Math.max(20, Math.round((pairs.length / (moves + 1)) * 100));
          setTimeout(() => onFinish(score, pairs.length), 400);
        }
      } else {
        setTimeout(() => setFlipped([]), 750);
      }
    }
  }

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <h3 className="display text-sm font-semibold text-ink">Memory pairs</h3>
        <span className="chip">
          {matched.length}/{pairs.length} found
        </span>
      </div>
      <div className="mt-3 grid grid-cols-4 gap-1.5">
        {cards.map((card) => {
          const revealed = flipped.includes(card.key) || matched.includes(card.id);
          return (
            <button
              key={card.key}
              type="button"
              onClick={() => flip(card)}
              className={`flex h-20 items-center justify-center rounded-xl border px-1 text-center text-[10px] font-medium leading-tight transition ${
                revealed
                  ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]"
                  : "border-line bg-[var(--brand)] text-transparent"
              }`}
              aria-label={revealed ? card.label : "Hidden card"}
            >
              {revealed ? card.label : "★"}
            </button>
          );
        })}
      </div>
      <p className="mt-2 text-[10px] text-muted">Match each Kalenjin word with its English meaning. Fewer moves, higher score.</p>
    </Card>
  );
}


function MissingWordGame({
  phrases,
  onFinish,
}: {
  phrases: Phrase[];
  onFinish: (score: number, total: number) => void;
}) {
  const rounds = useMemo(
    () =>
      shuffle(
        phrases
          .map((phrase) => ({
            ...phrase,
            tokens: phrase.kalenjin.replace(/[,.]/g, "").split(/\s+/).filter(Boolean),
          }))
          .filter((phrase) => phrase.tokens.length >= 3),
      ).slice(0, 4),
    [phrases],
  );
  const [index, setIndex] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [chosen, setChosen] = useState<string | null>(null);
  const round = rounds[index];
  const blankIndex = round ? Math.floor(round.tokens.length / 2) : 0;
  const answer = round ? round.tokens[blankIndex] : "";
  const options = useMemo(() => {
    if (!round) return [] as string[];
    const pool = Array.from(
      new Set(
        rounds
          .flatMap((item) => item.tokens)
          .filter((token) => token.toLowerCase() !== answer.toLowerCase()),
      ),
    );
    return shuffle([answer, ...shuffle(pool).slice(0, 3)]);
  }, [answer, round, rounds]);

  if (rounds.length === 0 || !round) {
    return (
      <Card className="p-4">
        <p className="text-xs text-muted">
          Not enough reviewed multi-word phrases exist for your variety to run this game yet.
        </p>
      </Card>
    );
  }

  function pick(option: string) {
    setChosen(option);
    const isCorrect = option === answer;
    if (isCorrect) setCorrectCount((value) => value + 1);
    setTimeout(() => {
      if (index + 1 >= rounds.length) {
        const finalCorrect = correctCount + (isCorrect ? 1 : 0);
        onFinish(Math.round((finalCorrect / rounds.length) * 100), rounds.length);
      } else {
        setIndex(index + 1);
        setChosen(null);
      }
    }, 850);
  }

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <h3 className="display text-sm font-semibold text-ink">Missing word</h3>
        <span className="chip">
          {index + 1}/{rounds.length}
        </span>
      </div>
      <p className="mt-2 text-[11px] text-muted">Complete the reviewed phrase for: {round.english}</p>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {round.tokens.map((token, tokenIndex) =>
          tokenIndex === blankIndex ? (
            <span
              key={`blank-${tokenIndex}`}
              className="rounded-lg border border-dashed border-[var(--brand)] px-2 py-1 text-sm font-semibold text-[var(--brand)]"
            >
              {chosen ?? "____"}
            </span>
          ) : (
            <span key={`${token}-${tokenIndex}`} className="rounded-lg bg-[var(--surface-muted)] px-2 py-1 text-sm text-ink">
              {token}
            </span>
          ),
        )}
      </div>
      <div className="mt-3 grid grid-cols-2 gap-1.5">
        {options.map((option) => (
          <button
            key={option}
            type="button"
            disabled={chosen !== null}
            onClick={() => pick(option)}
            className={`rounded-xl border px-3 py-2 text-xs transition ${
              chosen !== null && option === answer
                ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]"
                : chosen === option
                  ? "border-[color:var(--danger)] text-[color:var(--danger)]"
                  : "border-line bg-surface text-ink"
            }`}
          >
            {option}
          </button>
        ))}
      </div>
      {chosen ? (
        <p className="mt-2 text-[11px] text-muted">
          Reviewed phrase: {round.tokens.join(" ")} <StatusBadge status={round.status} />
        </p>
      ) : null}
    </Card>
  );
}
