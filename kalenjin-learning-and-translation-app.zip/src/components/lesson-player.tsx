"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { AudioButton, SlowAudioButton, SpeechNotice } from "@/components/audio";
import { Icon } from "@/components/icons";
import { Card, InfoNote, ProgressBar, ProgressRing, StatusBadge } from "@/components/ui";
import type { MaterializedExercise, SubmittedAnswer } from "@/lib/exercises";

type Concept = {
  conceptKey: string;
  word: string;
  definition: string;
  status: string;
  pronunciationGuide: string | null;
  note: string | null;
};

type Result = {
  score: number;
  xpEarned: number;
  results: { exerciseId: string; correct: boolean; expected: string; given: string }[];
  achievements: string[];
  alreadyCompleted: boolean;
};

export function LessonPlayer({
  slug,
  title,
  description,
  objectives,
  grammarNotes,
  concepts,
  exercises,
  nextSlug,
  completedScore,
}: {
  slug: string;
  title: string;
  description: string;
  objectives: string[];
  grammarNotes: string;
  concepts: Concept[];
  exercises: MaterializedExercise[];
  nextSlug: string | null;
  completedScore: number | null;
}) {
  const [stage, setStage] = useState<"intro" | "practice" | "summary">("intro");
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, SubmittedAnswer>>({});
  const [checked, setChecked] = useState(false);
  const [draft, setDraft] = useState("");
  const [selectedTokens, setSelectedTokens] = useState<string[]>([]);
  const [result, setResult] = useState<Result | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const exercise = exercises[index];
  const currentAnswer = exercise ? answers[exercise.id] : undefined;

  const localCorrect = useMemo(() => {
    if (!exercise || !currentAnswer) return false;
    if (exercise.kind === "arrange") {
      const given = selectedTokens.join(" ").toLowerCase().replace(/[^\p{L}\p{N}'\s]/gu, "");
      const expected = (exercise.correctSentence ?? "").toLowerCase().replace(/[^\p{L}\p{N}'\s]/gu, "");
      return given === expected;
    }
    if (exercise.options.length > 0) {
      return currentAnswer.optionId === exercise.correctOptionId;
    }
    const given = (currentAnswer.text ?? "").toLowerCase().trim();
    return exercise.accepted.some((value) => value.toLowerCase().trim() === given);
  }, [currentAnswer, exercise, selectedTokens]);

  if (exercises.length === 0) {
    return (
      <Card className="p-5">
        <InfoNote tone="warn">
          This lesson has no exercises for your selected variety yet. Switch variety in Profile or contribute the
          missing vocabulary so exercises can be generated without borrowing from another dialect.
        </InfoNote>
        <Link href="/learn" className="btn btn-secondary mt-3 w-full">
          Back to lessons
        </Link>
      </Card>
    );
  }

  function recordAnswer(answer: SubmittedAnswer) {
    if (!exercise) return;
    setAnswers((previous) => ({ ...previous, [exercise.id]: answer }));
  }

  function check() {
    if (!exercise) return;
    if (exercise.kind === "arrange") {
      recordAnswer({ tokens: selectedTokens });
    } else if (exercise.options.length > 0) {
      if (!currentAnswer?.optionId) {
        setError("Choose an option first.");
        return;
      }
    } else {
      if (!draft.trim()) {
        setError("Type your answer first.");
        return;
      }
      recordAnswer({ text: draft });
    }
    setError(null);
    setChecked(true);
  }

  async function next() {
    setChecked(false);
    setError(null);
    setDraft("");
    setSelectedTokens([]);
    if (index + 1 < exercises.length) {
      setIndex(index + 1);
      return;
    }
    await finish();
  }

  async function finish() {
    setSaving(true);
    setError(null);
    try {
      const response = await fetch(`/api/lessons/${slug}/complete`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ answers }),
      });
      const data = (await response.json()) as Result & { ok: boolean; error?: string };
      if (!response.ok || !data.ok) {
        setError(data.error ?? "Could not save your progress.");
        return;
      }
      setResult({
        score: data.score,
        xpEarned: data.xpEarned,
        results: data.results,
        achievements: data.achievements,
        alreadyCompleted: data.alreadyCompleted,
      });
      setStage("summary");
    } catch {
      setError("Network error. Your answers are kept on this screen — try saving again.");
    } finally {
      setSaving(false);
    }
  }

  if (stage === "intro") {
    return (
      <div className="flex flex-col gap-4">
        <Card className="p-4">
          <p className="label">Lesson objectives</p>
          <ul className="mt-2 space-y-1.5">
            {objectives.map((objective) => (
              <li key={objective} className="flex gap-2 text-xs leading-relaxed text-ink">
                <Icon name="check" size={14} className="mt-0.5 shrink-0 text-[var(--brand)]" />
                {objective}
              </li>
            ))}
          </ul>
          <p className="mt-3 text-xs leading-relaxed text-muted">{description}</p>
          {completedScore !== null ? (
            <p className="mt-2 chip border-transparent bg-[var(--brand-soft)] text-[var(--brand)]">
              Previously completed · best score {completedScore}%
            </p>
          ) : null}
          <button type="button" onClick={() => setStage("practice")} className="btn btn-primary mt-3 w-full">
            <Icon name="play" size={15} filled /> Start {exercises.length} exercises
          </button>
        </Card>

        <Card className="p-4">
          <p className="label">New vocabulary for your variety</p>
          <ul className="mt-2 divide-y divide-[var(--line)]">
            {concepts.length === 0 ? (
              <li className="py-3 text-xs text-muted">No vocabulary available for this lesson in your variety yet.</li>
            ) : (
              concepts.map((concept) => (
                <li key={concept.conceptKey} className="flex items-start justify-between gap-2 py-2.5">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <p className="display text-base font-semibold text-ink">{concept.word}</p>
                      <StatusBadge status={concept.status} />
                    </div>
                    <p className="text-xs text-muted">{concept.definition}</p>
                    {concept.pronunciationGuide ? (
                      <p className="text-[10px] text-muted">Say it: {concept.pronunciationGuide}</p>
                    ) : null}
                    {concept.note ? (
                      <p className="mt-0.5 text-[10px] leading-relaxed text-muted">{concept.note}</p>
                    ) : null}
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <AudioButton text={concept.word} lang="kal" size="sm" />
                    <SlowAudioButton text={concept.word} />
                  </div>
                </li>
              ))
            )}
          </ul>
          <div className="mt-2">
            <SpeechNotice lang="kal" />
          </div>
        </Card>

        <Card className="p-4">
          <p className="label">Grammar notes</p>
          <p className="mt-1.5 text-xs leading-relaxed text-muted">{grammarNotes}</p>
        </Card>
      </div>
    );
  }

  if (stage === "summary" && result) {
    const passed = result.score >= 60;
    return (
      <div className="flex flex-col gap-4">
        <Card className="flex flex-col items-center p-5 text-center">
          <ProgressRing value={result.score} size={116} stroke={10}>
            <span className="display text-2xl font-bold text-ink">{result.score}%</span>
            <span className="text-[10px] font-semibold uppercase text-muted">score</span>
          </ProgressRing>
          <h2 className="display mt-3 text-lg font-semibold text-ink">
            {passed ? "Well done — kogoi!" : "Good effort — review and try again"}
          </h2>
          <p className="mt-1 text-xs text-muted">
            +{result.xpEarned} XP{result.alreadyCompleted ? " (review session)" : ""} · progress saved to your account
          </p>
          {result.achievements.length > 0 ? (
            <p className="chip mt-2 border-transparent bg-[var(--gold-soft)] text-[color:var(--clay)]">
              <Icon name="trophy" size={12} /> New achievement unlocked
            </p>
          ) : null}
          <div className="mt-3 flex w-full flex-col gap-2">
            {nextSlug ? (
              <Link href={`/learn/${nextSlug}`} className="btn btn-primary w-full">
                Next lesson <Icon name="arrowRight" size={15} />
              </Link>
            ) : (
              <Link href="/learn" className="btn btn-primary w-full">
                Back to curriculum
              </Link>
            )}
            <button
              type="button"
              onClick={() => {
                setStage("intro");
                setIndex(0);
                setAnswers({});
                setResult(null);
              }}
              className="btn btn-outline w-full"
            >
              <Icon name="refresh" size={15} /> Practise again
            </button>
          </div>
        </Card>

        <Card className="p-4">
          <p className="label">Answer review</p>
          <ul className="mt-2 divide-y divide-[var(--line)]">
            {result.results.map((item, itemIndex) => {
              const exerciseInfo = exercises.find((entry) => entry.id === item.exerciseId);
              return (
                <li key={item.exerciseId} className="py-2.5">
                  <div className="flex items-center gap-2">
                    <span
                      className={`grid h-5 w-5 shrink-0 place-items-center rounded-full ${
                        item.correct
                          ? "bg-[var(--brand-soft)] text-[var(--brand)]"
                          : "bg-[var(--gold-soft)] text-[color:var(--clay)]"
                      }`}
                    >
                      <Icon name={item.correct ? "check" : "close"} size={12} />
                    </span>
                    <p className="text-xs font-medium text-ink">
                      {itemIndex + 1}. {exerciseInfo?.prompt ?? ""}
                    </p>
                  </div>
                  <p className="ml-7 text-[11px] text-muted">
                    Expected: <strong className="text-ink">{item.expected}</strong>
                    {item.given ? ` · You: ${item.given}` : " · no answer"}
                  </p>
                </li>
              );
            })}
          </ul>
        </Card>
      </div>
    );
  }

  if (!exercise) return null;

  return (
    <div className="flex flex-col gap-4">
      <div>
        <div className="mb-1.5 flex items-center justify-between text-[11px] font-semibold text-muted">
          <span>
            Exercise {index + 1} of {exercises.length}
          </span>
          <span>{Math.round(((index + (checked ? 1 : 0)) / exercises.length) * 100)}%</span>
        </div>
        <ProgressBar value={((index + (checked ? 1 : 0)) / exercises.length) * 100} />
      </div>

      <Card className="p-4">
        <p className="text-[10px] font-bold uppercase tracking-wide text-[var(--brand)]">{exercise.instruction}</p>

        {exercise.kind === "listen" ? (
          <div className="mt-3 flex flex-col items-center gap-2 rounded-2xl bg-[var(--surface-muted)] p-4">
            <AudioButton text={exercise.audioText ?? exercise.prompt} lang="kal" variant="solid" label="Play recording" />
            <p className="text-[10px] text-muted">Listen first. The word is hidden until you answer.</p>
          </div>
        ) : (
          <div className="mt-2">
            <p className="display text-2xl font-bold leading-snug text-ink">{exercise.prompt}</p>
            {exercise.kind === "type_definition" || exercise.kind === "mcq_meaning" ? (
              <div className="mt-1.5 flex items-center gap-2">
                <AudioButton text={exercise.audioText ?? exercise.prompt} lang="kal" size="sm" />
                <span className="text-[10px] text-muted">{exercise.promptLanguage === "kal" ? "Kalenjin" : "English"}</span>
              </div>
            ) : null}
          </div>
        )}

        {exercise.options.length > 0 ? (
          <div className="mt-3 flex flex-col gap-2">
            {exercise.options.map((option) => {
              const selected = currentAnswer?.optionId === option.id;
              const isCorrect = checked && option.id === exercise.correctOptionId;
              const isWrong = checked && selected && option.id !== exercise.correctOptionId;
              return (
                <button
                  key={option.id}
                  type="button"
                  disabled={checked}
                  onClick={() => recordAnswer({ optionId: option.id })}
                  className={`flex items-center justify-between rounded-2xl border px-3.5 py-3 text-left text-sm transition ${
                    isCorrect
                      ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]"
                      : isWrong
                        ? "border-[color:var(--danger)] bg-[color:var(--danger)]/10 text-[color:var(--danger)]"
                        : selected
                          ? "border-[var(--brand)] bg-[var(--brand-soft)]/50 text-ink"
                          : "border-line bg-surface text-ink"
                  }`}
                >
                  <span>{option.label}</span>
                  {isCorrect ? <Icon name="check" size={16} /> : null}
                </button>
              );
            })}
          </div>
        ) : exercise.kind === "arrange" ? (
          <div className="mt-3">
            <div className="flex min-h-12 flex-wrap items-center gap-1.5 rounded-2xl border border-dashed border-line p-2">
              {selectedTokens.length === 0 ? (
                <span className="px-1 text-xs text-muted">Tap the words below in the correct order.</span>
              ) : (
                selectedTokens.map((token, tokenIndex) => (
                  <button
                    key={`${token}-${tokenIndex}`}
                    type="button"
                    disabled={checked}
                    onClick={() => setSelectedTokens((previous) => previous.filter((_, i) => i !== tokenIndex))}
                    className="chip border-transparent bg-[var(--brand-soft)] text-[var(--brand)]"
                  >
                    {token} <Icon name="close" size={10} />
                  </button>
                ))
              )}
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {exercise.tokens?.map((token, tokenIndex) => {
                const used = selectedTokens.filter((value) => value === token).length;
                const total = exercise.tokens!.filter((value) => value === token).length;
                return (
                  <button
                    key={`${token}-${tokenIndex}`}
                    type="button"
                    disabled={checked || used >= total}
                    onClick={() => setSelectedTokens((previous) => [...previous, token])}
                    className="chip pressable disabled:opacity-40"
                  >
                    {token}
                  </button>
                );
              })}
            </div>
            <p className="mt-2 text-[10px] text-muted">English: {exercise.prompt}</p>
          </div>
        ) : (
          <input
            type="text"
            value={checked ? (currentAnswer?.text ?? "") : draft}
            onChange={(event) => setDraft(event.target.value)}
            disabled={checked}
            placeholder="Type your answer"
            className="input mt-3"
            autoComplete="off"
            autoCapitalize="none"
            spellCheck={false}
          />
        )}

        {error ? <p className="mt-2 text-xs text-[color:var(--danger)]">{error}</p> : null}

        {checked ? (
          <div
            className={`mt-3 rounded-2xl border p-3 text-xs leading-relaxed ${
              localCorrect
                ? "border-[var(--brand)] bg-[var(--brand-soft)]/40 text-ink"
                : "border-[color:var(--gold)]/50 bg-[var(--gold-soft)]/50 text-ink"
            }`}
          >
            <p className="font-semibold">{localCorrect ? "Correct" : "Not quite yet"}</p>
            <p className="mt-1 text-muted">{exercise.explanation}</p>
          </div>
        ) : null}

        <div className="mt-3 flex gap-2">
          {!checked ? (
            <button type="button" onClick={check} className="btn btn-primary flex-1">
              <Icon name="check" size={15} /> Check answer
            </button>
          ) : (
            <button type="button" onClick={() => void next()} disabled={saving} className="btn btn-primary flex-1">
              {saving ? "Saving…" : index + 1 === exercises.length ? "Finish lesson" : "Continue"}
              <Icon name="arrowRight" size={15} />
            </button>
          )}
        </div>
      </Card>

      <p className="text-center text-[10px] text-muted">
        Progress is graded again on the server before XP is awarded.
      </p>
    </div>
  );
}
