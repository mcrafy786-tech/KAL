"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { AudioButton } from "@/components/audio";
import { Icon } from "@/components/icons";
import { Card, EmptyState } from "@/components/ui";

type Pack = {
  slug: string;
  title: string;
  savedAt: string;
  concepts: { word: string; definition: string; pronunciationGuide: string | null; status: string }[];
  phrases: { english: string; kalenjin: string }[];
  exercises: number;
};

export function OfflineManager() {
  const [packs, setPacks] = useState<Pack[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        setPacks(JSON.parse(localStorage.getItem("kal-offline-packs") ?? "[]") as Pack[]);
      } catch {
        setPacks([]);
      }
      setLoaded(true);
    }, 0);
    return () => clearTimeout(timer);
  }, []);

  function remove(slug: string) {
    const next = packs.filter((pack) => pack.slug !== slug);
    setPacks(next);
    try {
      localStorage.setItem("kal-offline-packs", JSON.stringify(next));
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <Card className="p-4">
        <p className="flex items-center gap-1.5 text-xs font-bold text-ink">
          <Icon name="check" size={14} className="text-[var(--brand)]" /> Works offline on this device
        </p>
        <ul className="mt-1.5 space-y-1 text-[11px] text-muted">
          <li>• Downloaded lesson vocabulary, phrases and exercise counts</li>
          <li>• The app shell and previously visited screens</li>
          <li>• Device text-to-speech for saved words, if your phone has a matching voice</li>
          <li>• Saved translations already stored on this device&apos;s screen cache</li>
        </ul>
      </Card>

      {!loaded ? null : packs.length === 0 ? (
        <EmptyState
          icon="download"
          title="No offline packs yet"
          body="Open any lesson and tap “Save for offline”. The pack stores vocabulary, reviewed phrases and pronunciation guides on this device."
          action={
            <Link href="/learn" className="btn btn-secondary mt-1">
              Browse lessons
            </Link>
          }
        />
      ) : (
        <div className="flex flex-col gap-2">
          {packs.map((pack) => (
            <Card key={pack.slug} className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="display text-sm font-semibold text-ink">{pack.title}</h3>
                  <p className="text-[10px] text-muted">
                    Saved {new Date(pack.savedAt).toLocaleDateString()} · {pack.concepts.length} words ·{" "}
                    {pack.exercises} exercises
                  </p>
                </div>
                <button type="button" onClick={() => remove(pack.slug)} className="chip pressable" aria-label="Remove pack">
                  <Icon name="trash" size={12} /> Remove
                </button>
              </div>
              <ul className="mt-2 divide-y divide-[var(--line)]">
                {pack.concepts.slice(0, 6).map((concept) => (
                  <li key={concept.word} className="flex items-center justify-between gap-2 py-1.5">
                    <span className="min-w-0">
                      <span className="block text-xs font-semibold text-ink">{concept.word}</span>
                      <span className="block truncate text-[10px] text-muted">{concept.definition}</span>
                    </span>
                    <AudioButton text={concept.word} lang="kal" size="sm" />
                  </li>
                ))}
              </ul>
              <Link href={`/learn/${pack.slug}`} className="btn btn-outline mt-2 w-full">
                Open lesson
              </Link>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
