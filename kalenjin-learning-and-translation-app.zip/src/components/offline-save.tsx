"use client";

import { useEffect, useState } from "react";
import { Icon } from "@/components/icons";

type Pack = {
  slug: string;
  title: string;
  savedAt: string;
  concepts: { word: string; definition: string; pronunciationGuide: string | null; status: string }[];
  phrases: { english: string; kalenjin: string }[];
  exercises: number;
};

export function OfflineSave({
  pack,
}: {
  pack: Omit<Pack, "savedAt">;
}) {
  const [saved, setSaved] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        const packs = JSON.parse(localStorage.getItem("kal-offline-packs") ?? "[]") as Pack[];
        setSaved(packs.some((item) => item.slug === pack.slug));
      } catch {
        setSaved(false);
      }
    }, 0);
    return () => clearTimeout(timer);
  }, [pack.slug]);

  function save() {
    try {
      const packs = JSON.parse(localStorage.getItem("kal-offline-packs") ?? "[]") as Pack[];
      const next = packs.filter((item) => item.slug !== pack.slug);
      next.unshift({ ...pack, savedAt: new Date().toISOString() });
      localStorage.setItem("kal-offline-packs", JSON.stringify(next.slice(0, 20)));
      setSaved(true);
      setMessage("Saved on this device. Audio, translation and the tutor still need internet.");
      setTimeout(() => setMessage(null), 3500);
    } catch {
      setMessage("This browser blocked local storage, so the pack could not be saved.");
    }
  }

  return (
    <div className="mb-3">
      <button type="button" onClick={save} className="chip pressable" aria-pressed={saved}>
        <Icon name={saved ? "check" : "download"} size={12} />
        {saved ? "Saved offline" : "Save for offline"}
      </button>
      {message ? <p className="mt-1 text-[10px] text-muted">{message}</p> : null}
    </div>
  );
}
