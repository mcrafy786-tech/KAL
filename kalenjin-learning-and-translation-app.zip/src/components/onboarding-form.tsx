"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Icon } from "@/components/icons";
import { ProgressBar } from "@/components/ui";

type Dialect = { id: number; code: string; name: string; region: string; description: string };

const LEVELS = [
  { id: "beginner", label: "Beginner", hint: "I am starting from zero" },
  { id: "elementary", label: "Elementary", hint: "I know greetings and numbers" },
  { id: "intermediate", label: "Intermediate", hint: "I can hold a simple conversation" },
  { id: "upper_intermediate", label: "Upper intermediate", hint: "I understand everyday speech" },
  { id: "advanced", label: "Advanced", hint: "I want idiom, culture and precision" },
];

const GOALS = [5, 10, 15, 20, 30];

export function OnboardingForm({
  dialects,
  defaultDialectCode,
  defaultLevel,
}: {
  dialects: Dialect[];
  defaultDialectCode: string;
  defaultLevel: string;
}) {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [language, setLanguage] = useState("en");
  const [dialectCode, setDialectCode] = useState(defaultDialectCode);
  const [level, setLevel] = useState(defaultLevel);
  const [goal, setGoal] = useState(10);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const steps = ["Interface", "Variety", "Level", "Daily goal"];
  const selectedDialect = dialects.find((dialect) => dialect.code === dialectCode);

  async function finish() {
    setBusy(true);
    setError(null);
    try {
      const response = await fetch("/api/preferences", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          preferredLanguage: language,
          dialectCode,
          proficiencyLevel: level,
          dailyGoalMinutes: goal,
          onboarded: true,
        }),
      });
      const data = (await response.json()) as { ok: boolean; error?: string };
      if (!response.ok || !data.ok) {
        setError(data.error ?? "Could not save your preferences.");
        return;
      }
      router.replace("/home");
      router.refresh();
    } catch {
      setError("Network error while saving. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <div className="mb-1 flex items-center justify-between text-[11px] font-semibold text-muted">
          <span>
            Step {step + 1} of {steps.length}
          </span>
          <span>{steps[step]}</span>
        </div>
        <ProgressBar value={((step + 1) / steps.length) * 100} />
      </div>

      {step === 0 ? (
        <div className="card p-5 fade-up">
          <h1 className="display text-xl font-bold text-ink">How should the app speak to you?</h1>
          <p className="mt-1 text-xs text-muted">
            The interface language is separate from the Kalenjin variety you are learning.
          </p>
          <div className="mt-3 flex flex-col gap-2">
            {[
              { id: "en", label: "English", hint: "Explanations, tutor and interface in English" },
              { id: "sw", label: "Kiswahili", hint: "Interface labels in Kiswahili (explanations remain English for now)" },
            ].map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => setLanguage(option.id)}
                className={`rounded-2xl border p-3 text-left transition ${
                  language === option.id ? "border-[var(--brand)] bg-[var(--brand-soft)]/50" : "border-line bg-surface"
                }`}
              >
                <p className="text-sm font-semibold text-ink">{option.label}</p>
                <p className="text-[11px] text-muted">{option.hint}</p>
              </button>
            ))}
          </div>
        </div>
      ) : null}

      {step === 1 ? (
        <div className="card p-5 fade-up">
          <h1 className="display text-xl font-bold text-ink">Which Kalenjin variety will you learn?</h1>
          <p className="mt-1 text-xs text-muted">
            Vocabulary, pronunciation and phrasebook stay inside the variety you choose. Nothing is mixed silently.
          </p>
          <div className="mt-3 flex flex-col gap-2">
            {dialects.map((dialect) => (
              <button
                key={dialect.code}
                type="button"
                onClick={() => setDialectCode(dialect.code)}
                className={`rounded-2xl border p-3 text-left transition ${
                  dialectCode === dialect.code ? "border-[var(--brand)] bg-[var(--brand-soft)]/50" : "border-line bg-surface"
                }`}
              >
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-ink">{dialect.name}</p>
                  <span className="chip">{dialect.region}</span>
                </div>
                <p className="mt-0.5 text-[11px] leading-snug text-muted">{dialect.description}</p>
              </button>
            ))}
          </div>
          {selectedDialect ? (
            <p className="mt-3 rounded-xl bg-[var(--surface-muted)] px-3 py-2 text-[10px] leading-relaxed text-muted">
              Coverage for {selectedDialect.name} is growing from native-speaker contributions. If an entry is missing,
              the app tells you — it never substitutes another variety.
            </p>
          ) : null}
        </div>
      ) : null}

      {step === 2 ? (
        <div className="card p-5 fade-up">
          <h1 className="display text-xl font-bold text-ink">What is your current level?</h1>
          <p className="mt-1 text-xs text-muted">
            This sets where the tutor starts and how much explanation you get. You can change it any time.
          </p>
          <div className="mt-3 flex flex-col gap-2">
            {LEVELS.map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => setLevel(option.id)}
                className={`flex items-center justify-between rounded-2xl border p-3 text-left transition ${
                  level === option.id ? "border-[var(--brand)] bg-[var(--brand-soft)]/50" : "border-line bg-surface"
                }`}
              >
                <span>
                  <span className="block text-sm font-semibold text-ink">{option.label}</span>
                  <span className="block text-[11px] text-muted">{option.hint}</span>
                </span>
                {level === option.id ? <Icon name="check" size={16} className="text-[var(--brand)]" /> : null}
              </button>
            ))}
          </div>
        </div>
      ) : null}

      {step === 3 ? (
        <div className="card p-5 fade-up">
          <h1 className="display text-xl font-bold text-ink">Set a daily goal you can keep</h1>
          <p className="mt-1 text-xs text-muted">
            Progress counts real minutes, completed lessons and reviews — not simply opening the app.
          </p>
          <div className="mt-3 grid grid-cols-5 gap-1.5">
            {GOALS.map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => setGoal(value)}
                className={`rounded-2xl border py-3 text-center transition ${
                  goal === value ? "border-[var(--brand)] bg-[var(--brand-soft)]/60" : "border-line bg-surface"
                }`}
              >
                <span className="display block text-lg font-bold text-ink">{value}</span>
                <span className="text-[10px] text-muted">min</span>
              </button>
            ))}
          </div>
          <div className="mt-4 rounded-2xl border border-line p-3">
            <p className="label">Your setup</p>
            <ul className="mt-1.5 space-y-1 text-xs text-muted">
              <li>Variety: <strong className="text-ink">{selectedDialect?.name ?? dialectCode}</strong></li>
              <li>Level: <strong className="text-ink">{LEVELS.find((option) => option.id === level)?.label ?? level}</strong></li>
              <li>Goal: <strong className="text-ink">{goal} minutes per day</strong></li>
              <li>Interface: <strong className="text-ink">{language === "sw" ? "Kiswahili" : "English"}</strong></li>
            </ul>
          </div>
        </div>
      ) : null}

      {error ? <p className="text-xs text-[color:var(--danger)]">{error}</p> : null}

      <div className="flex gap-2">
        {step > 0 ? (
          <button type="button" onClick={() => setStep(step - 1)} className="btn btn-outline flex-1">
            Back
          </button>
        ) : null}
        {step < steps.length - 1 ? (
          <button type="button" onClick={() => setStep(step + 1)} className="btn btn-primary flex-1">
            Continue <Icon name="arrowRight" size={15} />
          </button>
        ) : (
          <button type="button" onClick={() => void finish()} disabled={busy} className="btn btn-primary flex-1">
            {busy ? "Saving…" : "Start learning"} <Icon name="sparkles" size={15} />
          </button>
        )}
      </div>
    </div>
  );
}
