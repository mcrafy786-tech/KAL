"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Icon } from "@/components/icons";
import { Card } from "@/components/ui";

type Dialect = { id: number; code: string; name: string };

const LEVELS = [
  { id: "beginner", label: "Beginner" },
  { id: "elementary", label: "Elementary" },
  { id: "intermediate", label: "Intermediate" },
  { id: "upper_intermediate", label: "Upper intermediate" },
  { id: "advanced", label: "Advanced" },
];
const GOALS = [5, 10, 15, 20, 30];

export function ProfileClient({
  user,
  dialects,
}: {
  user: {
    username: string;
    email: string;
    role: string;
    dialectCode: string | null;
    proficiencyLevel: string;
    dailyGoalMinutes: number;
    preferredLanguage: string;
    theme: string;
  };
  dialects: Dialect[];
}) {
  const router = useRouter();
  const [dialectCode, setDialectCode] = useState(user.dialectCode ?? dialects[0]?.code ?? "kipsigis");
  const [level, setLevel] = useState(user.proficiencyLevel);
  const [goal, setGoal] = useState(user.dailyGoalMinutes);
  const [language, setLanguage] = useState(user.preferredLanguage);
  const [theme, setTheme] = useState(user.theme);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function save() {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const response = await fetch("/api/preferences", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          dialectCode,
          proficiencyLevel: level,
          dailyGoalMinutes: goal,
          preferredLanguage: language,
          theme,
        }),
      });
      const data = (await response.json()) as { ok: boolean; error?: string };
      if (!response.ok || !data.ok) {
        setError(data.error ?? "Could not save changes.");
        return;
      }
      setMessage("Preferences saved. Lesson content refreshes to your variety.");
      router.refresh();
    } catch {
      setError("Network error while saving preferences.");
    } finally {
      setBusy(false);
    }
  }

  function applyTheme(next: string) {
    setTheme(next);
    const resolved = next === "system" ? (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light") : next;
    document.documentElement.dataset.theme = resolved;
    try {
      localStorage.setItem("kal-theme", next === "system" ? resolved : next);
    } catch {
      /* ignore */
    }
  }

  async function clearHistory() {
    if (!window.confirm("Delete all saved translations and conversation history? This cannot be undone.")) return;
    try {
      const response = await fetch("/api/translations", { method: "DELETE" });
      setMessage(response.ok ? "Translation history deleted." : "Could not delete history.");
      router.refresh();
    } catch {
      setError("Network error while deleting history.");
    }
  }

  async function signOut() {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    router.replace("/");
    router.refresh();
  }

  return (
    <div className="flex flex-col gap-3">
      <Card className="p-4" as="section">
        <div id="variety" className="scroll-mt-24">
          <h2 className="display text-sm font-semibold text-ink">Your Kalenjin variety</h2>
          <p className="text-[11px] text-muted">
            Switching variety changes lessons, dictionary, games and translations. Nothing is merged between varieties.
          </p>
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            {dialects.map((dialect) => (
              <button
                key={dialect.code}
                type="button"
                onClick={() => setDialectCode(dialect.code)}
                className={`rounded-xl border px-2.5 py-2 text-xs font-semibold transition ${
                  dialectCode === dialect.code
                    ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]"
                    : "border-line bg-surface text-ink"
                }`}
              >
                {dialect.name}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-3">
          <p className="label">Proficiency level</p>
          <select value={level} onChange={(event) => setLevel(event.target.value)} className="select mt-1">
            {LEVELS.map((option) => (
              <option key={option.id} value={option.id}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        <div className="mt-3">
          <p className="label">Daily goal</p>
          <div className="mt-1 grid grid-cols-5 gap-1.5">
            {GOALS.map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => setGoal(value)}
                className={`rounded-xl border py-2 text-xs font-semibold transition ${
                  goal === value ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]" : "border-line bg-surface text-ink"
                }`}
              >
                {value}m
              </button>
            ))}
          </div>
        </div>

        <div className="mt-3">
          <p className="label">Interface language</p>
          <div className="mt-1 flex gap-1.5">
            {[
              { id: "en", label: "English" },
              { id: "sw", label: "Kiswahili" },
            ].map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => setLanguage(option.id)}
                className={`flex-1 rounded-xl border px-2 py-2 text-xs font-semibold transition ${
                  language === option.id
                    ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]"
                    : "border-line bg-surface text-ink"
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-3">
          <p className="label">Appearance</p>
          <div className="mt-1 flex gap-1.5">
            {["light", "dark", "system"].map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => applyTheme(option)}
                className={`flex flex-1 items-center justify-center gap-1 rounded-xl border px-2 py-2 text-xs font-semibold capitalize transition ${
                  theme === option ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]" : "border-line bg-surface text-ink"
                }`}
              >
                <Icon name={option === "dark" ? "moon" : option === "light" ? "sun" : "settings"} size={13} />
                {option}
              </button>
            ))}
          </div>
        </div>

        {message ? <p className="mt-2 text-xs text-[var(--brand)]">{message}</p> : null}
        {error ? <p className="mt-2 text-xs text-[color:var(--danger)]">{error}</p> : null}

        <button type="button" onClick={() => void save()} disabled={busy} className="btn btn-primary mt-3 w-full">
          {busy ? "Saving…" : "Save preferences"}
        </button>
      </Card>

      <Card className="p-4" as="section">
        <h2 className="display text-sm font-semibold text-ink">Account & privacy</h2>
        <p className="mt-1 text-[11px] text-muted">
          Signed in as {user.username} ({user.email}) · role: {user.role}
        </p>
        <ul className="mt-2 space-y-1 text-[11px] text-muted">
          <li>• Voice recordings made in pronunciation practice never leave your device.</li>
          <li>• Translations are stored so you can revisit them; you can delete them at any time.</li>
          <li>• Contributor recordings are stored only with explicit speaker consent and reviewer approval.</li>
          <li>• API keys for speech/AI providers live on the server and are never shipped to the app.</li>
        </ul>
        <div className="mt-3 flex flex-col gap-2">
          <button type="button" onClick={() => void clearHistory()} className="btn btn-outline w-full">
            <Icon name="trash" size={15} /> Delete my translation history
          </button>
          <button type="button" onClick={() => void signOut()} className="btn btn-secondary w-full">
            <Icon name="logout" size={15} /> Sign out
          </button>
        </div>
      </Card>
    </div>
  );
}
