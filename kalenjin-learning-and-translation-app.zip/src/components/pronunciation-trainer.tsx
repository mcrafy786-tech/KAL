"use client";

import { useState } from "react";
import { AudioButton, SlowAudioButton, SpeechNotice } from "@/components/audio";
import { Icon } from "@/components/icons";
import { Card, InfoNote, StatusBadge } from "@/components/ui";
import { useSpeechSynthesis, useVoiceRecorder } from "@/lib/use-speech";

type Word = {
  word: string;
  definition: string;
  pronunciationGuide: string | null;
  verificationStatus: string;
  verificationNote: string | null;
};

export function PronunciationTrainer({ words, dialectName }: { words: Word[]; dialectName: string }) {
  const [index, setIndex] = useState(0);
  const { speak } = useSpeechSynthesis();
  const recorder = useVoiceRecorder();
  const word = words[index];

  if (!word) {
    return (
      <Card className="p-5">
        <p className="text-sm text-ink">No pronunciation entries are available for {dialectName} yet.</p>
      </Card>
    );
  }

  const tips: string[] = [];
  if (/ng'/.test(word.word)) tips.push("The ng' sound is a single velar nasal — keep the back of your tongue raised and do not add a hard g.");
  if (/'/.test(word.word)) tips.push("An apostrophe marks a distinct sound, not a pause. Practise the word again without dropping it.");
  if (/[aeiou]/i.test(word.word)) tips.push("Kalenjin vowels have tense/lax distinctions (for example a vs aa). Listen for length, not just quality.");
  tips.push("Ask a native speaker to record this word if no recording is attached. Your own recording is stored only on this device.");

  return (
    <div className="flex flex-col gap-3">
      <InfoNote tone="warn">
        This module does not give an accuracy score. No validated Kalenjin pronunciation-comparison model is integrated,
        so scoring your voice would be misleading. You compare your recording with the reference by ear.
      </InfoNote>

      <Card className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wide text-[var(--gold)]">
              Word {index + 1} of {words.length}
            </p>
            <h2 className="display text-3xl font-bold leading-tight text-ink">{word.word}</h2>
            <p className="text-sm text-muted">{word.definition}</p>
          </div>
          <StatusBadge status={word.verificationStatus} />
        </div>

        {word.pronunciationGuide ? (
          <p className="mt-2 rounded-xl bg-[var(--surface-muted)] px-3 py-2 text-xs text-ink">
            Say it: <strong>{word.pronunciationGuide}</strong>
          </p>
        ) : null}

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <AudioButton text={word.word} lang="kal" variant="solid" label="Reference" />
          <SlowAudioButton text={word.word} />
          <button
            type="button"
            onClick={() => (recorder.recording ? recorder.stop() : void recorder.start())}
            className={`btn ${recorder.recording ? "btn-gold recording-pulse" : "btn-secondary"}`}
          >
            <Icon name={recorder.recording ? "stop" : "mic"} size={15} />
            {recorder.recording ? "Stop" : "Record yourself"}
          </button>
        </div>

        {recorder.error ? <p className="mt-2 text-xs text-[color:var(--clay)]">{recorder.error}</p> : null}

        {recorder.audioUrl ? (
          <div className="mt-3 rounded-2xl border border-line p-3">
            <p className="text-[10px] font-bold uppercase tracking-wide text-muted">Your recording</p>
            <audio controls src={recorder.audioUrl} className="mt-1 w-full" />
            <p className="mt-1 text-[10px] text-muted">
              Held in this browser tab only. Nothing is uploaded, so nothing is retained after you leave the page.
            </p>
          </div>
        ) : null}

        {word.verificationNote ? (
          <p className="mt-2 text-[10px] leading-relaxed text-muted">{word.verificationNote}</p>
        ) : null}
      </Card>

      <Card className="p-4">
        <p className="label">Pronunciation guidance</p>
        <ul className="mt-2 space-y-1.5">
          {tips.map((tip) => (
            <li key={tip} className="flex gap-2 text-[11px] leading-relaxed text-muted">
              <Icon name="info" size={13} className="mt-0.5 shrink-0 text-[var(--brand)]" />
              {tip}
            </li>
          ))}
        </ul>
        <p className="mt-2 text-[10px] text-muted">
          Practice loop: listen at normal speed → listen slowly → record → play both → repeat three times.
        </p>
        <button
          type="button"
          onClick={() => {
            recorder.reset();
            setIndex((previous) => (previous + 1) % words.length);
          }}
          className="btn btn-primary mt-3 w-full"
        >
          Next word <Icon name="arrowRight" size={15} />
        </button>
      </Card>

      <div>
        <p className="label mb-1.5">Jump to a word</p>
        <div className="flex flex-wrap gap-1.5">
          {words.slice(0, 18).map((entry, wordIndex) => (
            <button
              key={`${entry.word}-${wordIndex}`}
              type="button"
              onClick={() => {
                recorder.reset();
                setIndex(wordIndex);
                speak(entry.word, { lang: "kal", rate: 0.85 });
              }}
              className={`chip pressable ${wordIndex === index ? "border-[var(--brand)] bg-[var(--brand-soft)] text-[var(--brand)]" : ""}`}
            >
              {entry.word}
            </button>
          ))}
        </div>
      </div>

      <SpeechNotice lang="kal" />
    </div>
  );
}
