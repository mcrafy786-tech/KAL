"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Icon } from "@/components/icons";
import { AudioButton, SlowAudioButton, SpeechNotice } from "@/components/audio";
import { InfoNote, StatusBadge } from "@/components/ui";
import { useSpeechRecognition, useSpeechSynthesis } from "@/lib/use-speech";

type Direction = "en-kal" | "kal-en";
type Mode = "text" | "conversation" | "history";

type Outcome = {
  translatedText: string | null;
  confidence: "verified" | "review" | "low" | "unknown" | "proposal";
  score: number;
  provider: string;
  notes: string[];
  suggestions: { english: string; kalenjin: string; status: string }[];
  tokens: { source: string; target: string | null; status: string }[];
  requiresHumanReview: boolean;
  dialectName: string;
};

type HistoryItem = {
  id: number;
  sourceText: string;
  translatedText: string | null;
  sourceLanguage: string;
  targetLanguage: string;
  confidenceStatus: string;
  confidenceScore: number;
  mode: string;
  createdAt: string;
};

type PhraseChip = { english: string; kalenjin: string; status: string; category: string };

type Turn = {
  id: string;
  speaker: "en" | "kal";
  source: string;
  translated: string | null;
  confidence: string;
  createdAt: string;
};

const CONFIDENCE_LABEL: Record<string, string> = {
  verified: "Reviewed match",
  review: "Corpus match · review pending",
  low: "Approximate gloss",
  unknown: "No verified translation",
  proposal: "AI proposal · unverified",
};

export function Translator({
  dialectName,
  dialectCode,
  history,
  phrasebook,
}: {
  dialectName: string;
  dialectCode: string;
  history: HistoryItem[];
  phrasebook: PhraseChip[];
}) {
  const [mode, setMode] = useState<Mode>("text");
  const [direction, setDirection] = useState<Direction>("en-kal");
  const [text, setText] = useState("");
  const [result, setResult] = useState<{ outcome: Outcome; id: number } | null>(null);
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>(history);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [speaker, setSpeaker] = useState<"en" | "kal">("en");
  const { speak } = useSpeechSynthesis();
  const pendingAutoTranslate = useRef(false);

  const targetLang: "en" | "kal" = direction === "en-kal" ? "kal" : "en";
  const recognitionLang = direction === "en-kal" ? "en-US" : "sw-KE";

  const submit = useCallback(
    async (input: string, opts?: { turnSpeaker?: "en" | "kal"; silent?: boolean }) => {
      const trimmed = input.trim();
      if (!trimmed) {
        setError("Type or record something to translate.");
        return;
      }
      setLoading(true);
      setError(null);
      try {
        const activeDirection: Direction = opts?.turnSpeaker
          ? opts.turnSpeaker === "en"
            ? "en-kal"
            : "kal-en"
          : direction;
        const response = await fetch("/api/translations", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ text: trimmed, direction: activeDirection, mode: mode === "conversation" ? "conversation" : "text" }),
        });
        const data = (await response.json()) as {
          ok: boolean;
          error?: string;
          result?: Outcome;
          saved?: HistoryItem;
        };
        if (!response.ok || !data.ok || !data.result || !data.saved) {
          setError(data.error ?? "Translation failed. Please try again.");
          return;
        }
        setResult({ outcome: data.result, id: data.saved.id });
        setHistoryItems((previous) => [data.saved!, ...previous.filter((item) => item.id !== data.saved!.id)]);
        if (mode === "conversation") {
          setTurns((previous) => [
            ...previous,
            {
              id: String(data.saved!.id),
              speaker: opts?.turnSpeaker ?? (activeDirection === "en-kal" ? "en" : "kal"),
              source: trimmed,
              translated: data.result!.translatedText,
              confidence: data.result!.confidence,
              createdAt: data.saved!.createdAt,
            },
          ]);
        }
        if (autoSpeak && data.result.translatedText) {
          speak(data.result.translatedText, {
            lang: activeDirection === "en-kal" ? "kal" : "en",
            rate: activeDirection === "en-kal" ? 0.85 : 0.95,
          });
        }
      } catch {
        setError("Network error — the translator needs an internet connection. Downloaded lessons still work offline.");
      } finally {
        setLoading(false);
      }
    },
    [autoSpeak, direction, mode, speak],
  );

  const recognition = useSpeechRecognition({
    lang: recognitionLang,
    onTranscript: (transcript) => {
      setText(transcript);
      if (mode === "conversation") {
        pendingAutoTranslate.current = true;
        void submit(transcript, { turnSpeaker: speaker });
      }
    },
  });

  useEffect(() => {
    if (mode === "conversation") pendingAutoTranslate.current = false;
  }, [mode]);

  function swapDirection() {
    setDirection((previous) => (previous === "en-kal" ? "kal-en" : "en-kal"));
    setResult(null);
  }

  async function copy(value: string | null) {
    if (!value) return;
    try {
      await navigator.clipboard.writeText(value);
      setNotice("Copied to clipboard.");
      setTimeout(() => setNotice(null), 2200);
    } catch {
      setNotice("Copy is blocked by this browser. Long-press the text to copy it.");
    }
  }

  async function requestReview() {
    if (!result) return;
    try {
      const response = await fetch("/api/contributions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          type: "correction",
          dialectCode,
          consent: false,
          payload: {
            english: direction === "en-kal" ? text : result.outcome.translatedText ?? "",
            kalenjin: direction === "en-kal" ? result.outcome.translatedText ?? "" : text,
            note: `Human review requested from Live Translator. Confidence: ${result.outcome.confidence}.`,
          },
        }),
      });
      const data = (await response.json()) as { ok: boolean; error?: string };
      setNotice(
        data.ok
          ? "Review requested. A native-speaker reviewer will see it in the admin queue."
          : data.error ?? "Could not submit the review request.",
      );
    } catch {
      setNotice("Network error while requesting review.");
    }
  }

  async function clearHistory(scope: "all" | "conversation") {
    try {
      const response = await fetch(`/api/translations${scope === "conversation" ? "?mode=conversation" : ""}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        setNotice("Could not clear history.");
        return;
      }
      if (scope === "conversation") {
        setTurns([]);
        setHistoryItems((previous) => previous.filter((item) => item.mode !== "conversation"));
        setNotice("Conversation history deleted from the server.");
      } else {
        setHistoryItems([]);
        setTurns([]);
        setNotice("All translation history deleted.");
      }
    } catch {
      setNotice("Network error while clearing history.");
    }
  }

  const tabs: { id: Mode; label: string; icon: "message" | "users" | "clock" }[] = [
    { id: "text", label: "Text", icon: "message" },
    { id: "conversation", label: "Conversation", icon: "users" },
    { id: "history", label: "History", icon: "clock" },
  ];

  return (
    <div className="flex flex-col gap-4">
      <div className="flex rounded-full border border-line bg-surface p-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setMode(tab.id)}
            className={`flex flex-1 items-center justify-center gap-1.5 rounded-full py-2 text-xs font-semibold transition ${
              mode === tab.id ? "bg-[var(--brand)] text-[var(--brand-ink)]" : "text-muted"
            }`}
          >
            <Icon name={tab.icon} size={14} />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="card-flat flex items-center justify-between gap-2 p-2">
        <button
          type="button"
          onClick={() => setDirection("en-kal")}
          className={`flex-1 rounded-xl px-3 py-2 text-xs font-semibold transition ${
            direction === "en-kal" ? "bg-[var(--brand-soft)] text-[var(--brand)]" : "text-muted"
          }`}
        >
          English → {dialectName}
        </button>
        <button
          type="button"
          onClick={swapDirection}
          aria-label="Swap translation direction"
          className="pressable grid h-9 w-9 shrink-0 place-items-center rounded-full border border-line bg-surface text-ink"
        >
          <Icon name="refresh" size={15} />
        </button>
        <button
          type="button"
          onClick={() => setDirection("kal-en")}
          className={`flex-1 rounded-xl px-3 py-2 text-xs font-semibold transition ${
            direction === "kal-en" ? "bg-[var(--brand-soft)] text-[var(--brand)]" : "text-muted"
          }`}
        >
          {dialectName} → English
        </button>
      </div>

      {direction === "kal-en" ? (
        <InfoNote tone="warn">
          Mainstream speech engines do not support Kalenjin recognition. The microphone here uses the nearest
          installed model and can be inaccurate, so manual Kalenjin input and the verified phrasebook below are the
          reliable path. Never treat an automatic transcript as correct.
        </InfoNote>
      ) : null}

      {mode === "text" ? (
        <>
          <div className="card p-4">
            <label htmlFor="translate-input" className="label">
              {direction === "en-kal" ? "English to translate" : `Text in ${dialectName}`}
            </label>
            <textarea
              id="translate-input"
              value={text}
              onChange={(event) => setText(event.target.value)}
              rows={4}
              placeholder={
                direction === "en-kal" ? "e.g. Hello, thank you" : "e.g. Chamgei"
              }
              className="textarea mt-2 resize-none"
              maxLength={600}
            />

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => (recognition.listening ? recognition.stop() : recognition.start())}
                className={`btn ${recognition.listening ? "btn-gold recording-pulse" : "btn-secondary"}`}
                aria-pressed={recognition.listening}
              >
                <Icon name={recognition.listening ? "stop" : "mic"} size={16} />
                {recognition.listening ? "Stop recording" : "Speak"}
              </button>
              <button type="button" onClick={() => void submit(text)} disabled={loading} className="btn btn-primary">
                <Icon name="translate" size={16} />
                {loading ? "Translating…" : "Translate"}
              </button>
              <button
                type="button"
                onClick={() => setText("")}
                className="btn btn-ghost ml-auto"
                aria-label="Clear input"
              >
                <Icon name="trash" size={15} /> Clear
              </button>
            </div>

            {recognition.listening ? (
              <div className="mt-3 flex items-center gap-2 text-xs text-muted">
                <span className="flex items-end gap-0.5 text-[var(--clay)]">
                  {[0, 1, 2, 3, 4].map((bar) => (
                    <span key={bar} className="wave-bar" style={{ animationDelay: `${bar * 0.12}s` }} />
                  ))}
                </span>
                Listening… {recognition.interim || "speak clearly"}
              </div>
            ) : null}

            {recognition.error ? <p className="mt-2 text-xs text-[color:var(--clay)]">{recognition.error}</p> : null}
            {error ? <p className="mt-2 text-xs text-[color:var(--danger)]">{error}</p> : null}
            {notice ? <p className="mt-2 text-xs text-[var(--brand)]">{notice}</p> : null}

            <div className="mt-3 flex flex-wrap gap-1.5">
              {(direction === "en-kal"
                ? ["Hello", "Thank you", "Yes", "One, two, three", "Water", "The sun"]
                : phrasebook.slice(0, 6).map((phrase) => phrase.kalenjin)
              ).map((sample) => (
                <button
                  key={sample}
                  type="button"
                  onClick={() => {
                    setText(sample);
                    void submit(sample);
                  }}
                  className="chip pressable hover:border-[var(--brand)]"
                >
                  {sample}
                </button>
              ))}
            </div>
          </div>

          {result ? (
            <ResultCard
              outcome={result.outcome}
              direction={direction}
              sourceText={text}
              onCopy={copy}
              onReview={requestReview}
              onRetry={() => void submit(text)}
            />
          ) : (
            <div className="card flex flex-col gap-2 p-4">
              <h3 className="display text-sm font-semibold text-ink">How translation confidence works</h3>
              <p className="text-xs leading-relaxed text-muted">
                The engine first looks for the whole sentence in the verified {dialectName} corpus. If it is not
                there, it offers the closest reviewed alternative or a word-level gloss marked approximate. When
                nothing reliable exists, it says so and lets you request native-speaker review. It never invents
                Kalenjin.
              </p>
              <div className="flex flex-wrap gap-1.5">
                <StatusBadge status="verified" />
                <StatusBadge status="review" />
                <StatusBadge status="low" />
                <StatusBadge status="unknown" />
              </div>
            </div>
          )}
        </>
      ) : null}

      {mode === "conversation" ? (
        <>
          <div className="card p-4">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <h3 className="display text-sm font-semibold text-ink">Two-person conversation</h3>
                <p className="text-[11px] text-muted">
                  Pass one phone back and forth. Turn-taking is manual so nothing is recorded by accident.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setAutoSpeak((previous) => !previous)}
                className={`chip pressable ${autoSpeak ? "border-[var(--brand)] text-[var(--brand)]" : ""}`}
              >
                <Icon name={autoSpeak ? "volume" : "pause"} size={12} />
                {autoSpeak ? "Auto-play on" : "Auto-play off"}
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  { id: "en" as const, title: "English speaker", hint: "Records English → translates to Kalenjin", color: "var(--brand)" },
                  { id: "kal" as const, title: `${dialectName} speaker`, hint: "Type Kalenjin if speech is unavailable", color: "var(--clay)" },
                ]
              ).map((option) => (
                <div
                  key={option.id}
                  className={`rounded-2xl border p-3 ${
                    speaker === option.id ? "border-[var(--brand)] bg-[var(--brand-soft)]/40" : "border-line"
                  }`}
                >
                  <p className="text-xs font-semibold text-ink">{option.title}</p>
                  <p className="mt-0.5 text-[10px] leading-snug text-muted">{option.hint}</p>
                  <button
                    type="button"
                    onClick={() => {
                      setSpeaker(option.id);
                      setDirection(option.id === "en" ? "en-kal" : "kal-en");
                      if (recognition.listening) {
                        recognition.stop();
                      } else {
                        recognition.start();
                      }
                    }}
                    aria-label={`Record ${option.title}`}
                    className={`mt-2 grid h-12 w-full place-items-center rounded-full text-[var(--brand-ink)] ${
                      speaker === option.id && recognition.listening ? "recording-pulse bg-[var(--clay)]" : "bg-[var(--brand)]"
                    }`}
                  >
                    <Icon name={speaker === option.id && recognition.listening ? "stop" : "mic"} size={20} />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSpeaker(option.id);
                      setDirection(option.id === "en" ? "en-kal" : "kal-en");
                      const value = window.prompt(
                        option.id === "en" ? "Type the English sentence:" : `Type the ${dialectName} sentence:`,
                      );
                      if (value?.trim()) void submit(value, { turnSpeaker: option.id });
                    }}
                    className="mt-1.5 w-full text-[10px] font-semibold text-muted underline decoration-dotted"
                  >
                    Type instead
                  </button>
                </div>
              ))}
            </div>

            {recognition.error ? <p className="mt-2 text-xs text-[color:var(--clay)]">{recognition.error}</p> : null}
            {error ? <p className="mt-2 text-xs text-[color:var(--danger)]">{error}</p> : null}
            {loading ? <p className="mt-2 text-xs text-muted">Translating…</p> : null}
          </div>

          <div className="card p-4">
            <div className="mb-2 flex items-center justify-between">
              <h3 className="display text-sm font-semibold text-ink">Conversation history</h3>
              <button
                type="button"
                onClick={() => void clearHistory("conversation")}
                className="chip pressable"
              >
                <Icon name="trash" size={12} /> Clear
              </button>
            </div>
            {turns.length === 0 ? (
              <p className="py-4 text-center text-xs text-muted">
                No turns yet. Tap a speaker button to begin — both sides appear here with their confidence label.
              </p>
            ) : (
              <ul className="flex flex-col gap-2">
                {turns.map((turn) => (
                  <li
                    key={turn.id}
                    className={`rounded-2xl border p-3 ${
                      turn.speaker === "en"
                        ? "border-line bg-[var(--surface-muted)]/60"
                        : "border-[color:var(--gold)]/40 bg-[var(--gold-soft)]/50"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wide text-muted">
                        {turn.speaker === "en" ? "English" : dialectName}
                      </span>
                      <StatusBadge status={turn.confidence} />
                    </div>
                    <p className="mt-1 text-sm text-ink">{turn.source}</p>
                    {turn.translated ? (
                      <p className="mt-1 border-t border-line pt-1 text-sm font-medium text-[var(--brand)]">
                        {turn.translated}
                      </p>
                    ) : (
                      <p className="mt-1 text-xs text-muted">No verified translation — request review from Text mode.</p>
                    )}
                    <div className="mt-2 flex items-center gap-2">
                      {turn.translated ? (
                        <AudioButton
                          text={turn.translated}
                          lang={turn.speaker === "en" ? "kal" : "en"}
                          size="sm"
                        />
                      ) : null}
                      <button
                        type="button"
                        onClick={() => void copy(turn.translated ?? turn.source)}
                        className="chip pressable"
                      >
                        <Icon name="copy" size={11} /> Copy
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </>
      ) : null}

      {mode === "history" ? (
        <div className="card p-4">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <h3 className="display text-sm font-semibold text-ink">Translation history</h3>
              <p className="text-[11px] text-muted">Stored per account and deletable at any time.</p>
            </div>
            <button type="button" onClick={() => void clearHistory("all")} className="chip pressable">
              <Icon name="trash" size={12} /> Delete all
            </button>
          </div>
          {historyItems.length === 0 ? (
            <p className="py-6 text-center text-xs text-muted">No saved translations yet.</p>
          ) : (
            <ul className="flex flex-col divide-y divide-[var(--line)]">
              {historyItems.map((item) => (
                <li key={item.id} className="py-3 first:pt-0 last:pb-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] font-semibold uppercase tracking-wide text-muted">
                      {item.sourceLanguage} → {item.targetLanguage} ·{" "}
                      {new Date(item.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}{" "}
                      {new Date(item.createdAt).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}
                    </span>
                    <StatusBadge status={item.confidenceStatus} />
                  </div>
                  <p className="mt-1 text-sm text-ink">{item.sourceText}</p>
                  <p className="text-sm text-[var(--brand)]">{item.translatedText ?? "— no verified result —"}</p>
                  <div className="mt-1.5 flex items-center gap-1.5">
                    {item.translatedText ? (
                      <AudioButton
                        text={item.translatedText}
                        lang={item.targetLanguage === "en" ? "en" : "kal"}
                        size="sm"
                      />
                    ) : null}
                    <button
                      type="button"
                      onClick={() => void copy(item.translatedText ?? item.sourceText)}
                      className="chip pressable"
                    >
                      <Icon name="copy" size={11} /> Copy
                    </button>
                    <span className="chip">{dialectName}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      ) : null}

      <div className="card p-4">
        <div className="mb-2 flex items-center justify-between">
          <h3 className="display text-sm font-semibold text-ink">Verified phrasebook</h3>
          <span className="chip">{dialectName}</span>
        </div>
        <p className="mb-2 text-[11px] text-muted">
          Play or copy a reviewed phrase. These are the safest building blocks when speech recognition is unavailable.
        </p>
        <div className="flex flex-wrap gap-1.5">
          {phrasebook.length === 0 ? (
            <p className="text-xs text-muted">No phrases recorded for this variety yet.</p>
          ) : (
            phrasebook.slice(0, 14).map((phrase) => (
              <span
                key={`${phrase.english}-${phrase.kalenjin}`}
                className="inline-flex items-center gap-1.5 rounded-full border border-line bg-surface px-2 py-1 text-[11px]"
              >
                <button
                  type="button"
                  onClick={() => setText(phrase.english)}
                  className="font-medium text-ink"
                  title={`Use “${phrase.english}”`}
                >
                  {phrase.kalenjin}
                </button>
                <AudioButton text={phrase.kalenjin} lang="kal" size="sm" variant="plain" />
                <SlowAudioButton text={phrase.kalenjin} />
              </span>
            ))
          )}
        </div>
        <div className="mt-3">
          <SpeechNotice lang="kal" />
        </div>
      </div>
    </div>
  );
}

function ResultCard({
  outcome,
  direction,
  sourceText,
  onCopy,
  onReview,
  onRetry,
}: {
  outcome: Outcome;
  direction: Direction;
  sourceText: string;
  onCopy: (value: string | null) => void;
  onReview: () => void;
  onRetry: () => void;
}) {
  return (
    <div className="card p-4 fade-up">
      <div className="flex items-center justify-between gap-2">
        <h3 className="display text-sm font-semibold text-ink">Translation</h3>
        <StatusBadge status={outcome.confidence} />
      </div>
      <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-muted">
        {direction === "en-kal" ? "English" : outcome.dialectName}
      </p>
      <p className="text-sm text-ink">{sourceText}</p>
      <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-muted">
        {direction === "en-kal" ? outcome.dialectName : "English"}
      </p>
      <p className="display text-xl font-semibold leading-snug text-[var(--brand)]">
        {outcome.translatedText ?? "No verified translation available"}
      </p>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        {outcome.translatedText ? (
          <>
            <AudioButton
              text={outcome.translatedText}
              lang={direction === "en-kal" ? "kal" : "en"}
              label="Play"
              variant="solid"
            />
            <SlowAudioButton text={outcome.translatedText} lang={direction === "en-kal" ? "kal" : "en"} />
            <button type="button" onClick={() => onCopy(outcome.translatedText)} className="chip pressable">
              <Icon name="copy" size={12} /> Copy
            </button>
          </>
        ) : null}
        <button type="button" onClick={onRetry} className="chip pressable">
          <Icon name="refresh" size={12} /> Try again
        </button>
        {outcome.requiresHumanReview ? (
          <button type="button" onClick={onReview} className="chip pressable border-[var(--brand)] text-[var(--brand)]">
            <Icon name="users" size={12} /> Request human review
          </button>
        ) : null}
      </div>

      <div className="mt-3 space-y-1.5">
        {outcome.notes.map((note, index) => (
          <p key={index} className="text-[11px] leading-relaxed text-muted">
            • {note}
          </p>
        ))}
      </div>

      {outcome.tokens.length > 0 ? (
        <div className="mt-3 rounded-xl border border-line p-2">
          <p className="text-[10px] font-semibold uppercase tracking-wide text-muted">Word-level breakdown</p>
          <div className="mt-1 flex flex-wrap gap-1">
            {outcome.tokens.map((token, index) => (
              <span key={`${token.source}-${index}`} className="chip">
                {token.source}
                {token.target ? ` → ${token.target}` : " → ?"}
              </span>
            ))}
          </div>
        </div>
      ) : null}

      {outcome.suggestions.length > 0 ? (
        <div className="mt-3">
          <p className="text-[10px] font-semibold uppercase tracking-wide text-muted">Verified alternatives</p>
          <ul className="mt-1 space-y-1">
            {outcome.suggestions.map((suggestion) => (
              <li key={`${suggestion.english}-${suggestion.kalenjin}`} className="flex items-center gap-2 text-xs">
                <span className="text-ink">{suggestion.english}</span>
                <Icon name="arrowRight" size={12} className="text-muted" />
                <span className="font-medium text-[var(--brand)]">{suggestion.kalenjin}</span>
                <AudioButton text={suggestion.kalenjin} lang="kal" size="sm" variant="plain" />
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <p className="mt-3 text-[10px] text-muted">
        Provider: {outcome.provider} · Confidence {Math.round(outcome.score * 100)}% · {CONFIDENCE_LABEL[outcome.confidence]}
      </p>
    </div>
  );
}
