"use client";

import { useEffect, useRef, useState } from "react";
import { AudioButton } from "@/components/audio";
import { Icon } from "@/components/icons";
import { Card, InfoNote } from "@/components/ui";

type Practice = { prompt: string; options: string[]; answer: string; conceptKey: string };

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  practice?: Practice;
};

const STARTERS = [
  "Teach me a greeting",
  "Show me the numbers",
  "How do I introduce myself?",
  "Why is some content marked needs review?",
  "Translate: thank you",
  "Give me a practice question",
];

function renderContent(content: string) {
  return content.split("\n").map((line, index) => {
    if (!line.trim()) return <div key={index} className="h-1.5" />;
    const parts = line.split(/(\*\*[^*]+\*\*)/g);
    return (
      <p key={index} className="text-[13px] leading-relaxed text-ink">
        {parts.map((part, partIndex) =>
          part.startsWith("**") && part.endsWith("**") ? (
            <strong key={partIndex} className="font-semibold text-[var(--brand)]">
              {part.slice(2, -2)}
            </strong>
          ) : (
            <span key={partIndex}>{part}</span>
          ),
        )}
      </p>
    );
  });
}

export function TutorChat({
  dialectName,
  initialMessages,
}: {
  dialectName: string;
  initialMessages: Message[];
}) {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [practiceState, setPracticeState] = useState<Record<string, string>>({});
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, loading]);

  async function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || loading) return;
    const userMessage: Message = { id: `local-${Date.now()}`, role: "user", content: trimmed };
    setMessages((previous) => [...previous, userMessage]);
    setInput("");
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/tutor", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ message: trimmed }),
      });
      const data = (await response.json()) as {
        ok: boolean;
        error?: string;
        reply?: { content: string; practice?: Practice };
      };
      if (!response.ok || !data.ok || !data.reply) {
        setError(data.error ?? "The tutor could not reply.");
        return;
      }
      setMessages((previous) => [
        ...previous,
        {
          id: `reply-${Date.now()}`,
          role: "assistant",
          content: data.reply!.content,
          practice: data.reply!.practice,
        },
      ]);
    } catch {
      setError("Network error — the tutor needs an internet connection.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <InfoNote>
        Your tutor answers from the reviewed {dialectName} corpus only. If something is not verified it will say so
        instead of inventing Kalenjin. Everything you send is stored in your private tutor transcript.
      </InfoNote>

      <div className="flex flex-col gap-2.5">
        {messages.length === 0 ? (
          <Card className="p-4">
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-[var(--gold-soft)] text-[color:var(--clay)]">
                <Icon name="sparkles" size={17} />
              </span>
              <div>
                <p className="display text-sm font-semibold text-ink">Chamgei! I am your Kalenjin tutor.</p>
                <p className="text-[11px] text-muted">Patient, honest about uncertainty, and always on your variety.</p>
              </div>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-muted">
              Ask about greetings, numbers, family words, grammar or a translation. I will explain mistakes in plain
              English and give you practice questions that adapt to your lessons.
            </p>
          </Card>
        ) : null}

        {messages.map((message) =>
          message.role === "user" ? (
            <div key={message.id} className="ml-auto max-w-[85%] rounded-2xl rounded-br-sm bg-[var(--brand)] px-3.5 py-2.5 text-sm text-[var(--brand-ink)]">
              {message.content}
            </div>
          ) : (
            <div key={message.id} className="max-w-[92%] rounded-2xl rounded-bl-sm border border-line bg-surface px-3.5 py-3">
              {renderContent(message.content)}
              {message.practice ? (
                <div className="mt-2 rounded-xl border border-line p-2.5">
                  <p className="text-xs font-semibold text-ink">{message.practice.prompt}</p>
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    {message.practice.options.map((option) => {
                      const chosen = practiceState[message.id] === option;
                      const isAnswer = option === message.practice!.answer;
                      const revealed = Boolean(practiceState[message.id]);
                      return (
                        <button
                          key={option}
                          type="button"
                          disabled={revealed}
                          onClick={() => setPracticeState((previous) => ({ ...previous, [message.id]: option }))}
                          className={`chip pressable ${
                            revealed && isAnswer
                              ? "border-transparent bg-[var(--brand-soft)] text-[var(--brand)]"
                              : chosen
                                ? "border-[color:var(--danger)] text-[color:var(--danger)]"
                                : ""
                          }`}
                        >
                          {option}
                        </button>
                      );
                    })}
                  </div>
                  {practiceState[message.id] ? (
                    <p className="mt-1.5 text-[11px] text-muted">
                      {practiceState[message.id] === message.practice.answer
                        ? "Correct. Say it out loud once, then use it in a greeting."
                        : `Not quite — the reviewed form is “${message.practice.answer}”.`}
                    </p>
                  ) : null}
                  <div className="mt-1.5">
                    <AudioButton text={message.practice.answer} lang="kal" size="sm" />
                  </div>
                </div>
              ) : null}
            </div>
          ),
        )}

        {loading ? (
          <div className="flex max-w-[60%] items-center gap-2 rounded-2xl border border-line bg-surface px-3 py-2.5 text-xs text-muted">
            <span className="flex items-end gap-0.5 text-[var(--brand)]">
              {[0, 1, 2].map((bar) => (
                <span key={bar} className="wave-bar" style={{ animationDelay: `${bar * 0.15}s` }} />
              ))}
            </span>
            Checking the verified corpus…
          </div>
        ) : null}
        <div ref={endRef} />
      </div>

      {error ? <p className="text-xs text-[color:var(--danger)]">{error}</p> : null}

      <div className="hide-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1">
        {STARTERS.map((starter) => (
          <button
            key={starter}
            type="button"
            onClick={() => void send(starter)}
            className="chip pressable shrink-0 hover:border-[var(--brand)]"
          >
            {starter}
          </button>
        ))}
      </div>

      <form
        onSubmit={(event) => {
          event.preventDefault();
          void send(input);
        }}
        className="sticky bottom-[5.6rem] flex items-end gap-2 rounded-2xl border border-line bg-surface p-2 shadow-lg"
      >
        <textarea
          value={input}
          onChange={(event) => setInput(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter" && !event.shiftKey) {
              event.preventDefault();
              void send(input);
            }
          }}
          rows={1}
          placeholder="Ask your tutor anything…"
          className="max-h-28 flex-1 resize-none bg-transparent px-1.5 py-1.5 text-sm text-ink outline-none"
          aria-label="Message your tutor"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="btn btn-primary !px-3"
          aria-label="Send message"
        >
          <Icon name="send" size={16} />
        </button>
      </form>
    </div>
  );
}
