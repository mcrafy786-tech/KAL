import Link from "next/link";
import type { ReactNode } from "react";
import { Icon } from "@/components/icons";

export function Logo({ size = 36 }: { size?: number }) {
  return (
    <span
      className="relative inline-flex shrink-0 items-center justify-center rounded-2xl"
      style={{
        width: size,
        height: size,
        background: "linear-gradient(145deg, var(--brand), color-mix(in oklab, var(--brand) 55%, #08281c))",
      }}
      aria-hidden="true"
    >
      <svg width={size * 0.62} height={size * 0.62} viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="4" fill="var(--gold)" />
        {[0, 45, 90, 135, 180, 225, 270, 315].map((angle) => (
          <line
            key={angle}
            x1="12"
            y1="12"
            x2={12 + 9 * Math.cos((angle * Math.PI) / 180)}
            y2={12 + 9 * Math.sin((angle * Math.PI) / 180)}
            stroke="var(--gold)"
            strokeWidth="1.6"
            strokeLinecap="round"
            opacity={0.85}
            transform={`translate(${-9 * Math.cos((angle * Math.PI) / 180)} ${-9 * Math.sin(
              (angle * Math.PI) / 180,
            )})`}
          />
        ))}
        <circle cx="12" cy="12" r="8.5" stroke="var(--brand-ink)" strokeOpacity="0.35" strokeWidth="1" />
      </svg>
    </span>
  );
}

const STATUS_META: Record<string, { label: string; className: string; title: string }> = {
  verified: {
    label: "Reviewed",
    className: "bg-[var(--brand-soft)] text-[var(--brand)] border-transparent",
    title: "Attested in published Kalenjin material and recorded in the app review log.",
  },
  needs_review: {
    label: "Needs review",
    className: "bg-[var(--gold-soft)] text-[color:var(--clay)] border-transparent",
    title: "Recorded from learner material but not yet confirmed by a native-speaker reviewer.",
  },
  community: {
    label: "Community",
    className: "bg-[var(--surface-muted)] text-[var(--muted)] border-transparent",
    title: "Submitted by a contributor and awaiting review.",
  },
  review: {
    label: "Review pending",
    className: "bg-[var(--gold-soft)] text-[color:var(--clay)] border-transparent",
    title: "Closest available corpus entry, not a confirmed exact match.",
  },
  low: {
    label: "Approximate",
    className: "bg-[var(--gold-soft)] text-[color:var(--clay)] border-transparent",
    title: "Word-level gloss. Grammar is not verified.",
  },
  unknown: {
    label: "No verified match",
    className: "bg-[var(--surface-muted)] text-[var(--muted)] border-transparent",
    title: "The verified corpus has no answer for this sentence in your variety.",
  },
  proposal: {
    label: "AI proposal",
    className: "bg-[var(--gold-soft)] text-[color:var(--clay)] border-transparent",
    title: "AI-generated and unverified. Needs native-speaker review.",
  },
  pending: {
    label: "Pending",
    className: "bg-[var(--gold-soft)] text-[color:var(--clay)] border-transparent",
    title: "Awaiting reviewer action.",
  },
  approved: {
    label: "Approved",
    className: "bg-[var(--brand-soft)] text-[var(--brand)] border-transparent",
    title: "Approved by a reviewer.",
  },
  rejected: {
    label: "Not accepted",
    className: "bg-[var(--surface-muted)] text-[var(--muted)] border-transparent",
    title: "Reviewed and not accepted.",
  },
};

export function StatusBadge({ status, className = "" }: { status: string; className?: string }) {
  const meta = STATUS_META[status] ?? STATUS_META.community;
  return (
    <span className={`chip ${meta.className} ${className}`} title={meta.title}>
      <span className="h-1.5 w-1.5 rounded-full bg-current opacity-80" />
      {meta.label}
    </span>
  );
}

export function Card({
  children,
  className = "",
  as = "div",
}: {
  children: ReactNode;
  className?: string;
  as?: "div" | "section" | "article";
}) {
  const Tag = as;
  return <Tag className={`card ${className}`}>{children}</Tag>;
}

export function ProgressBar({ value, className = "" }: { value: number; className?: string }) {
  const clamped = Math.max(0, Math.min(100, Math.round(value)));
  return (
    <div className={`progress-track ${className}`} role="progressbar" aria-valuenow={clamped} aria-valuemin={0} aria-valuemax={100}>
      <div className="progress-fill" style={{ width: `${clamped}%` }} />
    </div>
  );
}

export function ProgressRing({
  value,
  size = 88,
  stroke = 8,
  children,
}: {
  value: number;
  size?: number;
  stroke?: number;
  children?: ReactNode;
}) {
  const clamped = Math.max(0, Math.min(100, value));
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (clamped / 100) * circumference;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="var(--surface-muted)" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="var(--brand)"
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 0.6s cubic-bezier(0.22, 1, 0.36, 1)" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">{children}</div>
    </div>
  );
}

export function SectionHeading({
  title,
  subtitle,
  href,
  hrefLabel = "See all",
}: {
  title: string;
  subtitle?: string;
  href?: string;
  hrefLabel?: string;
}) {
  return (
    <div className="mb-3 flex items-end justify-between gap-3">
      <div>
        <h2 className="display text-lg font-semibold text-ink">{title}</h2>
        {subtitle ? <p className="mt-0.5 text-xs text-muted">{subtitle}</p> : null}
      </div>
      {href ? (
        <Link href={href} className="chip pressable hover:border-[var(--brand)]">
          {hrefLabel}
          <Icon name="arrowRight" size={12} />
        </Link>
      ) : null}
    </div>
  );
}

export function ScreenHeader({
  title,
  subtitle,
  backHref,
  action,
}: {
  title: string;
  subtitle?: string;
  backHref?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-4 flex items-start justify-between gap-3">
      <div className="flex items-start gap-2">
        {backHref ? (
          <Link
            href={backHref}
            aria-label="Go back"
            className="pressable mt-0.5 grid h-9 w-9 place-items-center rounded-full border border-line bg-surface text-ink"
          >
            <Icon name="chevronLeft" size={18} />
          </Link>
        ) : null}
        <div>
          <h1 className="display text-2xl font-semibold leading-tight text-ink">{title}</h1>
          {subtitle ? <p className="mt-1 text-sm text-muted">{subtitle}</p> : null}
        </div>
      </div>
      {action}
    </div>
  );
}

export function EmptyState({
  icon = "info",
  title,
  body,
  action,
}: {
  icon?: Parameters<typeof Icon>[0]["name"];
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <div className="card flex flex-col items-center gap-2 px-6 py-8 text-center">
      <span className="grid h-11 w-11 place-items-center rounded-full bg-[var(--surface-muted)] text-muted">
        <Icon name={icon} size={20} />
      </span>
      <h3 className="display text-base font-semibold text-ink">{title}</h3>
      <p className="max-w-xs text-xs leading-relaxed text-muted">{body}</p>
      {action}
    </div>
  );
}

export function Stat({
  label,
  value,
  hint,
  icon,
}: {
  label: string;
  value: string | number;
  hint?: string;
  icon?: Parameters<typeof Icon>[0]["name"];
}) {
  return (
    <div className="card-flat p-3">
      <div className="flex items-center gap-1.5 text-muted">
        {icon ? <Icon name={icon} size={14} /> : null}
        <span className="text-[10px] font-semibold uppercase tracking-wide">{label}</span>
      </div>
      <p className="display mt-1 text-xl font-semibold text-ink">{value}</p>
      {hint ? <p className="text-[10px] text-muted">{hint}</p> : null}
    </div>
  );
}

export function InfoNote({ children, tone = "neutral" }: { children: ReactNode; tone?: "neutral" | "warn" }) {
  return (
    <div
      className={`flex gap-2 rounded-2xl border p-3 text-[11px] leading-relaxed ${
        tone === "warn"
          ? "border-[color:var(--gold)]/40 bg-[var(--gold-soft)] text-[color:var(--clay)]"
          : "border-line bg-[var(--surface-muted)] text-muted"
      }`}
    >
      <Icon name={tone === "warn" ? "info" : "shield"} size={15} className="mt-0.5 shrink-0" />
      <div>{children}</div>
    </div>
  );
}
