/**
 * Kalenjin varieties.
 *
 * The app never assumes a variety. `DEFAULT_DIALECT_CODE` (server env) or the
 * learner's onboarding choice decides the active variety. Every vocabulary,
 * phrase, lesson exercise and translation is resolved per variety.
 */
export type DialectSeed = {
  code: string;
  name: string;
  nativeName: string;
  description: string;
  region: string;
  sortOrder: number;
};

export const dialectSeeds: DialectSeed[] = [
  {
    code: "kipsigis",
    name: "Kipsigis",
    nativeName: "Kipsigis",
    description:
      "Southern Nilotic variety spoken in Kericho, Bomet and parts of Nakuru. Often written with the Kalenjin orthography (ng', ë, ö).",
    region: "Kericho · Bomet",
    sortOrder: 1,
  },
  {
    code: "nandi",
    name: "Nandi",
    nativeName: "Nandi",
    description:
      "Variety of the Nandi Hills and Kapsabet highlands. Shares much core vocabulary with Kipsigis but differs in pronunciation and idiom.",
    region: "Nandi · Uasin Gishu",
    sortOrder: 2,
  },
  {
    code: "tugen",
    name: "Tugen",
    nativeName: "Tugen",
    description:
      "Spoken in Baringo. Distinct intonation and several lexical differences from Kipsigis/Nandi.",
    region: "Baringo",
    sortOrder: 3,
  },
  {
    code: "keiyo",
    name: "Keiyo",
    nativeName: "Keiyo",
    description:
      "Spoken in Elgeyo-Marakwet. Closely related to Marakwet with its own preferred spellings.",
    region: "Elgeyo-Marakwet",
    sortOrder: 4,
  },
  {
    code: "marakwet",
    name: "Marakwet",
    nativeName: "Marakwet",
    description:
      "Variety of the Kerio Valley. Northern and southern Marakwet communities also show internal variation.",
    region: "Elgeyo-Marakwet",
    sortOrder: 5,
  },
  {
    code: "pokot",
    name: "Pokot",
    nativeName: "Pökoot",
    description:
      "Spoken in West Pokot and across the border in Uganda. Sometimes classified as a separate but closely related language.",
    region: "West Pokot · Uganda",
    sortOrder: 6,
  },
  {
    code: "sabaot",
    name: "Sabaot",
    nativeName: "Sabaot",
    description:
      "Spoken on Mount Elgon (Trans Nzoia / Bungoma). Includes Kony, Bong'om and Pok varieties.",
    region: "Mt. Elgon",
    sortOrder: 7,
  },
];
