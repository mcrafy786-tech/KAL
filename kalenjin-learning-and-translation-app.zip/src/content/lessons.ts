export type ExerciseTemplate =
  | { kind: "mcq_meaning"; conceptKey: string; optionKeys: string[] }
  | { kind: "mcq_word"; conceptKey: string; optionKeys: string[] }
  | { kind: "listen"; conceptKey: string; optionKeys: string[] }
  | { kind: "type_translation"; conceptKey: string }
  | { kind: "type_definition"; conceptKey: string }
  | { kind: "arrange"; phraseConceptKey: string };

export type LessonSeed = {
  slug: string;
  title: string;
  description: string;
  level: number;
  orderIndex: number;
  estimatedMinutes: number;
  objectives: string[];
  conceptKeys: string[];
  grammarNotes: string;
  exercises: ExerciseTemplate[];
  verificationStatus: "verified" | "needs_review";
};

export const levelMeta: { level: number; title: string; subtitle: string }[] = [
  { level: 1, title: "Level 1 · Beginner", subtitle: "Greetings, numbers and the sounds of Kalenjin" },
  { level: 2, title: "Level 2 · Elementary", subtitle: "The people and things around you" },
  { level: 3, title: "Level 3 · Intermediate", subtitle: "Everyday verbs and practical conversations" },
  { level: 4, title: "Level 4 · Upper intermediate", subtitle: "Land, weather, community and culture" },
  { level: 5, title: "Level 5 · Advanced", subtitle: "Respectful speech, idiom and nuance" },
  { level: 6, title: "Level 6 · Mastery", subtitle: "Translation, storytelling and fluency" },
];

const mcq = (conceptKey: string, optionKeys: string[]): ExerciseTemplate => ({
  kind: "mcq_meaning",
  conceptKey,
  optionKeys,
});
const word = (conceptKey: string, optionKeys: string[]): ExerciseTemplate => ({
  kind: "mcq_word",
  conceptKey,
  optionKeys,
});
const listen = (conceptKey: string, optionKeys: string[]): ExerciseTemplate => ({
  kind: "listen",
  conceptKey,
  optionKeys,
});

export const lessonSeeds: LessonSeed[] = [
  {
    slug: "greetings-and-respect",
    title: "Greetings and respect",
    description: "Open a conversation the Kalenjin way and learn the most useful greeting words.",
    level: 1,
    orderIndex: 1,
    estimatedMinutes: 8,
    objectives: [
      "Greet someone using a reviewed Kalenjin greeting",
      "Say thank you and yes",
      "Recognise that respect and age affect how you greet",
    ],
    conceptKeys: ["greeting.hello", "greeting.thanks", "greeting.yes", "greeting.no", "greeting.thanks_very_much"],
    grammarNotes:
      "Kalenjin is a Nilotic language with a noun-class system and verb-internal marking for person, tense and aspect. Start with fixed, reviewed expressions. Do not assemble sentences by swapping words until a reviewer confirms the pattern for your variety.",
    exercises: [
      mcq("greeting.hello", ["greeting.hello", "greeting.thanks", "greeting.yes", "nature.water"]),
      word("greeting.thanks", ["greeting.thanks", "greeting.hello", "culture.kalenjin", "number.one"]),
      mcq("greeting.yes", ["greeting.yes", "greeting.no", "greeting.hello", "greeting.thanks"]),
      listen("greeting.hello", ["greeting.hello", "greeting.thanks", "number.two", "nature.fire"]),
      { kind: "type_translation", conceptKey: "greeting.hello" },
      { kind: "arrange", phraseConceptKey: "phrase.hello" },
    ],
    verificationStatus: "verified",
  },
  {
    slug: "counting-one-to-ten",
    title: "Counting from one to ten",
    description: "Build your first number set and practise recognising spoken numerals.",
    level: 1,
    orderIndex: 2,
    estimatedMinutes: 9,
    objectives: ["Count from one to ten", "Match numerals to written Kalenjin forms", "Hear the difference between similar numerals"],
    conceptKeys: [
      "number.one",
      "number.two",
      "number.three",
      "number.four",
      "number.five",
      "number.six",
      "number.seven",
      "number.eight",
      "number.nine",
      "number.ten",
    ],
    grammarNotes:
      "These are the citation forms of the numerals. Counting objects requires agreement with the noun class, a pattern that must be learned with reviewer-confirmed examples.",
    exercises: [
      mcq("number.three", ["number.three", "number.one", "number.five", "number.seven"]),
      word("number.five", ["number.five", "number.two", "number.ten", "number.six"]),
      mcq("number.ten", ["number.ten", "number.nine", "number.four", "number.eight"]),
      listen("number.two", ["number.two", "number.three", "number.eight", "number.six"]),
      { kind: "arrange", phraseConceptKey: "phrase.count_1_3" },
      { kind: "type_translation", conceptKey: "number.one" },
    ],
    verificationStatus: "verified",
  },
  {
    slug: "people-around-you",
    title: "The people around you",
    description: "Kinship words, with an honest note about the review still needed for family terms.",
    level: 2,
    orderIndex: 3,
    estimatedMinutes: 10,
    objectives: ["Name close family members", "Ask about a person's family", "Understand why kinship terms need care"],
    conceptKeys: ["family.mother", "family.father", "family.child", "people.chief"],
    grammarNotes:
      "Kinship vocabulary is one of the most variety-sensitive areas of Kalenjin. The seed entries here are marked 'needs review' on purpose: they appear in published learner material but have not been signed off by a native-speaker reviewer inside this app. Treat them as recognition-only until verified.",
    exercises: [
      mcq("family.mother", ["family.mother", "family.father", "family.child", "people.chief"]),
      word("family.father", ["family.father", "family.mother", "animal.cow", "home.house"]),
      mcq("family.child", ["family.child", "people.chief", "family.mother", "nature.water"]),
      listen("people.chief", ["people.chief", "family.father", "greeting.hello", "animal.dog"]),
      { kind: "type_definition", conceptKey: "family.mother" },
    ],
    verificationStatus: "needs_review",
  },
  {
    slug: "home-and-land",
    title: "Things at home and on the land",
    description: "Water, fire, the sun and the homestead — the vocabulary of daily life.",
    level: 2,
    orderIndex: 4,
    estimatedMinutes: 9,
    objectives: ["Name everyday elements", "Describe the homestead", "Use reviewed nouns with confidence"],
    conceptKeys: ["nature.water", "nature.fire", "nature.sun", "nature.moon", "home.house", "animal.cow"],
    grammarNotes:
      "Nouns in Kalenjin belong to classes that control agreement on modifiers and verbs. Learn each noun together with a reviewed example rather than guessing its class.",
    exercises: [
      mcq("nature.water", ["nature.water", "nature.fire", "nature.sun", "home.house"]),
      word("nature.fire", ["nature.fire", "nature.water", "animal.cow", "nature.moon"]),
      mcq("nature.sun", ["nature.sun", "nature.moon", "nature.water", "greeting.yes"]),
      listen("nature.moon", ["nature.moon", "nature.sun", "nature.rain", "animal.cow"]),
      { kind: "arrange", phraseConceptKey: "phrase.water" },
      { kind: "type_translation", conceptKey: "nature.fire" },
    ],
    verificationStatus: "verified",
  },
  {
    slug: "everyday-actions",
    title: "Everyday actions",
    description: "Verb roots for eating, seeing and speaking — and how Kalenjin builds verb forms.",
    level: 3,
    orderIndex: 5,
    estimatedMinutes: 12,
    objectives: [
      "Recognise three common verb roots",
      "Understand that the root is not a full sentence",
      "Describe simple daily actions with reviewed forms",
    ],
    conceptKeys: ["verb.eat", "verb.see", "verb.speak", "nature.water"],
    grammarNotes:
      "Kalenjin verbs carry subject, tense/aspect and sometimes object marking inside the word. 'Am' is a root, not 'I ate'. Until a reviewer supplies paradigm examples for your variety, practise recognition and use the phrasebook for production.",
    exercises: [
      mcq("verb.eat", ["verb.eat", "verb.see", "verb.speak", "animal.cow"]),
      word("verb.see", ["verb.see", "verb.eat", "nature.water", "animal.dog"]),
      mcq("verb.speak", ["verb.speak", "verb.see", "greeting.thanks", "people.chief"]),
      listen("verb.eat", ["verb.eat", "verb.speak", "nature.fire", "home.house"]),
      { kind: "type_definition", conceptKey: "verb.speak" },
    ],
    verificationStatus: "needs_review",
  },
  {
    slug: "numbers-in-daily-life",
    title: "Numbers in daily life",
    description: "Practise the full number set in listening and translation tasks.",
    level: 3,
    orderIndex: 6,
    estimatedMinutes: 11,
    objectives: ["Recall all ten numerals", "Translate numerals both ways", "Recognise numerals in rapid speech"],
    conceptKeys: [
      "number.six",
      "number.seven",
      "number.eight",
      "number.nine",
      "number.ten",
      "number.two",
      "number.four",
      "number.five",
    ],
    grammarNotes:
      "Counting people and counting objects use different agreement patterns. The numeral forms taught here are the citation forms and are safe in isolation.",
    exercises: [
      mcq("number.seven", ["number.seven", "number.six", "number.nine", "number.ten"]),
      word("number.nine", ["number.nine", "number.eight", "number.four", "number.two"]),
      mcq("number.eight", ["number.eight", "number.seven", "number.ten", "number.five"]),
      listen("number.six", ["number.six", "number.ten", "number.two", "number.nine"]),
      { kind: "arrange", phraseConceptKey: "phrase.count_1_5" },
      { kind: "type_translation", conceptKey: "number.three" },
    ],
    verificationStatus: "verified",
  },
  {
    slug: "weather-and-seasons",
    title: "Weather, seasons and the sky",
    description: "Talk about rain, sun and the moon while respecting uncertain entries.",
    level: 4,
    orderIndex: 7,
    estimatedMinutes: 12,
    objectives: ["Describe the sky and weather", "Use approved entries and flag uncertain ones", "Build a study habit around review"],
    conceptKeys: ["nature.rain", "nature.sun", "nature.moon", "nature.water", "nature.fire"],
    grammarNotes:
      "The rain entry is not yet reviewer-confirmed. In this lesson you will see how the app labels uncertainty in-line, which is exactly how you should treat unverified material from any source.",
    exercises: [
      mcq("nature.rain", ["nature.rain", "nature.sun", "nature.water", "nature.fire"]),
      word("nature.moon", ["nature.moon", "nature.sun", "nature.rain", "nature.fire"]),
      mcq("nature.sun", ["nature.sun", "nature.moon", "nature.water", "greeting.hello"]),
      listen("nature.rain", ["nature.rain", "nature.fire", "nature.sun", "nature.moon"]),
      { kind: "type_definition", conceptKey: "nature.rain" },
    ],
    verificationStatus: "needs_review",
  },
  {
    slug: "community-and-culture",
    title: "Community, cattle and mursik",
    description: "Culture lives inside vocabulary. Learn the words that carry community meaning.",
    level: 4,
    orderIndex: 8,
    estimatedMinutes: 10,
    objectives: ["Use cultural nouns accurately", "Explain mursik in English", "Avoid reductionist cultural claims"],
    conceptKeys: ["culture.mursik", "culture.kalenjin", "animal.cow", "people.chief"],
    grammarNotes:
      "Proper nouns such as 'Kalenjin' behave differently from common nouns. Learn the community-specific terms (Kipsigis, Nandi, Tugen, Keiyo, Marakwet, Pokot, Sabaot) as identity labels chosen by speakers, not as interchangeable synonyms.",
    exercises: [
      mcq("culture.mursik", ["culture.mursik", "culture.kalenjin", "animal.cow", "home.house"]),
      word("animal.cow", ["animal.cow", "culture.mursik", "animal.dog", "people.chief"]),
      mcq("culture.kalenjin", ["culture.kalenjin", "culture.mursik", "greeting.hello", "people.chief"]),
      listen("culture.mursik", ["culture.mursik", "nature.water", "animal.cow", "family.mother"]),
      { kind: "type_definition", conceptKey: "culture.mursik" },
    ],
    verificationStatus: "verified",
  },
  {
    slug: "respectful-speech",
    title: "Respectful speech and intensifiers",
    description: "Warmer thanks, careful kinship terms and the limits of the verified corpus.",
    level: 5,
    orderIndex: 9,
    estimatedMinutes: 13,
    objectives: ["Use intensifiers with care", "Recognise register differences", "Request human review when unsure"],
    conceptKeys: ["greeting.thanks_very_much", "greeting.thanks", "family.mother", "family.father", "people.chief"],
    grammarNotes:
      "Register in Kalenjin depends on age, gender and community. The app deliberately withholds some forms rather than guessing them. Use the contribute/review flow to add reviewer-confirmed forms for your variety.",
    exercises: [
      mcq("greeting.thanks_very_much", ["greeting.thanks_very_much", "greeting.thanks", "greeting.hello", "greeting.yes"]),
      word("people.chief", ["people.chief", "family.father", "greeting.no", "family.child"]),
      mcq("family.father", ["family.father", "family.mother", "family.child", "people.chief"]),
      { kind: "type_definition", conceptKey: "greeting.thanks_very_much" },
      { kind: "arrange", phraseConceptKey: "phrase.thank_you" },
    ],
    verificationStatus: "needs_review",
  },
  {
    slug: "idioms-and-nuance",
    title: "Idioms and nuance (reviewed fragments only)",
    description: "How idiom works, why it cannot be generated, and what has been approved so far.",
    level: 5,
    orderIndex: 10,
    estimatedMinutes: 12,
    objectives: ["Explain why idioms require native review", "Use approved fragments correctly", "Contribute an idiom for review"],
    conceptKeys: ["greeting.hello", "greeting.thanks", "culture.kalenjin", "culture.mursik", "verb.speak"],
    grammarNotes:
      "An idiom's meaning is not the sum of its words. This app will never machine-generate an idiom. Approved idioms appear only after a native-speaker reviewer signs them off with a recording and an explanation.",
    exercises: [
      mcq("culture.kalenjin", ["culture.kalenjin", "culture.mursik", "number.one", "greeting.hello"]),
      word("verb.speak", ["verb.speak", "verb.eat", "verb.see", "greeting.thanks"]),
      mcq("greeting.hello", ["greeting.hello", "greeting.thanks", "greeting.no", "culture.mursik"]),
      listen("greeting.thanks", ["greeting.thanks", "culture.kalenjin", "verb.speak", "greeting.yes"]),
      { kind: "type_translation", conceptKey: "greeting.thanks" },
    ],
    verificationStatus: "needs_review",
  },
  {
    slug: "storytelling-practice",
    title: "Storytelling practice",
    description: "Retell a short, reviewed sequence and practise translation both ways.",
    level: 6,
    orderIndex: 11,
    estimatedMinutes: 14,
    objectives: ["Retell a sequence of reviewed phrases", "Translate in both directions", "Build an oral practice routine"],
    conceptKeys: ["nature.water", "nature.fire", "animal.cow", "family.child", "culture.kalenjin"],
    grammarNotes:
      "Storytelling in Kalenjin uses discourse markers and a narrative tense that this corpus does not yet cover. Use this lesson to master the reviewed pieces, then record a native speaker telling the same story and submit it for review.",
    exercises: [
      mcq("animal.cow", ["animal.cow", "nature.water", "family.child", "nature.fire"]),
      word("nature.water", ["nature.water", "nature.fire", "culture.kalenjin", "animal.cow"]),
      listen("family.child", ["family.child", "animal.cow", "nature.water", "greeting.hello"]),
      { kind: "arrange", phraseConceptKey: "phrase.count_1_3" },
      { kind: "type_definition", conceptKey: "culture.kalenjin" },
    ],
    verificationStatus: "needs_review",
  },
  {
    slug: "mastery-translation",
    title: "Mastery translation drill",
    description: "Two-way translation under the app's confidence rules — the same engine used in Live Translator.",
    level: 6,
    orderIndex: 12,
    estimatedMinutes: 15,
    objectives: ["Translate reviewed phrases both ways", "Read confidence labels correctly", "Request review for unverified input"],
    conceptKeys: ["greeting.hello", "greeting.thanks", "number.ten", "nature.sun", "culture.mursik", "verb.eat"],
    grammarNotes:
      "The Live Translator only marks a result 'Reviewed match' when the whole sentence matches a confirmed phrase in the corpus for your variety. Word-gloss results are always labelled as approximate.",
    exercises: [
      { kind: "type_translation", conceptKey: "greeting.thanks" },
      { kind: "type_definition", conceptKey: "culture.mursik" },
      { kind: "type_translation", conceptKey: "number.ten" },
      mcq("verb.eat", ["verb.eat", "verb.see", "verb.speak", "animal.cow"]),
      { kind: "arrange", phraseConceptKey: "phrase.hello" },
    ],
    verificationStatus: "needs_review",
  },
];

export type CultureSeed = {
  slug: string;
  title: string;
  category: string;
  summary: string;
  body: string;
  verificationStatus: "verified" | "needs_review";
  contributor: string;
  dialectCode?: string;
};

export const cultureSeeds: CultureSeed[] = [
  {
    slug: "greetings-carry-respect",
    title: "Greetings carry respect",
    category: "Greetings",
    summary:
      "Greeting first, business later. Kalenjin communities place real weight on who greets whom, and with which form.",
    body:
      "A greeting opens the relationship before any request is made. Age, gender and community shape the expected form, and some greetings are reserved for particular contexts. This app currently teaches 'Chamgei' as a reviewed, general greeting for Kipsigis and Nandi. It intentionally does not generate elaborate greeting exchanges until native speakers have supplied and approved them for each variety.",
    verificationStatus: "needs_review",
    contributor: "Kalenjin editorial seed",
  },
  {
    slug: "mursik-at-the-centre",
    title: "Mursik at the centre of the table",
    category: "Food",
    summary: "Mursik is fermented milk, a Kalenjin speciality and a marker of hospitality.",
    body:
      "'Mursik' is broadly recognised across Kalenjin communities as fermented milk, traditionally prepared in a specially prepared gourd. Sharing it signals welcome. Exact preparation methods and associated courtesies vary between families and regions, so treat general descriptions as an invitation to ask rather than a complete account.",
    verificationStatus: "verified",
    contributor: "Kalenjin editorial seed",
  },
  {
    slug: "seven-varieties-not-one",
    title: "Seven varieties, not one language",
    category: "Language",
    summary:
      "Kipsigis, Nandi, Tugen, Keiyo, Marakwet, Pokot and Sabaot are distinct speech communities within the Kalenjin family.",
    body:
      "Treating all Kalenjin varieties as identical erases real differences in pronunciation, vocabulary and idiom. This app stores every word and phrase against a specific variety and never silently substitutes one variety's form for another. When coverage for your variety is missing, the app says so and offers to route your request to a reviewer.",
    verificationStatus: "verified",
    contributor: "Kalenjin editorial seed",
  },
  {
    slug: "cattle-and-identity",
    title: "Cattle and identity",
    category: "Community",
    summary: "Cattle vocabulary reaches far beyond the word for 'cow'.",
    body:
      "Cattle play a central role in Kalenjin economy, marriage custom and storytelling. The language contains fine distinctions for age, colour, horn shape and purpose. Rather than flattening these into a single gloss, the dictionary lists 'cow / cattle' as a starter entry and invites native speakers to submit the full terminology they use in their own community.",
    verificationStatus: "needs_review",
    contributor: "Kalenjin editorial seed",
  },
  {
    slug: "storytelling-and-praise",
    title: "Storytelling and praise",
    category: "Oral tradition",
    summary: "Oral narrative and praise names are living parts of the language, not museum pieces.",
    body:
      "Stories are told, corrected and retold — the audience is part of the performance. The same is true of praise names and proverbs. Because their meaning depends on delivery and context, this app does not generate them. Instead, contributors upload recordings with consent, and reviewers attach an explanation and an English paraphrase.",
    verificationStatus: "needs_review",
    contributor: "Kalenjin editorial seed",
  },
  {
    slug: "how-to-contribute-well",
    title: "How to contribute well",
    category: "Community",
    summary: "Good contributions are specific: variety, location, register and consent.",
    body:
      "When you submit a word, say which variety you speak and where you learned it. When you submit a correction, quote the current entry and the corrected form. When you upload a recording, confirm that you are the speaker or have the speaker's permission, and state how the audio may be used. Everything passes through review before learners see it as confirmed.",
    verificationStatus: "verified",
    contributor: "Kalenjin editorial seed",
  },
];
