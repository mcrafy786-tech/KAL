/**
 * Seed lexicon.
 *
 * IMPORTANT LINGUISTIC POLICY
 * ---------------------------
 * Entries are never invented to fill a gap. Each form carries a verification
 * status:
 *   verified     -> attested in published Kalenjin learner/dictionary material
 *                   (independent native-speaker review still tracked in-app)
 *   needs_review -> recorded in learner material but pronunciation / variety
 *                   usage has not been confirmed by an in-app reviewer
 *   community    -> submitted by a contributor and pending review
 *
 * A form that is not listed for a variety is intentionally *absent* for that
 * variety: the UI and translator report missing coverage instead of silently
 * substituting another variety's form.
 */

export type VerificationStatus = "verified" | "needs_review" | "community";

export type DialectCode =
  | "kipsigis"
  | "nandi"
  | "tugen"
  | "keiyo"
  | "marakwet"
  | "pokot"
  | "sabaot";

export type VocabularyForm = {
  word: string;
  status: VerificationStatus;
  note?: string;
  pronunciationGuide?: string;
};

export type LexiconConcept = {
  conceptKey: string;
  definition: string;
  category: string;
  frequencyRank: number;
  exampleSentence?: string;
  exampleTranslation?: string;
  forms: Partial<Record<DialectCode, VocabularyForm>>;
};

const SHARED_NOTE =
  "Shared Kalenjin root. Variety-specific pronunciation and usage require confirmation by a native-speaker reviewer.";

const NANDI_NOTE =
  "Form listed for Nandi in beginner materials. Pronunciation differs from Kipsigis; reviewer confirmation pending.";

const OTHER_NOTE =
  "Documented as a cognate in this variety. Local form, spelling and tone are pending native-speaker review.";

const verified = (word: string, pronunciationGuide?: string): VocabularyForm => ({
  word,
  status: "verified",
  pronunciationGuide,
  note: "Attested in published Kalenjin learner material. Independent in-app reviewer sign-off is tracked separately.",
});

const review = (word: string, note = SHARED_NOTE, pronunciationGuide?: string): VocabularyForm => ({
  word,
  status: "needs_review",
  note,
  pronunciationGuide,
});

export const lexicon: LexiconConcept[] = [
  {
    conceptKey: "greeting.hello",
    definition: "hello / greetings",
    category: "greetings",
    frequencyRank: 1,
    exampleSentence: "Chamgei!",
    exampleTranslation: "Greetings!",
    forms: {
      kipsigis: verified("Chamgei", "cham-GAY"),
      nandi: verified("Chamgei", "cham-GAY"),
      tugen: review("Chamgei", OTHER_NOTE, "cham-GAY"),
      keiyo: review("Chamgei", OTHER_NOTE, "cham-GAY"),
      marakwet: review("Chamgei", OTHER_NOTE, "cham-GAY"),
      pokot: review("Chamgei", OTHER_NOTE, "cham-GAY"),
      sabaot: review("Chamgei", OTHER_NOTE, "cham-GAY"),
    },
  },
  {
    conceptKey: "greeting.thanks",
    definition: "thank you",
    category: "greetings",
    frequencyRank: 2,
    forms: {
      kipsigis: verified("Kongoi", "kong-GOY"),
      nandi: verified("Kongoi", "kong-GOY"),
      tugen: review("Kongoi", OTHER_NOTE, "kong-GOY"),
      keiyo: review("Kongoi", OTHER_NOTE, "kong-GOY"),
      marakwet: review("Kongoi", OTHER_NOTE, "kong-GOY"),
      pokot: review("Kongoi", OTHER_NOTE, "kong-GOY"),
      sabaot: review("Kongoi", OTHER_NOTE, "kong-GOY"),
    },
  },
  {
    conceptKey: "greeting.thanks_very_much",
    definition: "thank you very much",
    category: "greetings",
    frequencyRank: 60,
    forms: {
      kipsigis: review(
        "Kongoi mising",
        "Two-part expression recorded in learner material. The intensifier is the element that needs reviewer confirmation.",
        "kong-GOY mee-SING",
      ),
      nandi: review("Kongoi mising", NANDI_NOTE),
    },
  },
  {
    conceptKey: "greeting.yes",
    definition: "yes",
    category: "greetings",
    frequencyRank: 6,
    forms: {
      kipsigis: verified("Ae", "ah-EH"),
      nandi: verified("Ae", "ah-EH"),
      tugen: review("Ae", OTHER_NOTE, "ah-EH"),
      keiyo: review("Ae", OTHER_NOTE, "ah-EH"),
      marakwet: review("Ae", OTHER_NOTE, "ah-EH"),
      pokot: review("Ae", OTHER_NOTE, "ah-EH"),
      sabaot: review("Ae", OTHER_NOTE, "ah-EH"),
    },
  },
  {
    conceptKey: "greeting.no",
    definition: "no / it is not there",
    category: "greetings",
    frequencyRank: 7,
    forms: {
      kipsigis: review(
        "Maate",
        "Kalenjin marks negation inside the verb. 'Maate' is an existential negative ('there is none') and is not a universal word for 'no' — reviewer confirmation required.",
        "mah-AH-teh",
      ),
      nandi: review("Maate", NANDI_NOTE),
    },
  },
  {
    conceptKey: "number.one",
    definition: "one (1)",
    category: "numbers",
    frequencyRank: 11,
    exampleSentence: "Akeng'",
    exampleTranslation: "one",
    forms: {
      kipsigis: verified("Akeng'", "ah-KENG"),
      nandi: verified("Akeng'", "ah-KENG"),
      tugen: review("Akeng'", OTHER_NOTE, "ah-KENG"),
      keiyo: review("Akeng'", OTHER_NOTE, "ah-KENG"),
      marakwet: review("Akeng'", OTHER_NOTE, "ah-KENG"),
      pokot: review("Akeng'", OTHER_NOTE, "ah-KENG"),
      sabaot: review("Akeng'", OTHER_NOTE, "ah-KENG"),
    },
  },
  {
    conceptKey: "number.two",
    definition: "two (2)",
    category: "numbers",
    frequencyRank: 12,
    forms: {
      kipsigis: verified("Aeng'", "ah-ENG"),
      nandi: verified("Aeng'", "ah-ENG"),
      tugen: review("Aeng'", OTHER_NOTE, "ah-ENG"),
      keiyo: review("Aeng'", OTHER_NOTE, "ah-ENG"),
      marakwet: review("Aeng'", OTHER_NOTE, "ah-ENG"),
    },
  },
  {
    conceptKey: "number.three",
    definition: "three (3)",
    category: "numbers",
    frequencyRank: 13,
    forms: {
      kipsigis: verified("Somok", "so-MOK"),
      nandi: verified("Somok", "so-MOK"),
      tugen: review("Somok", OTHER_NOTE, "so-MOK"),
      keiyo: review("Somok", OTHER_NOTE, "so-MOK"),
      marakwet: review("Somok", OTHER_NOTE, "so-MOK"),
    },
  },
  {
    conceptKey: "number.four",
    definition: "four (4)",
    category: "numbers",
    frequencyRank: 14,
    forms: {
      kipsigis: verified("Ang'wan", "ang-WAHN"),
      nandi: verified("Ang'wan", "ang-WAHN"),
      tugen: review("Ang'wan", OTHER_NOTE, "ang-WAHN"),
    },
  },
  {
    conceptKey: "number.five",
    definition: "five (5)",
    category: "numbers",
    frequencyRank: 15,
    forms: {
      kipsigis: verified("Mut", "moot"),
      nandi: verified("Mut", "moot"),
      tugen: review("Mut", OTHER_NOTE, "moot"),
    },
  },
  {
    conceptKey: "number.six",
    definition: "six (6)",
    category: "numbers",
    frequencyRank: 16,
    forms: {
      kipsigis: verified("Lo", "loh"),
      nandi: verified("Lo", "loh"),
    },
  },
  {
    conceptKey: "number.seven",
    definition: "seven (7)",
    category: "numbers",
    frequencyRank: 17,
    forms: {
      kipsigis: verified("Tisap", "tee-SAHP"),
      nandi: verified("Tisap", "tee-SAHP"),
    },
  },
  {
    conceptKey: "number.eight",
    definition: "eight (8)",
    category: "numbers",
    frequencyRank: 18,
    forms: {
      kipsigis: verified("Sisiit", "see-SEET"),
      nandi: verified("Sisiit", "see-SEET"),
    },
  },
  {
    conceptKey: "number.nine",
    definition: "nine (9)",
    category: "numbers",
    frequencyRank: 19,
    forms: {
      kipsigis: verified("Sokol", "so-KOL"),
      nandi: verified("Sokol", "so-KOL"),
    },
  },
  {
    conceptKey: "number.ten",
    definition: "ten (10)",
    category: "numbers",
    frequencyRank: 20,
    forms: {
      kipsigis: verified("Taman", "tah-MAHN"),
      nandi: verified("Taman", "tah-MAHN"),
    },
  },
  {
    conceptKey: "nature.water",
    definition: "water",
    category: "nature",
    frequencyRank: 30,
    forms: {
      kipsigis: verified("Pek", "pek"),
      nandi: verified("Pek", "pek"),
      tugen: review("Pek", OTHER_NOTE, "pek"),
      keiyo: review("Pek", OTHER_NOTE, "pek"),
      marakwet: review("Pek", OTHER_NOTE, "pek"),
      pokot: review("Pek", OTHER_NOTE, "pek"),
      sabaot: review("Pek", OTHER_NOTE, "pek"),
    },
  },
  {
    conceptKey: "nature.fire",
    definition: "fire",
    category: "nature",
    frequencyRank: 31,
    forms: {
      kipsigis: verified("Mat", "maht"),
      nandi: verified("Mat", "maht"),
      tugen: review("Mat", OTHER_NOTE, "maht"),
      keiyo: review("Mat", OTHER_NOTE, "maht"),
      marakwet: review("Mat", OTHER_NOTE, "maht"),
      pokot: review("Mat", OTHER_NOTE, "maht"),
      sabaot: review("Mat", OTHER_NOTE, "maht"),
    },
  },
  {
    conceptKey: "nature.sun",
    definition: "sun",
    category: "nature",
    frequencyRank: 32,
    forms: {
      kipsigis: verified("Asista", "ah-SEES-tah"),
      nandi: verified("Asista", "ah-SEES-tah"),
      tugen: review("Asista", OTHER_NOTE, "ah-SEES-tah"),
      keiyo: review("Asista", OTHER_NOTE, "ah-SEES-tah"),
      marakwet: review("Asista", OTHER_NOTE, "ah-SEES-tah"),
      pokot: review("Asista", OTHER_NOTE, "ah-SEES-tah"),
      sabaot: review("Asista", OTHER_NOTE, "ah-SEES-tah"),
    },
  },
  {
    conceptKey: "nature.moon",
    definition: "moon / month",
    category: "nature",
    frequencyRank: 33,
    forms: {
      kipsigis: verified("Arawet", "ah-rah-WET"),
      nandi: review("Arawet", NANDI_NOTE, "ah-rah-WET"),
      tugen: review("Arawet", OTHER_NOTE, "ah-rah-WET"),
    },
  },
  {
    conceptKey: "nature.rain",
    definition: "rain",
    category: "nature",
    frequencyRank: 34,
    forms: {
      kipsigis: review(
        "Ng'weny",
        "Recorded in learner lists as 'rain'. Tone and noun-class behaviour need reviewer confirmation before being used in sentences.",
        "ng-WEN-y",
      ),
      nandi: review("Ng'weny", NANDI_NOTE, "ng-WEN-y"),
    },
  },
  {
    conceptKey: "family.mother",
    definition: "mother",
    category: "family",
    frequencyRank: 40,
    forms: {
      kipsigis: review("Kogo", "Kinship terms are strongly variety- and register-dependent. Awaiting native-speaker confirmation for this variety."),
      nandi: review("Kogo", NANDI_NOTE),
      tugen: review("Kogo", OTHER_NOTE),
    },
  },
  {
    conceptKey: "family.father",
    definition: "father",
    category: "family",
    frequencyRank: 41,
    forms: {
      kipsigis: review("Kwanda", "Kinship term recorded for Kipsigis; honourific/respect forms differ by family context."),
      nandi: review("Kwanda", NANDI_NOTE),
      tugen: review("Kwanda", OTHER_NOTE),
    },
  },
  {
    conceptKey: "family.child",
    definition: "child",
    category: "family",
    frequencyRank: 42,
    forms: {
      kipsigis: review("Ng'etun", "Diminutive/plural forms differ; reviewer to confirm singular vs. collective usage."),
      nandi: review("Ng'etun", NANDI_NOTE),
    },
  },
  {
    conceptKey: "home.house",
    definition: "house / home",
    category: "home",
    frequencyRank: 45,
    forms: {
      kipsigis: review("Kot", "Basic noun in learner material. Noun-class and possessive forms need verification."),
      nandi: review("Kot", NANDI_NOTE),
    },
  },
  {
    conceptKey: "animal.cow",
    definition: "cow / cattle",
    category: "animals",
    frequencyRank: 50,
    forms: {
      kipsigis: review("Teta", "Central cultural term; singular/plural and age/gender distinctions are extensive and require review."),
      nandi: review("Teta", NANDI_NOTE),
    },
  },
  {
    conceptKey: "animal.dog",
    definition: "dog",
    category: "animals",
    frequencyRank: 51,
    forms: {
      kipsigis: review("Ng'okto", "Learner-list form; spelling and tone pending review."),
      nandi: review("Ng'okto", NANDI_NOTE),
    },
  },
  {
    conceptKey: "people.chief",
    definition: "chief / leader",
    category: "people",
    frequencyRank: 52,
    forms: {
      kipsigis: review("Kiruogindet", "Title recorded in published material. Status/role nuance needs cultural review."),
      nandi: review("Kiruogindet", NANDI_NOTE),
      tugen: review("Kiruogindet", OTHER_NOTE),
    },
  },
  {
    conceptKey: "verb.eat",
    definition: "to eat",
    category: "verbs",
    frequencyRank: 55,
    forms: {
      kipsigis: review(
        "Am",
        "Verb root recorded in beginner material. Kalenjin verbs are inflected for person, tense and aspect, so the bare root is not a full word — do not use it as a finished sentence.",
      ),
      nandi: review("Am", NANDI_NOTE),
    },
  },
  {
    conceptKey: "verb.see",
    definition: "to see",
    category: "verbs",
    frequencyRank: 56,
    forms: {
      kipsigis: review("Nyone", "Root-level gloss. Conjugation must be reviewed before sentence use."),
      nandi: review("Nyone", NANDI_NOTE),
    },
  },
  {
    conceptKey: "verb.speak",
    definition: "to say / to speak",
    category: "verbs",
    frequencyRank: 57,
    forms: {
      kipsigis: review(
        "Ales",
        "Related to the root heard in the name 'Kalenjin'. Inflected forms change with subject and tense — confirm before production use.",
      ),
      nandi: review("Ales", NANDI_NOTE),
    },
  },
  {
    conceptKey: "culture.mursik",
    definition: "mursik (fermented milk, a Kalenjin speciality)",
    category: "culture",
    frequencyRank: 70,
    forms: {
      kipsigis: verified("Mursik", "moor-SEEK"),
      nandi: verified("Mursik", "moor-SEEK"),
      tugen: review("Mursik", OTHER_NOTE, "moor-SEEK"),
      keiyo: review("Mursik", OTHER_NOTE, "moor-SEEK"),
      marakwet: review("Mursik", OTHER_NOTE, "moor-SEEK"),
      pokot: review("Mursik", OTHER_NOTE, "moor-SEEK"),
      sabaot: review("Mursik", OTHER_NOTE, "moor-SEEK"),
    },
  },
  {
    conceptKey: "culture.kalenjin",
    definition: "Kalenjin (the people / the language family)",
    category: "culture",
    frequencyRank: 71,
    forms: {
      kipsigis: verified("Kalenjin", "kah-len-JEEN"),
      nandi: verified("Kalenjin", "kah-len-JEEN"),
      tugen: verified("Kalenjin", "kah-len-JEEN"),
      keiyo: verified("Kalenjin", "kah-len-JEEN"),
      marakwet: verified("Kalenjin", "kah-len-JEEN"),
      pokot: review("Kalenjin", "Pokot speakers often identify by 'Pökoot'; the wider term is used differently across communities."),
      sabaot: review("Kalenjin", "Sabaot speakers identify primarily as Sabaot; wider Kalenjin identity is contextual."),
    },
  },
];

export type PhraseSeed = {
  conceptKey: string;
  english: string;
  category: string;
  forms: Partial<Record<DialectCode, { kalenjin: string; status: VerificationStatus; note?: string }>>;
  alternatives?: { kalenjin: string; english: string; note: string }[];
};

export const phraseSeeds: PhraseSeed[] = [
  {
    conceptKey: "phrase.hello",
    english: "Hello",
    category: "greetings",
    forms: {
      kipsigis: { kalenjin: "Chamgei", status: "verified" },
      nandi: { kalenjin: "Chamgei", status: "verified" },
      tugen: { kalenjin: "Chamgei", status: "needs_review", note: OTHER_NOTE },
      keiyo: { kalenjin: "Chamgei", status: "needs_review", note: OTHER_NOTE },
      marakwet: { kalenjin: "Chamgei", status: "needs_review", note: OTHER_NOTE },
      pokot: { kalenjin: "Chamgei", status: "needs_review", note: OTHER_NOTE },
      sabaot: { kalenjin: "Chamgei", status: "needs_review", note: OTHER_NOTE },
    },
  },
  {
    conceptKey: "phrase.thank_you",
    english: "Thank you",
    category: "greetings",
    forms: {
      kipsigis: { kalenjin: "Kongoi", status: "verified" },
      nandi: { kalenjin: "Kongoi", status: "verified" },
      tugen: { kalenjin: "Kongoi", status: "needs_review", note: OTHER_NOTE },
      keiyo: { kalenjin: "Kongoi", status: "needs_review", note: OTHER_NOTE },
      marakwet: { kalenjin: "Kongoi", status: "needs_review", note: OTHER_NOTE },
      pokot: { kalenjin: "Kongoi", status: "needs_review", note: OTHER_NOTE },
      sabaot: { kalenjin: "Kongoi", status: "needs_review", note: OTHER_NOTE },
    },
  },
  {
    conceptKey: "phrase.thank_you_very_much",
    english: "Thank you very much",
    category: "greetings",
    forms: {
      kipsigis: { kalenjin: "Kongoi mising", status: "needs_review", note: "Intensifier pending reviewer confirmation." },
      nandi: { kalenjin: "Kongoi mising", status: "needs_review", note: NANDI_NOTE },
    },
  },
  {
    conceptKey: "phrase.yes",
    english: "Yes",
    category: "greetings",
    forms: {
      kipsigis: { kalenjin: "Ae", status: "verified" },
      nandi: { kalenjin: "Ae", status: "verified" },
      tugen: { kalenjin: "Ae", status: "needs_review", note: OTHER_NOTE },
      keiyo: { kalenjin: "Ae", status: "needs_review", note: OTHER_NOTE },
      marakwet: { kalenjin: "Ae", status: "needs_review", note: OTHER_NOTE },
    },
  },
  {
    conceptKey: "phrase.no",
    english: "No",
    category: "greetings",
    forms: {
      kipsigis: {
        kalenjin: "Maate",
        status: "needs_review",
        note: "Existential negative ('there is none'). Kalenjin usually negates inside the verb; this is not a universal 'no'.",
      },
      nandi: { kalenjin: "Maate", status: "needs_review", note: NANDI_NOTE },
    },
  },
  {
    conceptKey: "phrase.count_1_3",
    english: "One, two, three",
    category: "numbers",
    forms: {
      kipsigis: { kalenjin: "Akeng', aeng', somok", status: "verified" },
      nandi: { kalenjin: "Akeng', aeng', somok", status: "verified" },
      tugen: { kalenjin: "Akeng', aeng', somok", status: "needs_review", note: OTHER_NOTE },
      keiyo: { kalenjin: "Akeng', aeng', somok", status: "needs_review", note: OTHER_NOTE },
      marakwet: { kalenjin: "Akeng', aeng', somok", status: "needs_review", note: OTHER_NOTE },
    },
  },
  {
    conceptKey: "phrase.count_1_5",
    english: "One, two, three, four, five",
    category: "numbers",
    forms: {
      kipsigis: { kalenjin: "Akeng', aeng', somok, ang'wan, mut", status: "verified" },
      nandi: { kalenjin: "Akeng', aeng', somok, ang'wan, mut", status: "verified" },
      tugen: { kalenjin: "Akeng', aeng', somok, ang'wan, mut", status: "needs_review", note: OTHER_NOTE },
    },
  },
  {
    conceptKey: "phrase.water",
    english: "Water",
    category: "nature",
    forms: {
      kipsigis: { kalenjin: "Pek", status: "verified" },
      nandi: { kalenjin: "Pek", status: "verified" },
      tugen: { kalenjin: "Pek", status: "needs_review", note: OTHER_NOTE },
      keiyo: { kalenjin: "Pek", status: "needs_review", note: OTHER_NOTE },
      marakwet: { kalenjin: "Pek", status: "needs_review", note: OTHER_NOTE },
      pokot: { kalenjin: "Pek", status: "needs_review", note: OTHER_NOTE },
      sabaot: { kalenjin: "Pek", status: "needs_review", note: OTHER_NOTE },
    },
  },
  {
    conceptKey: "phrase.fire",
    english: "Fire",
    category: "nature",
    forms: {
      kipsigis: { kalenjin: "Mat", status: "verified" },
      nandi: { kalenjin: "Mat", status: "verified" },
      tugen: { kalenjin: "Mat", status: "needs_review", note: OTHER_NOTE },
      keiyo: { kalenjin: "Mat", status: "needs_review", note: OTHER_NOTE },
    },
  },
  {
    conceptKey: "phrase.sun",
    english: "The sun",
    category: "nature",
    forms: {
      kipsigis: { kalenjin: "Asista", status: "verified" },
      nandi: { kalenjin: "Asista", status: "verified" },
      tugen: { kalenjin: "Asista", status: "needs_review", note: OTHER_NOTE },
    },
  },
  {
    conceptKey: "phrase.mother",
    english: "Mother",
    category: "family",
    forms: {
      kipsigis: { kalenjin: "Kogo", status: "needs_review", note: "Kinship register requires native review." },
      nandi: { kalenjin: "Kogo", status: "needs_review", note: NANDI_NOTE },
    },
  },
  {
    conceptKey: "phrase.father",
    english: "Father",
    category: "family",
    forms: {
      kipsigis: { kalenjin: "Kwanda", status: "needs_review", note: "Kinship register requires native review." },
      nandi: { kalenjin: "Kwanda", status: "needs_review", note: NANDI_NOTE },
    },
  },
  {
    conceptKey: "phrase.house",
    english: "House",
    category: "home",
    forms: {
      kipsigis: { kalenjin: "Kot", status: "needs_review", note: "Noun-class behaviour pending review." },
      nandi: { kalenjin: "Kot", status: "needs_review", note: NANDI_NOTE },
    },
  },
  {
    conceptKey: "phrase.mursik",
    english: "Mursik (fermented milk)",
    category: "culture",
    forms: {
      kipsigis: { kalenjin: "Mursik", status: "verified" },
      nandi: { kalenjin: "Mursik", status: "verified" },
    },
  },
];
