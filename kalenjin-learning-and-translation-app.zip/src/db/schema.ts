import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Meta                                                                */
/* ------------------------------------------------------------------ */

export const appMeta = pgTable("app_meta", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});

/* ------------------------------------------------------------------ */
/* Language varieties                                                  */
/* ------------------------------------------------------------------ */

export const dialects = pgTable("dialects", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  nativeName: text("native_name").notNull(),
  description: text("description").notNull(),
  region: text("region").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/* ------------------------------------------------------------------ */
/* Accounts                                                            */
/* ------------------------------------------------------------------ */

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    username: text("username").notNull(),
    email: text("email").notNull(),
    passwordHash: text("password_hash").notNull(),
    role: text("role").notNull().default("learner"), // learner | contributor | admin
    preferredLanguage: text("preferred_language").notNull().default("en"),
    dialectId: integer("dialect_id").references(() => dialects.id),
    proficiencyLevel: text("proficiency_level").notNull().default("beginner"),
    dailyGoalMinutes: integer("daily_goal_minutes").notNull().default(10),
    xp: integer("xp").notNull().default(0),
    streak: integer("streak").notNull().default(0),
    lastActiveDay: date("last_active_day"),
    onboarded: boolean("onboarded").notNull().default(false),
    theme: text("theme").notNull().default("system"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("users_email_unique").on(table.email),
    uniqueIndex("users_username_unique").on(table.username),
  ],
);

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(), // sha256 of the raw token
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("sessions_user_idx").on(table.userId)],
);

/* ------------------------------------------------------------------ */
/* Linguistics                                                         */
/* ------------------------------------------------------------------ */

export const vocabulary = pgTable(
  "vocabulary",
  {
    id: serial("id").primaryKey(),
    dialectId: integer("dialect_id")
      .notNull()
      .references(() => dialects.id, { onDelete: "cascade" }),
    conceptKey: text("concept_key").notNull(),
    word: text("word").notNull(),
    normalized: text("normalized").notNull(),
    definition: text("definition").notNull(),
    category: text("category").notNull(),
    pronunciationGuide: text("pronunciation_guide"),
    exampleSentence: text("example_sentence"),
    exampleTranslation: text("example_translation"),
    verificationStatus: text("verification_status").notNull().default("needs_review"),
    verificationNote: text("verification_note"),
    frequencyRank: integer("frequency_rank").notNull().default(100),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("vocabulary_dialect_concept_unique").on(table.dialectId, table.conceptKey),
    index("vocabulary_normalized_idx").on(table.normalized),
    index("vocabulary_category_idx").on(table.category),
  ],
);

export const phrases = pgTable(
  "phrases",
  {
    id: serial("id").primaryKey(),
    dialectId: integer("dialect_id")
      .notNull()
      .references(() => dialects.id, { onDelete: "cascade" }),
    conceptKey: text("concept_key").notNull(),
    english: text("english").notNull(),
    kalenjin: text("kalenjin").notNull(),
    normalizedEnglish: text("normalized_english").notNull(),
    normalizedKalenjin: text("normalized_kalenjin").notNull(),
    category: text("category").notNull(),
    verificationStatus: text("verification_status").notNull().default("needs_review"),
    verificationNote: text("verification_note"),
    alternatives: jsonb("alternatives").$type<{ kalenjin: string; english: string; note: string }[]>().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("phrases_dialect_concept_unique").on(table.dialectId, table.conceptKey),
    index("phrases_dialect_idx").on(table.dialectId),
  ],
);

export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  level: integer("level").notNull(),
  orderIndex: integer("order_index").notNull().default(0),
  estimatedMinutes: integer("estimated_minutes").notNull().default(8),
  objectives: jsonb("objectives").$type<string[]>().notNull().default([]),
  conceptKeys: jsonb("concept_keys").$type<string[]>().notNull().default([]),
  grammarNotes: text("grammar_notes").notNull().default(""),
  exercises: jsonb("exercises").$type<unknown[]>().notNull().default([]),
  verificationStatus: text("verification_status").notNull().default("needs_review"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const culturalNotes = pgTable("cultural_notes", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  dialectId: integer("dialect_id").references(() => dialects.id),
  title: text("title").notNull(),
  category: text("category").notNull(),
  summary: text("summary").notNull(),
  body: text("body").notNull(),
  verificationStatus: text("verification_status").notNull().default("needs_review"),
  contributor: text("contributor"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/* ------------------------------------------------------------------ */
/* Learner activity                                                    */
/* ------------------------------------------------------------------ */

export const userProgress = pgTable(
  "user_progress",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    lessonId: integer("lesson_id")
      .notNull()
      .references(() => lessons.id, { onDelete: "cascade" }),
    status: text("status").notNull().default("in_progress"),
    score: integer("score").notNull().default(0),
    attempts: integer("attempts").notNull().default(0),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("user_progress_unique").on(table.userId, table.lessonId)],
);

export const favorites = pgTable(
  "favorites",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    vocabularyId: integer("vocabulary_id")
      .notNull()
      .references(() => vocabulary.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("favorites_unique").on(table.userId, table.vocabularyId)],
);

export const userVocabulary = pgTable(
  "user_vocabulary",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    vocabularyId: integer("vocabulary_id")
      .notNull()
      .references(() => vocabulary.id, { onDelete: "cascade" }),
    strength: integer("strength").notNull().default(1),
    learnedAt: timestamp("learned_at", { withTimezone: true }).defaultNow().notNull(),
    lastReviewedAt: timestamp("last_reviewed_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("user_vocabulary_unique").on(table.userId, table.vocabularyId)],
);

export const achievements = pgTable(
  "achievements",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    type: text("type").notNull(),
    earnedAt: timestamp("earned_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("achievements_unique").on(table.userId, table.type)],
);

export const dailyActivity = pgTable(
  "daily_activity",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    day: date("day").notNull(),
    xpEarned: integer("xp_earned").notNull().default(0),
    minutes: integer("minutes").notNull().default(0),
    lessonsCompleted: integer("lessons_completed").notNull().default(0),
    reviews: integer("reviews").notNull().default(0),
  },
  (table) => [uniqueIndex("daily_activity_unique").on(table.userId, table.day)],
);

export const gameScores = pgTable(
  "game_scores",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    gameType: text("game_type").notNull(),
    dialectId: integer("dialect_id").references(() => dialects.id),
    score: integer("score").notNull().default(0),
    total: integer("total").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("game_scores_user_idx").on(table.userId)],
);

/* ------------------------------------------------------------------ */
/* Translation + speech                                                */
/* ------------------------------------------------------------------ */

export const translations = pgTable(
  "translations",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    sourceText: text("source_text").notNull(),
    translatedText: text("translated_text"),
    sourceLanguage: text("source_language").notNull(),
    targetLanguage: text("target_language").notNull(),
    dialectId: integer("dialect_id").references(() => dialects.id),
    confidenceStatus: text("confidence_status").notNull(),
    confidenceScore: real("confidence_score").notNull().default(0),
    provider: text("provider").notNull().default("verified-corpus"),
    matchedPhraseId: integer("matched_phrase_id").references(() => phrases.id, {
      onDelete: "set null",
    }),
    notes: text("notes"),
    mode: text("mode").notNull().default("text"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("translations_user_idx").on(table.userId, table.createdAt)],
);

export const recordings = pgTable(
  "recordings",
  {
    id: serial("id").primaryKey(),
    dialectId: integer("dialect_id").references(() => dialects.id),
    vocabularyId: integer("vocabulary_id").references(() => vocabulary.id, { onDelete: "set null" }),
    phraseId: integer("phrase_id").references(() => phrases.id, { onDelete: "set null" }),
    contributorId: integer("contributor_id").references(() => users.id, { onDelete: "set null" }),
    speakerName: text("speaker_name").notNull(),
    consentStatus: text("consent_status").notNull().default("pending"),
    audioUrl: text("audio_url"),
    reviewStatus: text("review_status").notNull().default("pending"),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("recordings_dialect_idx").on(table.dialectId)],
);

/* ------------------------------------------------------------------ */
/* Contributions + review queue                                        */
/* ------------------------------------------------------------------ */

export const contributions = pgTable(
  "contributions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    type: text("type").notNull(), // vocabulary | correction | recording | example | cultural
    dialectId: integer("dialect_id").references(() => dialects.id),
    payload: jsonb("payload").$type<Record<string, string>>().notNull(),
    consent: boolean("consent").notNull().default(false),
    status: text("status").notNull().default("pending"),
    reviewerId: integer("reviewer_id").references(() => users.id, { onDelete: "set null" }),
    reviewNote: text("review_note"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  },
  (table) => [index("contributions_status_idx").on(table.status)],
);

/* ------------------------------------------------------------------ */
/* Tutor transcript                                                    */
/* ------------------------------------------------------------------ */

export const tutorMessages = pgTable(
  "tutor_messages",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: text("role").notNull(),
    content: text("content").notNull(),
    grounding: jsonb("grounding").$type<string[]>().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("tutor_messages_user_idx").on(table.userId, table.createdAt)],
);
