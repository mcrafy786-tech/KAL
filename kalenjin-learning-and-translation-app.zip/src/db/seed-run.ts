import "dotenv/config";
import { ensureSeeded, SEED_VERSION } from "@/db/seed";
import { pool } from "@/db";

async function main() {
  await ensureSeeded();
  const result = await pool.query<{ count: string }>("select count(*)::text as count from vocabulary");
  const dialects = await pool.query<{ count: string }>("select count(*)::text as count from dialects");
  console.log(
    `Seed ${SEED_VERSION} applied. ${result.rows[0]?.count ?? 0} vocabulary rows across ${
      dialects.rows[0]?.count ?? 0
    } varieties.`,
  );
}

main()
  .catch((error) => {
    console.error("Seeding failed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await pool.end();
  });
