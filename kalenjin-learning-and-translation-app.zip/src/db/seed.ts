import { eq, sql } from "drizzle-orm";
import { db, pool } from "@/db";
import {
  achievements,
  culturalNotes,
  dailyActivity,
  dialects,
  lessons,
  phrases,
  userProgress,
  userVocabulary,
  users,
  vocabulary,
} from "@/db/schema";
import { dialectSeeds } from "@/content/dialects";
import { lexicon, phraseSeeds, type DialectCode } from "@/content/lexicon";
import { cultureSeeds, lessonSeeds } from "@/content/lessons";
import { hashPassword } from "@/lib/password";
import { isoDaysAgo, normalizeText, todayIso } from "@/lib/text";

export const SEED_VERSION = "2026-02-01.1";

let seededInProcess = false;

/**
 * Idempotent content seed. Runs under a Postgres advisory lock so that
 * concurrent server instances cannot double-insert. Bumping SEED_VERSION
 * refreshes editorial content without touching learner data or contributions.
 */
export async function ensureSeeded(): Promise<void> {
  if (seededInProcess) return;
  const client = await pool.connect();
  try {
    await client.query("select pg_advisory_lock($1)", [918273645]);
    const existing = await client.query<{ value: string }>(
      "select value from app_meta where key = 'seed_version' limit 1",
    );
    if (existing.rows[0]?.value === SEED_VERSION) {
      seededInProcess = true;
      return;
    }
    await runSeed();
    await client.query(
      "insert into app_meta (key, value) values ('seed_version', $1) on conflict (key) do update set value = excluded.value",
      [SEED_VERSION],
    );
    seededInProcess = true;
  } finally {
    await client.query("select pg_advisory_unlock($1)", [918273645]).catch(() => undefined);
    client.release();
  }
}

async function runSeed(): Promise<void> {
  for (const dialect of dialectSeeds) {
    await db
      .insert(dialects)
      .values(dialect)
      .onConflictDoUpdate({
        target: dialects.code,
        set: {
          name: dialect.name,
          nativeName: dialect.nativeName,
          description: dialect.description,
          region: dialect.region,
          sortOrder: dialect.sortOrder,
        },
      });
  }

  const dialectRows = await db.select().from(dialects);
  const dialectIdByCode = new Map(dialectRows.map((row) => [row.code, row.id]));

  for (const concept of lexicon) {
    for (const [code, form] of Object.entries(concept.forms)) {
      const dialectId = dialectIdByCode.get(code);
      if (!dialectId || !form) continue;
      await db
        .insert(vocabulary)
        .values({
          dialectId,
          conceptKey: concept.conceptKey,
          word: form.word,
          normalized: normalizeText(form.word),
          definition: concept.definition,
          category: concept.category,
          pronunciationGuide: form.pronunciationGuide ?? null,
          exampleSentence: concept.exampleSentence ?? null,
          exampleTranslation: concept.exampleTranslation ?? null,
          verificationStatus: form.status,
          verificationNote: form.note ?? null,
          frequencyRank: concept.frequencyRank,
        })
        .onConflictDoUpdate({
          target: [vocabulary.dialectId, vocabulary.conceptKey],
          set: {
            word: form.word,
            normalized: normalizeText(form.word),
            definition: concept.definition,
            category: concept.category,
            pronunciationGuide: form.pronunciationGuide ?? null,
            exampleSentence: concept.exampleSentence ?? null,
            exampleTranslation: concept.exampleTranslation ?? null,
            verificationStatus: form.status,
            verificationNote: form.note ?? null,
            frequencyRank: concept.frequencyRank,
          },
        });
    }
  }

  for (const phrase of phraseSeeds) {
    for (const [code, form] of Object.entries(phrase.forms)) {
      const dialectId = dialectIdByCode.get(code);
      if (!dialectId || !form) continue;
      await db
        .insert(phrases)
        .values({
          dialectId,
          conceptKey: phrase.conceptKey,
          english: phrase.english,
          kalenjin: form.kalenjin,
          normalizedEnglish: normalizeText(phrase.english),
          normalizedKalenjin: normalizeText(form.kalenjin),
          category: phrase.category,
          verificationStatus: form.status,
          verificationNote: form.note ?? null,
          alternatives: phrase.alternatives ?? [],
        })
        .onConflictDoUpdate({
          target: [phrases.dialectId, phrases.conceptKey],
          set: {
            english: phrase.english,
            kalenjin: form.kalenjin,
            normalizedEnglish: normalizeText(phrase.english),
            normalizedKalenjin: normalizeText(form.kalenjin),
            category: phrase.category,
            verificationStatus: form.status,
            verificationNote: form.note ?? null,
            alternatives: phrase.alternatives ?? [],
          },
        });
    }
  }

  for (const lesson of lessonSeeds) {
    await db
      .insert(lessons)
      .values({
        slug: lesson.slug,
        title: lesson.title,
        description: lesson.description,
        level: lesson.level,
        orderIndex: lesson.orderIndex,
        estimatedMinutes: lesson.estimatedMinutes,
        objectives: lesson.objectives,
        conceptKeys: lesson.conceptKeys,
        grammarNotes: lesson.grammarNotes,
        exercises: lesson.exercises,
        verificationStatus: lesson.verificationStatus,
      })
      .onConflictDoUpdate({
        target: lessons.slug,
        set: {
          title: lesson.title,
          description: lesson.description,
          level: lesson.level,
          orderIndex: lesson.orderIndex,
          estimatedMinutes: lesson.estimatedMinutes,
          objectives: lesson.objectives,
          conceptKeys: lesson.conceptKeys,
          grammarNotes: lesson.grammarNotes,
          exercises: lesson.exercises,
          verificationStatus: lesson.verificationStatus,
        },
      });
  }

  for (const note of cultureSeeds) {
    await db
      .insert(culturalNotes)
      .values({
        slug: note.slug,
        title: note.title,
        category: note.category,
        summary: note.summary,
        body: note.body,
        verificationStatus: note.verificationStatus,
        contributor: note.contributor,
        dialectId: note.dialectCode ? (dialectIdByCode.get(note.dialectCode) ?? null) : null,
      })
      .onConflictDoUpdate({
        target: culturalNotes.slug,
        set: {
          title: note.title,
          category: note.category,
          summary: note.summary,
          body: note.body,
          verificationStatus: note.verificationStatus,
          contributor: note.contributor,
        },
      });
  }

  await seedAccounts(dialectIdByCode);
}

async function seedAccounts(dialectIdByCode: Map<string, number>): Promise<void> {
  const kipsigisId = dialectIdByCode.get("kipsigis" satisfies DialectCode) ?? null;

  const accounts = [
    {
      username: "kalenjin_admin",
      email: "admin@kalenjin.app",
      password: "Kalenjin2026!",
      role: "admin",
      proficiencyLevel: "advanced",
      dailyGoalMinutes: 20,
    },
    {
      username: "demo_learner",
      email: "demo@kalenjin.app",
      password: "demo1234",
      role: "learner",
      proficiencyLevel: "beginner",
      dailyGoalMinutes: 10,
    },
    {
      username: "native_contributor",
      email: "contributor@kalenjin.app",
      password: "contributor1234",
      role: "contributor",
      proficiencyLevel: "advanced",
      dailyGoalMinutes: 15,
    },
  ];

  for (const account of accounts) {
    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, account.email)).limit(1);
    if (existing.length > 0) continue;
    await db.insert(users).values({
      username: account.username,
      email: account.email,
      passwordHash: hashPassword(account.password),
      role: account.role,
      preferredLanguage: "en",
      dialectId: kipsigisId,
      proficiencyLevel: account.proficiencyLevel,
      dailyGoalMinutes: account.dailyGoalMinutes,
      onboarded: true,
      xp: account.role === "learner" ? 340 : 0,
      streak: account.role === "learner" ? 4 : 0,
      lastActiveDay: todayIso(),
      theme: "system",
    });
  }

  const demo = await db.select().from(users).where(eq(users.email, "demo@kalenjin.app")).limit(1);
  if (!demo[0]) return;
  const demoId = demo[0].id;

  const progressCount = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(userProgress)
    .where(eq(userProgress.userId, demoId));
  if ((progressCount[0]?.count ?? 0) > 0) return;

  const lessonRows = await db.select().from(lessons).orderBy(lessons.orderIndex).limit(12);
  for (const [index, lesson] of lessonRows.slice(0, 3).entries()) {
    await db.insert(userProgress).values({
      userId: demoId,
      lessonId: lesson.id,
      status: "completed",
      score: [100, 86, 92][index] ?? 80,
      attempts: 1,
      completedAt: new Date(Date.now() - (3 - index) * 86_400_000),
    });
  }

  const vocabRows = await db
    .select()
    .from(vocabulary)
    .where(eq(vocabulary.dialectId, kipsigisId ?? 0))
    .orderBy(vocabulary.frequencyRank)
    .limit(8);
  for (const row of vocabRows) {
    await db
      .insert(userVocabulary)
      .values({ userId: demoId, vocabularyId: row.id, strength: 2 })
      .onConflictDoNothing();
  }

  for (const type of ["first_lesson", "streak_3", "wordsmith_5"]) {
    await db.insert(achievements).values({ userId: demoId, type }).onConflictDoNothing();
  }

  for (let daysAgo = 3; daysAgo >= 0; daysAgo -= 1) {
    await db
      .insert(dailyActivity)
      .values({
        userId: demoId,
        day: isoDaysAgo(daysAgo),
        xpEarned: [40, 60, 0, 90][3 - daysAgo] ?? 30,
        minutes: [6, 9, 0, 12][3 - daysAgo] ?? 5,
        lessonsCompleted: daysAgo === 0 ? 1 : 0,
      })
      .onConflictDoNothing();
  }
}
