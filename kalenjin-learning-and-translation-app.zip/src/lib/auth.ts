import { createHash, randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { dialects, sessions, users } from "@/db/schema";

export { hashPassword, verifyPassword } from "@/lib/password";

export const SESSION_COOKIE = "kal_session";
const SESSION_DAYS = 30;

export type SessionUser = {
  id: number;
  username: string;
  email: string;
  role: string;
  preferredLanguage: string;
  dialectId: number | null;
  dialectCode: string | null;
  dialectName: string | null;
  proficiencyLevel: string;
  dailyGoalMinutes: number;
  xp: number;
  streak: number;
  onboarded: boolean;
  theme: string;
};

function tokenId(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

export async function createSession(userId: number): Promise<void> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ id: tokenId(token), userId, expiresAt });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.COOKIE_SECURE === "true",
    path: "/",
    expires: expiresAt,
  });
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.id, tokenId(token)));
  }
  store.delete(SESSION_COOKIE);
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  try {
    const rows = await db
      .select({
        id: users.id,
        username: users.username,
        email: users.email,
        role: users.role,
        preferredLanguage: users.preferredLanguage,
        dialectId: users.dialectId,
        dialectCode: dialects.code,
        dialectName: dialects.name,
        proficiencyLevel: users.proficiencyLevel,
        dailyGoalMinutes: users.dailyGoalMinutes,
        xp: users.xp,
        streak: users.streak,
        onboarded: users.onboarded,
        theme: users.theme,
      })
      .from(sessions)
      .innerJoin(users, eq(users.id, sessions.userId))
      .leftJoin(dialects, eq(dialects.id, users.dialectId))
      .where(and(eq(sessions.id, tokenId(token)), gt(sessions.expiresAt, new Date())))
      .limit(1);
    return rows[0] ?? null;
  } catch {
    return null;
  }
}

export function sameOrigin(request: Request): boolean {
  const origin = request.headers.get("origin");
  if (!origin) return true;
  try {
    const originHost = new URL(origin).host;
    const host = request.headers.get("host");
    return !host || originHost === host;
  } catch {
    return false;
  }
}

export function jsonError(message: string, status = 400) {
  return Response.json({ ok: false, error: message }, { status });
}
