import { and, asc, desc, eq, inArray, ilike, gte, ne, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeeded } from "@/db/seed";
import {
  achievements,
  contributions,
  culturalNotes,
  dailyActivity,
  dialects,
  favorites,
  gameScores,
  lessons,
  phrases,
  recordings,
  translations,
  userProgress,
  userVocabulary,
  users,
  vocabulary,
} from "@/db/schema";
import type { ExerciseTemplate } from "@/content/lessons";
import { materializeExercises, type ContentEntry, type MaterializedExercise, type PhraseEntry } from "@/lib/exercises";
import { ACHIEVEMENT_DEFS, levelForXp } from "@/lib/gamification";
import { isoDaysAgo, similarity, stripParenthetical, todayIso } from "@/lib/text";
import type { SessionUser } from "@/lib/auth";

export async function loadDialects() {
  await ensureSeeded();
  return db.select().from(dialects).orderBy(asc(dialects.sortOrder));
}

export async function getDialectById(id: number | null | undefined) {
  if (!id) return null;
  await ensureSeeded();
  const [row] = await db.select().from(dialects).where(eq(dialects.id, id)).limit(1);
  return row ?? null;
}

export async function getDefaultDialectId(): Promise<number | null> {
  await ensureSeeded();
  const preferred = process.env.DEFAULT_DIALECT_CODE ?? "kipsigis";
  const [row] = await db
    .select({ id: dialects.id })
    .from(dialects)
    .where(eq(dialects.code, preferred))
    .limit(1);
  if (row) return row.id;
  const [fallback] = await db.select({ id: dialects.id }).from(dialects).orderBy(asc(dialects.sortOrder)).limit(1);
  return fallback?.id ?? null;
}

export async function getVocabularyRows(dialectId: number) {
  await ensureSeeded();
  return db
    .select()
    .from(vocabulary)
    .where(eq(vocabulary.dialectId, dialectId))
    .orderBy(asc(vocabulary.frequencyRank));
}

export async function getPhraseRows(dialectId: number) {
  await ensureSeeded();
  return db.select().from(phrases).where(eq(phrases.dialectId, dialectId)).orderBy(asc(phrases.conceptKey));
}

export function contentEntries(rows: Awaited<ReturnType<typeof getVocabularyRows>>): Map<string, ContentEntry> {
  return new Map(
    rows.map((row) => [
      row.conceptKey,
      {
        conceptKey: row.conceptKey,
        word: row.word,
        definition: row.definition,
        status: row.verificationStatus,
        pronunciationGuide: row.pronunciationGuide,
        note: row.verificationNote,
      },
    ]),
  );
}

export function phraseEntries(rows: Awaited<ReturnType<typeof getPhraseRows>>): Map<string, PhraseEntry> {
  return new Map(
    rows.map((row) => [
      row.conceptKey,
      {
        conceptKey: row.conceptKey,
        english: row.english,
        kalenjin: row.kalenjin,
        status: row.verificationStatus,
        note: row.verificationNote,
      },
    ]),
  );
}

export type DictionaryEntry = {
  id: number;
  word: string;
  definition: string;
  category: string;
  pronunciationGuide: string | null;
  exampleSentence: string | null;
  exampleTranslation: string | null;
  verificationStatus: string;
  verificationNote: string | null;
  favorite: boolean;
  learned: boolean;
  recordCount: number;
};

export async function getDictionary(dialectId: number, userId?: number): Promise<DictionaryEntry[]> {
  const rows = await getVocabularyRows(dialectId);
  if (rows.length === 0) return [];

  const ids = rows.map((row) => row.id);
  const [favoriteRows, learnedRows, recordingRows] = await Promise.all([
    userId
      ? db
          .select({ vocabularyId: favorites.vocabularyId })
          .from(favorites)
          .where(and(eq(favorites.userId, userId), inArray(favorites.vocabularyId, ids)))
      : Promise.resolve([]),
    userId
      ? db
          .select({ vocabularyId: userVocabulary.vocabularyId })
          .from(userVocabulary)
          .where(and(eq(userVocabulary.userId, userId), inArray(userVocabulary.vocabularyId, ids)))
      : Promise.resolve([]),
    db
      .select({ vocabularyId: recordings.vocabularyId })
      .from(recordings)
      .where(inArray(recordings.vocabularyId, ids))
      .catch(() => [] as { vocabularyId: number | null }[]),
  ]);

  const favoriteSet = new Set(favoriteRows.map((row) => row.vocabularyId));
  const learnedSet = new Set(learnedRows.map((row) => row.vocabularyId));
  const recordingCount = new Map<number, number>();
  recordingRows.forEach((row) => {
    if (row.vocabularyId) recordingCount.set(row.vocabularyId, (recordingCount.get(row.vocabularyId) ?? 0) + 1);
  });

  return rows.map((row) => ({
    id: row.id,
    word: row.word,
    definition: row.definition,
    category: row.category,
    pronunciationGuide: row.pronunciationGuide,
    exampleSentence: row.exampleSentence,
    exampleTranslation: row.exampleTranslation,
    verificationStatus: row.verificationStatus,
    verificationNote: row.verificationNote,
    favorite: favoriteSet.has(row.id),
    learned: learnedSet.has(row.id),
    recordCount: recordingCount.get(row.id) ?? 0,
  }));
}

export type LessonCard = {
  id: number;
  slug: string;
  title: string;
  description: string;
  level: number;
  estimatedMinutes: number;
  objectives: string[];
  verificationStatus: string;
  score: number;
  status: "locked" | "available" | "in_progress" | "completed";
  coverage: number;
  totalConcepts: number;
};

export async function getLessonCatalog(userId: number | null, dialectId: number): Promise<LessonCard[]> {
  await ensureSeeded();
  const [lessonRows, progressRows, vocabRows] = await Promise.all([
    db.select().from(lessons).orderBy(asc(lessons.orderIndex)),
    userId ? db.select().from(userProgress).where(eq(userProgress.userId, userId)) : Promise.resolve([]),
    db.select({ conceptKey: vocabulary.conceptKey }).from(vocabulary).where(eq(vocabulary.dialectId, dialectId)),
  ]);

  const progressByLesson = new Map(progressRows.map((row) => [row.lessonId, row]));
  const availableConcepts = new Set(vocabRows.map((row) => row.conceptKey));
  let previousCompleted = true;

  return lessonRows.map((lesson) => {
    const progress = progressByLesson.get(lesson.id);
    const coverage = lesson.conceptKeys.filter((key) => availableConcepts.has(key)).length;
    const completed = progress?.status === "completed";
    const status: LessonCard["status"] = completed
      ? "completed"
      : !previousCompleted || coverage === 0
        ? "locked"
        : progress
          ? "in_progress"
          : "available";
    previousCompleted = completed;
    return {
      id: lesson.id,
      slug: lesson.slug,
      title: lesson.title,
      description: lesson.description,
      level: lesson.level,
      estimatedMinutes: lesson.estimatedMinutes,
      objectives: lesson.objectives,
      verificationStatus: lesson.verificationStatus,
      score: progress?.score ?? 0,
      status,
      coverage,
      totalConcepts: lesson.conceptKeys.length,
    };
  });
}

export async function getLessonDetail(slug: string, dialectId: number, userId: number | null) {
  await ensureSeeded();
  const [lesson] = await db.select().from(lessons).where(eq(lessons.slug, slug)).limit(1);
  if (!lesson) return null;

  const [vocabRows, phraseRows, progressRows] = await Promise.all([
    getVocabularyRows(dialectId),
    getPhraseRows(dialectId),
    userId
      ? db
          .select()
          .from(userProgress)
          .where(and(eq(userProgress.userId, userId), eq(userProgress.lessonId, lesson.id)))
          .limit(1)
      : Promise.resolve([]),
  ]);

  const vocabularyMap = contentEntries(vocabRows);
  const phraseMap = phraseEntries(phraseRows);
  const exercises: MaterializedExercise[] = materializeExercises(
    (lesson.exercises as ExerciseTemplate[]) ?? [],
    vocabularyMap,
    phraseMap,
  );
  const lessonConcepts = lesson.conceptKeys
    .map((key) => vocabularyMap.get(key))
    .filter((entry): entry is ContentEntry => Boolean(entry));

  const allLessons = await db
    .select({ slug: lessons.slug, orderIndex: lessons.orderIndex })
    .from(lessons)
    .orderBy(asc(lessons.orderIndex));
  const currentIndex = allLessons.findIndex((row) => row.slug === slug);

  return {
    lesson,
    exercises,
    concepts: lessonConcepts,
    phraseRows,
    vocabularyIds: lessonConcepts
      .map((entry) => vocabRows.find((row) => row.conceptKey === entry.conceptKey)?.id)
      .filter((id): id is number => typeof id === "number"),
    progress: progressRows[0] ?? null,
    prevSlug: currentIndex > 0 ? allLessons[currentIndex - 1]?.slug : null,
    nextSlug: currentIndex >= 0 ? allLessons[currentIndex + 1]?.slug : null,
  };
}

export async function getDictionaryStats(dialectId: number) {
  const rows = await getVocabularyRows(dialectId);
  const reviewed = rows.filter((row) => row.verificationStatus === "verified").length;
  const pending = rows.length - reviewed;
  const categories = Array.from(new Set(rows.map((row) => row.category)));
  return { total: rows.length, reviewed, pending, categories };
}

export async function getDashboard(user: SessionUser) {
  await ensureSeeded();
  const dialectId = user.dialectId ?? (await getDefaultDialectId());
  const [catalog, vocabRows, todayRows, weeklyRows, achievementRows, translationRows, gameRows, vocabCount, phraseRows] =
    await Promise.all([
      dialectId ? getLessonCatalog(user.id, dialectId) : Promise.resolve([]),
      dialectId ? getVocabularyRows(dialectId) : Promise.resolve([]),
      db
        .select()
        .from(dailyActivity)
        .where(and(eq(dailyActivity.userId, user.id), gte(dailyActivity.day, isoDaysAgo(6))))
        .orderBy(asc(dailyActivity.day)),
      db.select().from(dailyActivity).where(eq(dailyActivity.userId, user.id)).orderBy(desc(dailyActivity.day)).limit(7),
      db.select().from(achievements).where(eq(achievements.userId, user.id)),
      db
        .select()
        .from(translations)
        .where(eq(translations.userId, user.id))
        .orderBy(desc(translations.createdAt))
        .limit(5),
      db.select().from(gameScores).where(eq(gameScores.userId, user.id)).orderBy(desc(gameScores.createdAt)).limit(5),
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(userVocabulary)
        .where(eq(userVocabulary.userId, user.id)),
      dialectId ? getPhraseRows(dialectId) : Promise.resolve([]),
    ]);

  const today = todayRows.find((row) => row.day === todayIso());
  const nextLesson = catalog.find((lesson) => lesson.status === "available" || lesson.status === "in_progress");
  const earnedSet = new Set(achievementRows.map((row) => row.type));
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86_400_000);
  const wordOfDay = vocabRows.length > 0 ? vocabRows[dayOfYear % vocabRows.length] : null;
  const reviewedVocab = vocabRows.filter((row) => row.verificationStatus === "verified").length;

  return {
    dialectId,
    catalog,
    nextLesson,
    wordOfDay,
    today,
    weekly: weeklyRows,
    translations: translationRows,
    games: gameRows,
    achievements: ACHIEVEMENT_DEFS.map((def) => ({ ...def, earned: earnedSet.has(def.type) })),
    learnedWords: vocabCount[0]?.count ?? 0,
    completedLessons: catalog.filter((lesson) => lesson.status === "completed").length,
    coverage: {
      words: vocabRows.length,
      reviewedWords: reviewedVocab,
      phrases: phraseRows.length,
      verifiedPhrases: phraseRows.filter((row) => row.verificationStatus === "verified").length,
    },
    level: levelForXp(user.xp),
    totals: {
      lessons: catalog.length,
      translations: translationRows.length,
      games: gameRows.length,
    },
  };
}

export async function getProgressOverview(user: SessionUser) {
  await ensureSeeded();
  const [activityRows, lessonRows, vocabRows, gameRows, translationRows, contributionRows, achievementRows] =
    await Promise.all([
      db
        .select()
        .from(dailyActivity)
        .where(eq(dailyActivity.userId, user.id))
        .orderBy(desc(dailyActivity.day))
        .limit(14),
      db
        .select({
          slug: lessons.slug,
          title: lessons.title,
          level: lessons.level,
          status: userProgress.status,
          score: userProgress.score,
          completedAt: userProgress.completedAt,
        })
        .from(userProgress)
        .innerJoin(lessons, eq(lessons.id, userProgress.lessonId))
        .where(eq(userProgress.userId, user.id))
        .orderBy(desc(userProgress.updatedAt)),
      db
        .select({
          word: vocabulary.word,
          definition: vocabulary.definition,
          strength: userVocabulary.strength,
          learnedAt: userVocabulary.learnedAt,
        })
        .from(userVocabulary)
        .innerJoin(vocabulary, eq(vocabulary.id, userVocabulary.vocabularyId))
        .where(eq(userVocabulary.userId, user.id))
        .orderBy(desc(userVocabulary.lastReviewedAt))
        .limit(12),
      db.select().from(gameScores).where(eq(gameScores.userId, user.id)).orderBy(desc(gameScores.createdAt)).limit(10),
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(translations)
        .where(eq(translations.userId, user.id)),
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(contributions)
        .where(eq(contributions.userId, user.id)),
      db.select({ type: achievements.type }).from(achievements).where(eq(achievements.userId, user.id)),
    ]);

  const totalMinutes = activityRows.reduce((sum, row) => sum + row.minutes, 0);
  const totalXp = activityRows.reduce((sum, row) => sum + row.xpEarned, 0);
  const earnedSet = new Set(achievementRows.map((row) => row.type));

  return {
    activity: activityRows,
    completedLessons: lessonRows.filter((row) => row.status === "completed"),
    vocab: vocabRows,
    games: gameRows,
    translations: translationRows[0]?.count ?? 0,
    contributions: contributionRows[0]?.count ?? 0,
    totalMinutes,
    totalXp,
    achievements: ACHIEVEMENT_DEFS.map((def) => ({ ...def, earned: earnedSet.has(def.type) })),
    level: levelForXp(user.xp),
  };
}

export async function getHistory(userId: number, limit = 40) {
  await ensureSeeded();
  return db
    .select()
    .from(translations)
    .where(eq(translations.userId, userId))
    .orderBy(desc(translations.createdAt))
    .limit(limit);
}

export async function getCultureNotes(dialectId: number | null) {
  await ensureSeeded();
  const rows = await db.select().from(culturalNotes).orderBy(asc(culturalNotes.id));
  return rows.filter((row) => !row.dialectId || row.dialectId === dialectId);
}

export async function getGameVocabulary(dialectId: number, limit = 30) {
  const rows = await getVocabularyRows(dialectId);
  return rows.slice(0, limit).map((row) => ({
    id: row.id,
    word: row.word,
    definition: stripParenthetical(row.definition),
    category: row.category,
    verificationStatus: row.verificationStatus,
    pronunciationGuide: row.pronunciationGuide,
  }));
}

export async function getAdminSnapshot() {
  await ensureSeeded();
  const [pending, recentRecordings, vocabRows, dialectRows, phraseRows, userRows, processed] = await Promise.all([
    db.select().from(contributions).where(eq(contributions.status, "pending")).orderBy(desc(contributions.createdAt)),
    db.select().from(recordings).orderBy(desc(recordings.createdAt)).limit(12),
    db.select().from(vocabulary).orderBy(desc(vocabulary.id)).limit(40),
    db.select().from(dialects).orderBy(asc(dialects.sortOrder)),
    db.select({ verificationStatus: phrases.verificationStatus }).from(phrases),
    db.select({ count: sql<number>`count(*)::int` }).from(users),
    db
      .select()
      .from(contributions)
      .where(ne(contributions.status, "pending"))
      .orderBy(desc(contributions.reviewedAt))
      .limit(10)
      .catch(() => []),
  ]);

  return {
    pending,
    processed,
    recordings: recentRecordings,
    vocabulary: vocabRows,
    dialects: dialectRows,
    phraseCount: phraseRows.length,
    verifiedPhrases: phraseRows.filter((row) => row.verificationStatus === "verified").length,
    userCount: userRows[0]?.count ?? 0,
  };
}

export async function getMyContributions(userId: number) {
  await ensureSeeded();
  return db
    .select()
    .from(contributions)
    .where(eq(contributions.userId, userId))
    .orderBy(desc(contributions.createdAt))
    .limit(20);
}

export async function searchDictionary(dialectId: number, query: string) {
  await ensureSeeded();
  if (!query.trim()) return getVocabularyRows(dialectId);
  const pattern = `%${query.trim()}%`;
  return db
    .select()
    .from(vocabulary)
    .where(
      and(
        eq(vocabulary.dialectId, dialectId),
        or(ilike(vocabulary.word, pattern), ilike(vocabulary.definition, pattern)),
      ),
    )
    .orderBy(asc(vocabulary.frequencyRank));
}

export function fuzzyDictionaryMatches<T extends { word: string; definition: string }>(rows: T[], query: string): T[] {
  return rows
    .map((row) => ({
      row,
      score: Math.max(similarity(row.word, query), similarity(row.definition, query)),
    }))
    .filter((entry) => entry.score >= 0.55)
    .sort((a, b) => b.score - a.score)
    .slice(0, 6)
    .map((entry) => entry.row);
}
