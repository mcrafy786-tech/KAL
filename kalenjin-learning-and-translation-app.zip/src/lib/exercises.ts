import type { ExerciseTemplate } from "@/content/lessons";
import { normalizeText, stripParenthetical } from "@/lib/text";

export type ContentEntry = {
  conceptKey: string;
  word: string;
  definition: string;
  status: string;
  pronunciationGuide?: string | null;
  note?: string | null;
};

export type PhraseEntry = {
  conceptKey: string;
  english: string;
  kalenjin: string;
  status: string;
  note?: string | null;
};

export type ExerciseOption = { id: string; label: string };

export type MaterializedExercise = {
  id: string;
  kind: ExerciseTemplate["kind"];
  instruction: string;
  prompt: string;
  promptLanguage: "en" | "kal";
  audioText?: string;
  options: ExerciseOption[];
  correctOptionId?: string;
  accepted: string[];
  tokens?: string[];
  correctSentence?: string;
  explanation: string;
  conceptKey: string;
};

export type SubmittedAnswer = { optionId?: string; text?: string; tokens?: string[] };

export type GradedResult = {
  exerciseId: string;
  correct: boolean;
  expected: string;
  given: string;
};

const instructionFor = (kind: ExerciseTemplate["kind"]): string => {
  switch (kind) {
    case "mcq_meaning":
      return "What does this Kalenjin word mean?";
    case "mcq_word":
      return "Which Kalenjin word matches this meaning?";
    case "listen":
      return "Listen, then choose the meaning.";
    case "type_translation":
      return "Type the Kalenjin word for this meaning.";
    case "type_definition":
      return "Translate this Kalenjin word into English.";
    case "arrange":
      return "Put the words in the reviewed order.";
  }
};

function acceptedDefinitionForms(definition: string): string[] {
  const base = stripParenthetical(definition);
  const forms = new Set<string>();
  forms.add(normalizeText(definition));
  forms.add(normalizeText(base));
  base.split(/[/,;]/).forEach((part) => {
    const value = normalizeText(part);
    if (value) forms.add(value);
  });
  return Array.from(forms).filter(Boolean);
}

function acceptedWordForms(word: string, definition: string): string[] {
  const forms = new Set<string>([normalizeText(word), normalizeText(word.replace(/'/g, ""))]);
  const numeric = definition.match(/\d+/g);
  numeric?.forEach((digits) => forms.add(digits));
  return Array.from(forms).filter(Boolean);
}

export function materializeExercises(
  templates: ExerciseTemplate[],
  vocabulary: Map<string, ContentEntry>,
  phrases: Map<string, PhraseEntry>,
): MaterializedExercise[] {
  const exercises: MaterializedExercise[] = [];

  templates.forEach((template, index) => {
    const id = `ex-${index + 1}`;
    if (template.kind === "arrange") {
      const phrase = phrases.get(template.phraseConceptKey);
      if (!phrase) return;
      const tokens = phrase.kalenjin
        .replace(/[,.]/g, "")
        .split(/\s+/)
        .filter(Boolean);
      if (tokens.length < 2) return;
      exercises.push({
        id,
        kind: "arrange",
        instruction: instructionFor("arrange"),
        prompt: phrase.english,
        promptLanguage: "en",
        options: [],
        accepted: [normalizeText(phrase.kalenjin)],
        tokens,
        correctSentence: phrase.kalenjin,
        explanation: `Reviewed for your variety: “${phrase.english}” → “${phrase.kalenjin}”. ${
          phrase.status === "verified" ? "" : "Status: pending native-speaker review."
        }`.trim(),
        conceptKey: template.phraseConceptKey,
      });
      return;
    }

    const answer = vocabulary.get(template.conceptKey);
    if (!answer) return;

    if (template.kind === "type_translation" || template.kind === "type_definition") {
      exercises.push({
        id,
        kind: template.kind,
        instruction: instructionFor(template.kind),
        prompt:
          template.kind === "type_translation"
            ? stripParenthetical(answer.definition)
            : answer.word,
        promptLanguage: template.kind === "type_translation" ? "en" : "kal",
        audioText: template.kind === "type_definition" ? answer.word : undefined,
        options: [],
        accepted:
          template.kind === "type_translation"
            ? acceptedWordForms(answer.word, answer.definition)
            : acceptedDefinitionForms(answer.definition),
        explanation: `${answer.word} = ${answer.definition}. ${
          answer.status === "verified"
            ? "Reviewed entry."
            : "Pending native-speaker review — recognition practice only."
        } ${answer.note ?? ""}`.trim(),
        conceptKey: template.conceptKey,
      });
      return;
    }

    const optionKeys = Array.from(new Set([template.conceptKey, ...template.optionKeys]));
    const entries = optionKeys
      .map((key) => vocabulary.get(key))
      .filter((entry): entry is ContentEntry => Boolean(entry));
    if (entries.length < 2) return;

    const options: ExerciseOption[] = [];
    const seenLabels = new Set<string>();
    for (const entry of entries) {
      const label = template.kind === "mcq_word" ? entry.word : stripParenthetical(entry.definition);
      if (seenLabels.has(label)) continue;
      seenLabels.add(label);
      options.push({ id: entry.conceptKey, label });
    }
    if (options.length < 2) return;

    exercises.push({
      id,
      kind: template.kind,
      instruction: instructionFor(template.kind),
      prompt: template.kind === "mcq_word" ? stripParenthetical(answer.definition) : answer.word,
      promptLanguage: template.kind === "mcq_word" ? "en" : "kal",
      audioText: template.kind === "listen" ? answer.word : undefined,
      options,
      correctOptionId: template.conceptKey,
      accepted: [],
      explanation: `${answer.word} = ${answer.definition}. ${
        answer.status === "verified"
          ? "Reviewed entry."
          : "Pending native-speaker review."
      }`.trim(),
      conceptKey: template.conceptKey,
    });
  });

  return exercises;
}

export function gradeAnswer(exercise: MaterializedExercise, answer: SubmittedAnswer | undefined): boolean {
  if (!answer) return false;
  if (exercise.kind === "mcq_meaning" || exercise.kind === "mcq_word" || exercise.kind === "listen") {
    return Boolean(exercise.correctOptionId) && answer.optionId === exercise.correctOptionId;
  }
  if (exercise.kind === "arrange") {
    const given = normalizeText((answer.tokens ?? []).join(" "));
    const expected = normalizeText(exercise.correctSentence ?? "");
    return given.length > 0 && given === expected;
  }
  const given = normalizeText(answer.text ?? "");
  if (!given) return false;
  return exercise.accepted.some((accepted) => accepted === given);
}

export function gradeExercises(
  exercises: MaterializedExercise[],
  answers: Record<string, SubmittedAnswer>,
): { score: number; results: GradedResult[] } {
  const results = exercises.map((exercise) => {
    const answer = answers[exercise.id];
    const correct = gradeAnswer(exercise, answer);
    let given = "";
    if (answer?.optionId) {
      given = exercise.options.find((option) => option.id === answer.optionId)?.label ?? answer.optionId;
    } else if (answer?.tokens) {
      given = answer.tokens.join(" ");
    } else if (answer?.text) {
      given = answer.text;
    }
    const expected =
      exercise.kind === "arrange"
        ? (exercise.correctSentence ?? "")
        : exercise.kind === "type_translation" || exercise.kind === "type_definition"
          ? exercise.accepted[0] ?? ""
          : exercise.options.find((option) => option.id === exercise.correctOptionId)?.label ?? "";
    return { exerciseId: exercise.id, correct, expected, given };
  });
  const correctCount = results.filter((result) => result.correct).length;
  const score = results.length === 0 ? 0 : Math.round((correctCount / results.length) * 100);
  return { score, results };
}
