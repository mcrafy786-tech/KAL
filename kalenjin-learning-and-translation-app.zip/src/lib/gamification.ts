import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  achievements,
  dailyActivity,
  gameScores,
  lessons,
  translations,
  userProgress,
  userVocabulary,
  users,
} from "@/db/schema";
import { isoDaysAgo, todayIso } from "@/lib/text";

export type AchievementDef = {
  type: string;
  title: string;
  description: string;
  emoji: string;
};

export const ACHIEVEMENT_DEFS: AchievementDef[] = [
  { type: "first_lesson", title: "First steps", description: "Complete your first lesson", emoji: "🌱" },
  { type: "perfect_lesson", title: "Flawless", description: "Score 100% on a lesson", emoji: "🎯" },
  { type: "streak_3", title: "Three-day rhythm", description: "Practise three days in a row", emoji: "🔥" },
  { type: "streak_7", title: "Week of words", description: "Practise seven days in a row", emoji: "🗓️" },
  { type: "wordsmith_5", title: "Wordsmith", description: "Learn 5 dictionary words", emoji: "📖" },
  { type: "wordsmith_25", title: "Lexicon builder", description: "Learn 25 dictionary words", emoji: "🧠" },
  { type: "game_rookie", title: "Playful learner", description: "Finish your first game", emoji: "🎮" },
  { type: "game_perfect", title: "Game master", description: "Finish a game with a perfect score", emoji: "🏆" },
  { type: "translator_pioneer", title: "Bridge builder", description: "Save your first translation", emoji: "🌉" },
  { type: "contributor", title: "Voice of the community", description: "Submit content for native review", emoji: "🤝" },
];

export const LEVELS = [
  { min: 0, title: "Newcomer" },
  { min: 100, title: "Listener" },
  { min: 250, title: "Speaker" },
  { min: 500, title: "Storyteller" },
  { min: 900, title: "Kalenjin guide" },
  { min: 1500, title: "Language keeper" },
];

export function levelForXp(xp: number) {
  let index = 0;
  LEVELS.forEach((level, i) => {
    if (xp >= level.min) index = i;
  });
  const current = LEVELS[index];
  const next = LEVELS[index + 1];
  const progress = next ? Math.min(100, Math.round(((xp - current.min) / (next.min - current.min)) * 100)) : 100;
  return {
    index,
    title: current.title,
    nextTitle: next?.title ?? null,
    nextAt: next?.min ?? null,
    progress,
  };
}

export async function recordActivity(
  userId: number,
  delta: { xp?: number; minutes?: number; lessonsCompleted?: number; reviews?: number },
): Promise<void> {
  const xp = delta.xp ?? 0;
  const today = todayIso();

  const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user) return;

  let streak = user.streak;
  if (user.lastActiveDay !== today) {
    streak = user.lastActiveDay === isoDaysAgo(1) ? user.streak + 1 : 1;
  }

  await db
    .update(users)
    .set({ xp: user.xp + xp, streak, lastActiveDay: today })
    .where(eq(users.id, userId));

  await db
    .insert(dailyActivity)
    .values({
      userId,
      day: today,
      xpEarned: xp,
      minutes: delta.minutes ?? 0,
      lessonsCompleted: delta.lessonsCompleted ?? 0,
      reviews: delta.reviews ?? 0,
    })
    .onConflictDoUpdate({
      target: [dailyActivity.userId, dailyActivity.day],
      set: {
        xpEarned: sql`${dailyActivity.xpEarned} + ${xp}`,
        minutes: sql`${dailyActivity.minutes} + ${delta.minutes ?? 0}`,
        lessonsCompleted: sql`${dailyActivity.lessonsCompleted} + ${delta.lessonsCompleted ?? 0}`,
        reviews: sql`${dailyActivity.reviews} + ${delta.reviews ?? 0}`,
      },
    });
}

export async function awardAchievements(userId: number, candidates: string[]): Promise<string[]> {
  const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user) return [];

  const [completed, learned, games, translationCount, existing] = await Promise.all([
    db
      .select({ count: sql<number>`count(*)::int` })
      .from(userProgress)
      .where(and(eq(userProgress.userId, userId), eq(userProgress.status, "completed"))),
    db
      .select({ count: sql<number>`count(*)::int` })
      .from(userVocabulary)
      .where(eq(userVocabulary.userId, userId)),
    db.select({ count: sql<number>`count(*)::int` }).from(gameScores).where(eq(gameScores.userId, userId)),
    db
      .select({ count: sql<number>`count(*)::int` })
      .from(translations)
      .where(eq(translations.userId, userId)),
    db.select({ type: achievements.type }).from(achievements).where(eq(achievements.userId, userId)),
  ]);

  const qualified = new Set(candidates);
  if ((completed[0]?.count ?? 0) >= 1) qualified.add("first_lesson");
  if ((learned[0]?.count ?? 0) >= 5) qualified.add("wordsmith_5");
  if ((learned[0]?.count ?? 0) >= 25) qualified.add("wordsmith_25");
  if (user.streak >= 3) qualified.add("streak_3");
  if (user.streak >= 7) qualified.add("streak_7");
  if ((games[0]?.count ?? 0) >= 1) qualified.add("game_rookie");
  if ((translationCount[0]?.count ?? 0) >= 1) qualified.add("translator_pioneer");

  const already = new Set(existing.map((row) => row.type));
  const fresh = Array.from(qualified).filter((type) => !already.has(type));
  for (const type of fresh) {
    await db.insert(achievements).values({ userId, type }).onConflictDoNothing();
  }
  return fresh;
}

export async function pairVocabulary(userId: number, vocabularyIds: number[]): Promise<void> {
  for (const vocabularyId of vocabularyIds) {
    await db
      .insert(userVocabulary)
      .values({ userId, vocabularyId })
      .onConflictDoUpdate({
        target: [userVocabulary.userId, userVocabulary.vocabularyId],
        set: { lastReviewedAt: new Date(), strength: sql`${userVocabulary.strength} + 1` },
      });
  }
}

export async function lessonTitleForCount(): Promise<number> {
  const [row] = await db.select({ count: sql<number>`count(*)::int` }).from(lessons);
  return row?.count ?? 0;
}
