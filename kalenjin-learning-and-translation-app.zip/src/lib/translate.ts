import { eq } from "drizzle-orm";
import { db } from "@/db";
import { dialects, phrases, vocabulary } from "@/db/schema";
import { normalizeText, similarity, stripParenthetical, tokensOf } from "@/lib/text";
import { requestLlmProposal } from "@/lib/translation-providers";

export type Direction = "en-kal" | "kal-en";
export type ConfidenceStatus = "verified" | "review" | "low" | "unknown" | "proposal";

export type TranslationToken = {
  source: string;
  target: string | null;
  status: "verified" | "review" | "missing";
  conceptKey?: string;
  label?: string;
};

export type TranslationSuggestion = {
  english: string;
  kalenjin: string;
  status: string;
};

export type TranslationOutcome = {
  translatedText: string | null;
  confidence: ConfidenceStatus;
  score: number;
  provider: string;
  notes: string[];
  alternatives: { text: string; note: string }[];
  suggestions: TranslationSuggestion[];
  tokens: TranslationToken[];
  matchedPhraseId: number | null;
  requiresHumanReview: boolean;
  dialectCode: string;
  dialectName: string;
};

const CONFIDENCE_COPY: Record<ConfidenceStatus, string> = {
  verified: "Reviewed match from the verified corpus.",
  review: "Matched a corpus entry that is still pending native-speaker review.",
  low: "Word-level gloss only. Grammar and idiom have not been verified — do not treat this as fluent Kalenjin.",
  unknown: "No verified translation is available for this sentence in your selected variety.",
  proposal: "AI-generated proposal. Unverified. A native-speaker reviewer must approve it before it is trusted.",
};

export function confidenceExplanation(status: ConfidenceStatus): string {
  return CONFIDENCE_COPY[status];
}

function definitionMapIndex(
  rows: { conceptKey: string; word: string; definition: string; verificationStatus: string }[],
) {
  const byWord = new Map<string, (typeof rows)[number]>();
  const byDefinition = new Map<string, (typeof rows)[number]>();
  for (const row of rows) {
    byWord.set(normalizeText(row.word), row);
    byDefinition.set(normalizeText(row.definition), row);
    byDefinition.set(normalizeText(stripParenthetical(row.definition)), row);
    stripParenthetical(row.definition)
      .split(/[/,;]/)
      .map((part) => normalizeText(part))
      .filter(Boolean)
      .forEach((part) => byDefinition.set(part, row));
  }
  return { byWord, byDefinition };
}

function statusFromVerification(status: string): "verified" | "review" {
  return status === "verified" ? "verified" : "review";
}

export async function translateSentence(args: {
  text: string;
  direction: Direction;
  dialectId: number;
  allowProposal?: boolean;
}): Promise<TranslationOutcome> {
  const material = await loadDialectMaterial(args.dialectId);
  const base = translateFromCorpus(args.text, args.direction, material);

  if (base.confidence === "unknown" && args.allowProposal) {
    const proposal = await requestLlmProposal({
      text: args.text.trim(),
      fromLanguage: args.direction === "en-kal" ? "en" : "kal",
      dialectName: material.dialectName,
      knownCorpus: material.phrases.map((phrase) => ({ english: phrase.english, kalenjin: phrase.kalenjin })),
    });
    if (proposal) {
      return {
        ...base,
        translatedText: proposal.text,
        confidence: "proposal",
        score: 0.3,
        provider: "openai-proposal",
        notes: [
          "AI proposal — this is NOT a verified Kalenjin translation.",
          ...proposal.notes,
          "A native speaker must review and approve it before you rely on it.",
        ],
        requiresHumanReview: true,
      };
    }
  }

  return base;
}

async function loadDialectMaterial(dialectId: number) {
  const [dialect] = await db.select().from(dialects).where(eq(dialects.id, dialectId)).limit(1);
  if (!dialect) {
    throw new Error("Unknown language variety");
  }
  const [vocabRows, phraseRows] = await Promise.all([
    db.select().from(vocabulary).where(eq(vocabulary.dialectId, dialectId)),
    db.select().from(phrases).where(eq(phrases.dialectId, dialectId)),
  ]);
  const index = definitionMapIndex(vocabRows);
  return {
    dialectCode: dialect.code,
    dialectName: dialect.name,
    vocabRows,
    phraseRows,
    phrases: phraseRows,
    ...index,
  };
}

type DialectMaterial = Awaited<ReturnType<typeof loadDialectMaterial>>;

function translateFromCorpus(text: string, direction: Direction, material: DialectMaterial): TranslationOutcome {
  const normalized = normalizeText(text);
  const notes: string[] = [];
  const tokens: TranslationToken[] = [];
  const suggestions = closestSuggestions(normalized, direction, material);
  const base = {
    provider: "verified-corpus",
    suggestions,
    tokens,
    alternatives: [] as { text: string; note: string }[],
    dialectCode: material.dialectCode,
    dialectName: material.dialectName,
  };

  if (!normalized) {
    return {
      ...base,
      translatedText: null,
      confidence: "unknown",
      score: 0,
      notes: ["Enter a sentence or phrase to translate."],
      matchedPhraseId: null,
      requiresHumanReview: false,
    };
  }

  /* 1. Exact phrase match in the selected variety. */
  const exactPhrase = material.phraseRows.find((phrase) =>
    direction === "en-kal"
      ? phrase.normalizedEnglish === normalized
      : phrase.normalizedKalenjin === normalized,
  );

  if (exactPhrase) {
    const confidence = statusFromVerification(exactPhrase.verificationStatus);
    notes.push(confidenceExplanation(confidence));
    if (exactPhrase.verificationNote) notes.push(exactPhrase.verificationNote);
    return {
      ...base,
      translatedText: direction === "en-kal" ? exactPhrase.kalenjin : exactPhrase.english,
      confidence,
      score: confidence === "verified" ? 1 : 0.7,
      notes,
      provider: "verified-corpus",
      alternatives: (exactPhrase.alternatives ?? []).map((alternative) => ({
        text: direction === "en-kal" ? alternative.kalenjin : alternative.english,
        note: alternative.note,
      })),
      matchedPhraseId: exactPhrase.id,
      tokens: [
        {
          source: text,
          target: direction === "en-kal" ? exactPhrase.kalenjin : exactPhrase.english,
          status: confidence === "verified" ? "verified" : "review",
          conceptKey: exactPhrase.conceptKey,
        },
      ],
      requiresHumanReview: confidence !== "verified",
    };
  }

  /* 2. Single dictionary entry. */
  const singleWord = direction === "en-kal" ? material.byDefinition.get(normalized) : material.byWord.get(normalized);
  if (singleWord) {
    const confidence = statusFromVerification(singleWord.verificationStatus);
    notes.push(confidenceExplanation(confidence));
    notes.push("Dictionary entry — use in a full sentence requires verified grammar for this variety.");
    return {
      ...base,
      translatedText: direction === "en-kal" ? singleWord.word : singleWord.definition,
      confidence,
      score: confidence === "verified" ? 0.95 : 0.65,
      notes,
      matchedPhraseId: null,
      tokens: [
        {
          source: text,
          target: direction === "en-kal" ? singleWord.word : singleWord.definition,
          status: confidence === "verified" ? "verified" : "review",
          conceptKey: singleWord.conceptKey,
        },
      ],
      requiresHumanReview: confidence !== "verified",
    };
  }

  /* 3. Fuzzy nearest phrase (never presented as verified). */
  const fuzzy = material.phraseRows
    .map((phrase) => ({
      phrase,
      score: similarity(normalized, direction === "en-kal" ? phrase.normalizedEnglish : phrase.normalizedKalenjin),
    }))
    .sort((a, b) => b.score - a.score)[0];

  if (fuzzy && fuzzy.score >= 0.82) {
    notes.push(
      "Closest corpus phrase (fuzzy match). This is not an exact sentence match — confirm before using it.",
    );
    if (fuzzy.phrase.verificationNote) notes.push(fuzzy.phrase.verificationNote);
    return {
      ...base,
      translatedText: direction === "en-kal" ? fuzzy.phrase.kalenjin : fuzzy.phrase.english,
      confidence: "review",
      score: Math.round(fuzzy.score * 100) / 100,
      notes,
      matchedPhraseId: fuzzy.phrase.id,
      requiresHumanReview: true,
    };
  }

  /* 4. Word-by-word gloss with explicit uncertainty. */
  const sourceTokens = tokensOf(normalized);
  let matchedCount = 0;
  for (const token of sourceTokens) {
    const match =
      direction === "en-kal"
        ? material.byDefinition.get(token) ?? material.byWord.get(token)
        : material.byWord.get(token);
    if (match) {
      matchedCount += 1;
      tokens.push({
        source: token,
        target: direction === "en-kal" ? match.word : match.definition,
        status: match.verificationStatus === "verified" ? "verified" : "review",
        conceptKey: match.conceptKey,
      });
    } else {
      tokens.push({ source: token, target: null, status: "missing" });
    }
  }

  if (matchedCount > 0 && matchedCount === sourceTokens.length) {
    notes.push(confidenceExplanation("low"));
    notes.push(
      "Every word was found in the dictionary, but Kalenjin word order and verb inflection are not word-by-word. This gloss is for study only.",
    );
    return {
      ...base,
      translatedText: tokens.map((token) => token.target ?? "…").join(" "),
      confidence: "low",
      score: 0.35,
      notes,
      matchedPhraseId: null,
      requiresHumanReview: true,
    };
  }

  if (matchedCount > 0) {
    notes.push(
      `Only ${matchedCount} of ${sourceTokens.length} words are in the verified ${material.dialectName} dictionary.`,
    );
    notes.push(confidenceExplanation("low"));
    return {
      ...base,
      translatedText: tokens.map((token) => token.target ?? "…").join(" "),
      confidence: "low",
      score: 0.2,
      notes,
      matchedPhraseId: null,
      requiresHumanReview: true,
    };
  }

  notes.push(confidenceExplanation("unknown"));
  notes.push(
    suggestions.length > 0
      ? "A verified alternative is suggested below. You can also request native-speaker review."
      : "No close verified phrase exists yet. Request native-speaker review so this can be added to the corpus.",
  );
  return {
    ...base,
    translatedText: null,
    confidence: "unknown",
    score: 0,
    notes,
    matchedPhraseId: null,
    requiresHumanReview: true,
  };
}

function closestSuggestions(
  normalized: string,
  direction: Direction,
  material: DialectMaterial,
): TranslationSuggestion[] {
  return material.phraseRows
    .map((phrase) => ({
      phrase,
      score: similarity(
        normalized,
        direction === "en-kal" ? phrase.normalizedEnglish : phrase.normalizedKalenjin,
      ),
    }))
    .filter((entry) => entry.score >= 0.45)
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map((entry) => ({
      english: entry.phrase.english,
      kalenjin: entry.phrase.kalenjin,
      status: entry.phrase.verificationStatus,
    }));
}

export const translationSamples = [
  "Hello",
  "Thank you",
  "Yes",
  "One, two, three",
  "Water",
  "The sun",
  "Fire",
  "Mursik",
  "Mother",
  "House",
];
