/**
 * Optional external translation providers.
 *
 * The default engine is the verified corpus (`src/lib/translate.ts`). External AI
 * is only ever used to produce an *unverified proposal*, clearly labelled in the
 * UI as such. It never overwrites a verified corpus result and never claims
 * native-speaker review.
 *
 * Activation: set OPENAI_API_KEY (and optionally OPENAI_MODEL) in the server env.
 * No key ever reaches the browser. Without the key the provider reports itself
 * as unavailable and the app continues with corpus-only translation.
 */
export type ProposalRequest = {
  text: string;
  fromLanguage: "en" | "kal";
  dialectName: string;
  knownCorpus: { english: string; kalenjin: string }[];
};

export type Proposal = {
  text: string;
  notes: string[];
};

export function llmProposalAvailable(): boolean {
  return Boolean(process.env.OPENAI_API_KEY);
}

export async function requestLlmProposal(request: ProposalRequest): Promise<Proposal | null> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return null;
  const model = process.env.OPENAI_MODEL ?? "gpt-4o-mini";
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 14_000);
  try {
    const corpus = request.knownCorpus
      .map((entry) => `- ${entry.english} => ${entry.kalenjin}`)
      .join("\n");
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${apiKey}`,
      },
      signal: controller.signal,
      body: JSON.stringify({
        model,
        temperature: 0.1,
        response_format: { type: "json_object" },
        messages: [
          {
            role: "system",
            content:
              "You assist a Kalenjin language application. You must NOT invent Kalenjin grammar, words, or idioms. " +
              `Use only the supplied verified ${request.dialectName} corpus for Kalenjin output. ` +
              "If the corpus cannot support a translation, return an empty translation and explain what is missing. " +
              "Your output is an unverified proposal for a human reviewer and will be labelled as such. " +
              'Reply as JSON: {"translation": string, "notes": string[]}.',
          },
          {
            role: "user",
            content: `Corpus for ${request.dialectName}:\n${corpus || "(empty)"}\n\nTask: translate the following ${
              request.fromLanguage === "en" ? "English to Kalenjin" : "Kalenjin to English"
            }: "${request.text}"\nNever blend another Kalenjin variety into the answer.`,
          },
        ],
      }),
    });
    if (!response.ok) return null;
    const payload = (await response.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const raw = payload.choices?.[0]?.message?.content;
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { translation?: string; notes?: string[] };
    const translation = (parsed.translation ?? "").trim();
    if (!translation) return null;
    return {
      text: translation,
      notes: (parsed.notes ?? []).slice(0, 3),
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}
