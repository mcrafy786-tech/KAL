import { eq } from "drizzle-orm";
import { db } from "@/db";
import { phrases, vocabulary } from "@/db/schema";
import { translateSentence } from "@/lib/translate";
import { stripParenthetical } from "@/lib/text";

export type TutorPractice = {
  prompt: string;
  options: string[];
  answer: string;
  conceptKey: string;
};

export type TutorReply = {
  intent: string;
  content: string;
  suggestions: string[];
  grounding: string[];
  practice?: TutorPractice;
};

type CorpusRow = {
  conceptKey: string;
  word: string;
  definition: string;
  verificationStatus: string;
  verificationNote: string | null;
};

function statusLabel(status: string): string {
  return status === "verified" ? "reviewed entry" : "pending native review";
}

function findEntry(rows: CorpusRow[], conceptKey: string): CorpusRow | undefined {
  return rows.find((row) => row.conceptKey === conceptKey);
}

function entryLine(row: CorpusRow | undefined): string | null {
  if (!row) return null;
  return `${row.word} — ${stripParenthetical(row.definition)} (${statusLabel(row.verificationStatus)})`;
}

/**
 * Deterministic, corpus-grounded tutor. Every Kalenjin token in a reply comes
 * from the selected variety's database rows; nothing is generated from thin air.
 * An LLM provider can be layered on later, but it would still be labelled as an
 * unverified proposal, exactly like the translator.
 */
export async function tutorReply(args: {
  message: string;
  dialectId: number;
  dialectName: string;
  proficiencyLevel: string;
}): Promise<TutorReply> {
  const rows = (await db.select().from(vocabulary).where(eq(vocabulary.dialectId, args.dialectId))) as CorpusRow[];
  await db.select().from(phrases).where(eq(phrases.dialectId, args.dialectId));
  const message = args.message.trim();
  const lower = message.toLowerCase();
  const grounding = rows.slice(0, 8).map((row) => row.conceptKey);

  const hello = findEntry(rows, "greeting.hello");
  const thanks = findEntry(rows, "greeting.thanks");
  const yes = findEntry(rows, "greeting.yes");
  const no = findEntry(rows, "greeting.no");

  if (!message) {
    return {
      intent: "empty",
      content: "Ask me about a word, a number, or how to greet someone in " + args.dialectName + ".",
      suggestions: ["Teach me a greeting", "Show me the numbers", "How do I introduce myself?"],
      grounding,
    };
  }

  if (/^(hi|hello|hey|habari|sasa|chamgei|kongoi)\b/.test(lower)) {
    const greeting = entryLine(hello);
    return {
      intent: "greeting",
      content: [
        `Chamgei — welcome to your ${args.dialectName} practice.`,
        greeting
          ? `For your variety, the corpus currently has: ${greeting}.`
          : `I do not yet have a reviewed greeting for ${args.dialectName}. I will not guess one — you can submit a recorded greeting for review.`,
        "What would you like to work on: greetings, numbers, family words, or a translation?",
      ].join("\n\n"),
      suggestions: ["Teach me the numbers", "How do I introduce myself?", "Translate: thank you"],
      grounding,
    };
  }

  if (/(introduce|introduction|my name|jina)/.test(lower)) {
    const parts = [entryLine(hello), entryLine(thanks), entryLine(yes)].filter(Boolean);
    return {
      intent: "introduce",
      content: [
        `A full self-introduction needs a reviewed sentence pattern, and I do not have one confirmed for ${args.dialectName} yet. I will not invent one.`,
        parts.length > 0
          ? `Here is what is safely available right now:\n${parts.map((part) => `• ${part}`).join("\n")}`
          : `No introduction vocabulary is available for ${args.dialectName} yet.`,
        "A safe first step: learn the greeting and the thank-you, then ask a native speaker to record 'My name is …' for your variety. You can submit that recording for review in the Contribute area.",
      ].join("\n\n"),
      suggestions: ["Teach me a greeting", "Why is some content marked needs review?", "Translate: hello"],
      grounding,
    };
  }

  if (/(how are you|greet|greeting|morning|evening)/.test(lower)) {
    const line = entryLine(hello);
    return {
      intent: "greeting-practice",
      content: [
        line
          ? `Start with ${line}. Greetings come first in most Kalenjin conversations, before business or questions.`
          : `I do not have a reviewed greeting for ${args.dialectName} yet.`,
        "I am deliberately not giving you a made-up 'How are you?' sentence. That expression differs by community and register, and a wrong form can sound disrespectful. Mark it for human review and a native speaker can add it.",
        "Try saying the reviewed greeting out loud three times, then play the audio on this word's dictionary card to compare.",
      ].join("\n\n"),
      suggestions: ["Which words are reviewed?", "Give me a practice question", "Translate: hello"],
      grounding,
    };
  }

  if (/(number|count|one|two|three|ten)/.test(lower)) {
    const numerals = rows
      .filter((row) => row.conceptKey.startsWith("number."))
      .sort((a, b) => a.conceptKey.localeCompare(b.conceptKey));
    if (numerals.length === 0) {
      return {
        intent: "numbers",
        content: `I do not have number entries for ${args.dialectName} yet. You can contribute them with a recording for review.`,
        suggestions: ["Teach me a greeting", "What can you teach me?"],
        grounding,
      };
    }
    return {
      intent: "numbers",
      content: [
        `Here are the ${args.dialectName} numerals in the corpus right now:`,
        numerals.map((row) => `• ${row.word} — ${stripParenthetical(row.definition)} (${statusLabel(row.verificationStatus)})`).join("\n"),
        "Remember: counting objects may need noun-class agreement that is not yet verified here. Use the numerals as recognition practice first.",
      ].join("\n\n"),
      suggestions: ["Give me a practice question", "Teach me a greeting", "Translate: one, two, three"],
      grounding: numerals.map((row) => row.conceptKey),
    };
  }

  if (/(family|mother|father|child|kinship)/.test(lower)) {
    const family = rows.filter((row) => row.conceptKey.startsWith("family."));
    return {
      intent: "family",
      content: [
        family.length > 0
          ? `Family vocabulary for ${args.dialectName}:\n${family
              .map((row) => `• ${row.word} — ${stripParenthetical(row.definition)} (${statusLabel(row.verificationStatus)})`)
              .join("\n")}`
          : `I have no family vocabulary for ${args.dialectName} yet.`,
        "Kinship terms are the most variety- and register-sensitive part of this vocabulary. Everything above is recognition practice until a native speaker confirms it in the app.",
      ].join("\n\n"),
      suggestions: ["Why is some content marked needs review?", "Give me a practice question", "Show me the numbers"],
      grounding: family.map((row) => row.conceptKey),
    };
  }

  if (/(review|verified|trust|accuracy|sure|confiden)/.test(lower)) {
    return {
      intent: "verification",
      content: [
        "Every Kalenjin entry carries a status. 'Reviewed' means attested in published material and tracked in the app's review log. 'Needs review' means a learner may recognise it, but it is not confirmed for production use.",
        "The Live Translator applies the same rule: a full-sentence corpus match can be 'Reviewed match', a partial or fuzzy match is flagged, and a word-by-word gloss is explicitly called approximate.",
        "When there is no verified answer I will say so. I never fill gaps with invented Kalenjin.",
      ].join("\n\n"),
      suggestions: ["Translate: hello", "How do I introduce myself?", "Give me a practice question"],
      grounding,
    };
  }

  if (/(translate|meaning of|how do you say)/.test(lower)) {
    const target = message
      .replace(/.*?(translate|meaning of|how do you say)/i, "")
      .replace(/^[:\s"']+|[?"']+$/g, "")
      .trim();
    if (!target) {
      return {
        intent: "translate-needs-input",
        content: "Tell me the sentence you want translated, for example: translate: thank you.",
        suggestions: ["Translate: hello", "Translate: water", "Translate: one, two, three"],
        grounding,
      };
    }
    const outcome = await translateSentence({ text: target, direction: "en-kal", dialectId: args.dialectId });
    const label =
      outcome.confidence === "verified"
        ? "Reviewed match"
        : outcome.confidence === "review"
          ? "Corpus match — pending review"
          : outcome.confidence === "low"
            ? "Approximate word gloss"
            : "Not available in the verified corpus";
    return {
      intent: "translate",
      content: [
        `“${target}” in ${args.dialectName}:`,
        outcome.translatedText ? `**${outcome.translatedText}** — ${label}` : `**No verified translation available.**`,
        ...outcome.notes.slice(0, 3),
        outcome.suggestions.length > 0
          ? `Closest reviewed phrases: ${outcome.suggestions.map((suggestion) => `${suggestion.english} → ${suggestion.kalenjin}`).join("; ")}`
          : "",
      ]
        .filter(Boolean)
        .join("\n\n"),
      suggestions: ["Why is some content marked needs review?", "Teach me a greeting", "Request native review"],
      grounding,
    };
  }

  if (/(practice|quiz|test|question|exercise)/.test(lower)) {
    const practice = buildPractice(rows);
    if (!practice) {
      return {
        intent: "practice-empty",
        content: `Not enough ${args.dialectName} vocabulary is loaded to build a practice question yet.`,
        suggestions: ["Teach me a greeting", "Show me the numbers"],
        grounding,
      };
    }
    return {
      intent: "practice",
      content: `Let's practise. ${practice.prompt}`,
      suggestions: ["Another question", "Explain the answer", "Teach me a greeting"],
      grounding,
      practice,
    };
  }

  if (/(grammar|verb|noun|sentence|structure|tense)/.test(lower)) {
    return {
      intent: "grammar",
      content: [
        "Kalenjin is a Southern Nilotic language. Three things matter for learners: nouns fall into classes that control agreement, verbs carry person and tense/aspect marking inside the word, and spoken register changes with age and community.",
        "Because agreement and inflection depend on the exact noun or verb, I will not generate sentence patterns. Learn fixed reviewed phrases first; when a native speaker supplies a paradigm for your variety, it goes into the lesson content after review.",
        `You are currently studying ${args.dialectName}. Different Kalenjin varieties are not interchangeable — I will always keep your variety separate.`,
      ].join("\n\n"),
      suggestions: ["Give me a practice question", "Show me the numbers", "Why is some content marked needs review?"],
      grounding,
    };
  }

  const best = rows
    .filter((row) => lower.includes(row.word.toLowerCase()))
    .slice(0, 2);
  return {
    intent: "fallback",
    content: [
      best.length > 0
        ? `I spotted ${best.map((row) => `${row.word} (${stripParenthetical(row.definition)})`).join(" and ")} in your message.`
        : `I can help with ${args.dialectName} greetings, numbers, family words, dictionary meanings and translation.`,
      "I only answer from the reviewed corpus, so I will say 'not available' rather than guess. What would you like to practise?",
    ].join("\n\n"),
    suggestions: ["Teach me a greeting", "Show me the numbers", "Give me a practice question", "Translate: thank you"],
    grounding,
  };
}

function buildPractice(rows: CorpusRow[]): TutorPractice | undefined {
  const pool = rows.filter((row) => row.definition.length > 2);
  if (pool.length < 3) return undefined;
  const answer = pool[Math.floor(Math.random() * pool.length)];
  const distractors = pool.filter((row) => row.conceptKey !== answer.conceptKey).slice(0, 2);
  const options = [answer, ...distractors]
    .map((row) => row.word)
    .sort(() => Math.random() - 0.5);
  return {
    prompt: `Which Kalenjin word means “${stripParenthetical(answer.definition)}”?`,
    options,
    answer: answer.word,
    conceptKey: answer.conceptKey,
  };
}
