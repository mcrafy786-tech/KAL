"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type RecognitionResultEvent = {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: { isFinal: boolean; 0: { transcript: string } };
  };
};

type RecognitionLike = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((event: RecognitionResultEvent) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
};

type RecognitionCtor = new () => RecognitionLike;

function getRecognitionCtor(): RecognitionCtor | null {
  if (typeof window === "undefined") return null;
  const win = window as unknown as { SpeechRecognition?: RecognitionCtor; webkitSpeechRecognition?: RecognitionCtor };
  return win.SpeechRecognition ?? win.webkitSpeechRecognition ?? null;
}

export type RecognitionState = "idle" | "listening" | "unsupported" | "denied" | "error";

export function useSpeechRecognition(options: {
  lang: string;
  onTranscript: (transcript: string) => void;
  onEnd?: () => void;
}) {
  const { lang, onTranscript, onEnd } = options;
  const [state, setState] = useState<RecognitionState>("idle");
  const [error, setError] = useState<string | null>(null);
  const [interim, setInterim] = useState("");
  const recognitionRef = useRef<RecognitionLike | null>(null);
  const ctorRef = useRef<RecognitionCtor | null>(null);
  const [supported, setSupported] = useState<boolean | null>(null);

  useEffect(() => {
    const ctor = getRecognitionCtor();
    ctorRef.current = ctor;
    const timer = setTimeout(() => {
      setSupported(Boolean(ctor));
      if (!ctor) setState("unsupported");
    }, 0);
    return () => clearTimeout(timer);
  }, []);

  const stop = useCallback(() => {
    recognitionRef.current?.stop();
    recognitionRef.current = null;
    setState((previous) => (previous === "listening" ? "idle" : previous));
    setInterim("");
  }, []);

  const start = useCallback(() => {
    const Ctor = ctorRef.current;
    if (!Ctor) {
      setState("unsupported");
      setError("This browser cannot access microphone speech recognition. Use the manual text input below.");
      return;
    }
    setError(null);
    setInterim("");
    try {
      const recognition = new Ctor();
      recognition.lang = lang;
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
      let finalText = "";
      recognition.onresult = (event) => {
        let interimText = "";
        for (let i = event.resultIndex; i < event.results.length; i += 1) {
          const result = event.results[i];
          if (result.isFinal) {
            finalText += result[0].transcript;
          } else {
            interimText += result[0].transcript;
          }
        }
        setInterim(interimText);
        if (finalText.trim()) {
          onTranscript(finalText.trim());
        }
      };
      recognition.onerror = (event) => {
        if (event.error === "not-allowed" || event.error === "service-not-allowed") {
          setState("denied");
          setError("Microphone permission was blocked. Enable it in your browser settings, or type the text instead.");
        } else if (event.error === "no-speech") {
          setState("idle");
          setError("No speech detected. Try again, a little closer to the microphone.");
        } else if (event.error !== "aborted") {
          setState("error");
          setError(`Speech recognition error: ${event.error}. You can type the text instead.`);
        }
      };
      recognition.onend = () => {
        setState("idle");
        setInterim("");
        recognitionRef.current = null;
        onEnd?.();
      };
      recognitionRef.current = recognition;
      recognition.start();
      setState("listening");
    } catch {
      setState("error");
      setError("Could not start speech recognition. Check microphone permissions or type the text instead.");
    }
  }, [lang, onTranscript, onEnd]);

  useEffect(() => stop, [stop]);

  return { supported, state, error, interim, start, stop, listening: state === "listening" };
}

export function useSpeechSynthesis() {
  const [speaking, setSpeaking] = useState(false);
  const [paused, setPaused] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [supported, setSupported] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    const load = () => {
      setVoices(window.speechSynthesis.getVoices());
      setSupported(true);
    };
    const timer = setTimeout(load, 0);
    window.speechSynthesis.addEventListener("voiceschanged", load);
    return () => {
      clearTimeout(timer);
      window.speechSynthesis.removeEventListener("voiceschanged", load);
    };
  }, []);

  const pickVoice = useCallback(
    (lang: "en" | "kal") => {
      if (voices.length === 0) return null;
      if (lang === "en") {
        return voices.find((voice) => voice.lang.toLowerCase().startsWith("en")) ?? null;
      }
      return (
        voices.find((voice) => voice.lang.toLowerCase().startsWith("sw")) ??
        voices.find((voice) => voice.lang.toLowerCase().startsWith("en-ke")) ??
        null
      );
    },
    [voices],
  );

  const speak = useCallback(
    (text: string, settings?: { lang?: "en" | "kal"; rate?: number; volume?: number }) => {
      if (typeof window === "undefined" || !("speechSynthesis" in window) || !text.trim()) return false;
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      const lang = settings?.lang ?? "en";
      const voice = pickVoice(lang);
      if (voice) utterance.voice = voice;
      utterance.lang = lang === "en" ? voice?.lang ?? "en-US" : voice?.lang ?? "sw-KE";
      utterance.rate = settings?.rate ?? 0.92;
      utterance.volume = settings?.volume ?? 1;
      utterance.onstart = () => {
        setSpeaking(true);
        setPaused(false);
      };
      utterance.onend = () => {
        setSpeaking(false);
        setPaused(false);
      };
      utterance.onerror = () => {
        setSpeaking(false);
        setPaused(false);
      };
      utteranceRef.current = utterance;
      window.speechSynthesis.speak(utterance);
      return true;
    },
    [pickVoice],
  );

  const stop = useCallback(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    setSpeaking(false);
    setPaused(false);
  }, []);

  const pause = useCallback(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.pause();
    setPaused(true);
  }, []);

  const resume = useCallback(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.resume();
    setPaused(false);
  }, []);

  const kalenjinVoiceAvailable = voices.some((voice) => voice.lang.toLowerCase().startsWith("sw"));

  return { speak, stop, pause, resume, speaking, paused, kalenjinVoiceAvailable, supported };
}

export function useVoiceRecorder() {
  const [recording, setRecording] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const urlRef = useRef<string | null>(null);

  const stop = useCallback(() => {
    recorderRef.current?.stop();
    recorderRef.current = null;
    setRecording(false);
  }, []);

  const start = useCallback(async () => {
    setError(null);
    if (typeof window === "undefined" || !navigator.mediaDevices?.getUserMedia) {
      setError("Recording is not available in this browser.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) chunksRef.current.push(event.data);
      };
      recorder.onstop = () => {
        stream.getTracks().forEach((track) => track.stop());
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        if (urlRef.current) URL.revokeObjectURL(urlRef.current);
        urlRef.current = URL.createObjectURL(blob);
        setAudioUrl(urlRef.current);
      };
      recorder.start();
      recorderRef.current = recorder;
      setRecording(true);
    } catch {
      setError("Microphone permission denied. You can still listen to the reference audio.");
    }
  }, []);

  useEffect(() => {
    return () => {
      if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    };
  }, []);

  return { recording, audioUrl, error, start, stop, reset: () => setAudioUrl(null) };
}
